<!-- CONSTRUCT-SKILL-NOTES:BEGIN version=1 -->

## Reference Notes

**Reference scope.** Meaningful non-sameness, reference frames, distinctions, discrimination, causal difference-making and category boundaries.

- Formal anchors: equivalence relations, partitions, metric/topological separation, information-theoretic discrimination, measurement theory, counterfactual and contrastive explanation.
- Operational anchors: sensitivity/specificity, confidence intervals, measurement error, threshold analysis and context-specific fairness audits.
- Evidence rule: report the comparison universe, measurement resolution, invariances and chosen dimensions before calling a distinction real, material, causal or normatively important.

**Reference register convention.** For every cited claim, record source title/author or standards body, edition or release, persistent identifier/URL, access date when online, quoted passage or page/section, claim supported, evidence tier, and known counterevidence. External works mentioned here are **reading leads, not bundled or automatically verified citations**. Resolve authoritative editions before use.

## Assets Notes

**Existing package assets (verified against release `pluginrel_6ad31a9c75dc81918fe03685a5cd24bc`):**

- **Bundled local reference:** none specific to this skill was listed in the current release.
- **Shared branding only:** `assets/construct-icon.png` exists at plugin root. It is not evidence, a skill dataset, or a specialized analysis asset.
- **No other difference-specific templates, data files, test corpora, schemas, or visualizations were found in the release file inventory.**

**Recommended assets to develop and validate:**

- **Proposed, not yet bundled:** difference vector and contrast-dimension schema.
- **Proposed, not yet bundled:** frame-sensitivity and robustness matrix.
- **Proposed, not yet bundled:** boundary cases, false distinctions and near-match controls.
- **Proposed, not yet bundled:** counterfactual contrast and causal-warrant log.

**Asset registration standard.** Every future file should carry purpose, source/creator, provenance, license/consent, version, schema or media type, integrity digest, restrictions, expected consumer, and validation status. Keep examples distinct from normative specifications and empirical datasets. Do not claim a proposed asset exists until it has been bundled and audited.

## Dependencies

**Package/runtime dependencies.** This skill is a Markdown instruction module; no skill-specific executable runtime, package manager dependency, remote API, or MCP tool dependency is declared in the inspected plugin package. Invocation of tools or sources is conditional on access, authorization, and the question being asked.

**Cross-skill reasoning dependencies (invoke selectively, not automatically):**

- `skills/similarity/SKILL.md` — define legitimate equivalence; a **conceptual** dependency, not a required code import.
- `skills/uniqueness/SKILL.md` — escalate from differences to singularity; a **conceptual** dependency, not a required code import.
- `skills/taxonomy/SKILL.md` — turn stable distinctions into categories; a **conceptual** dependency, not a required code import.
- `skills/validity/SKILL.md` — test discriminability and context fitness; a **conceptual** dependency, not a required code import.

**Handoff contract.** Input: compared objects, purpose, dimensions and resolution. Output: contrastive features, distances/boundaries, uncertainty, effect on decisions and tests of frame dependence.

**Dependency rules.** Preserve the ownership boundary between specialist skills; pass a stated purpose, definitions, provenance, constraints and confidence with every handoff. If a required skill, external source, authorization or test environment is unavailable, mark the gap rather than simulating evidence or claiming a test ran.

<!-- CONSTRUCT-SKILL-NOTES:END -->
