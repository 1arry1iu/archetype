<!-- CONSTRUCT-SKILL-NOTES:BEGIN version=1 -->

## Reference Notes

**Reference scope.** Justified likeness, correspondence, equivalence, analogy, matching and substitutability.

- Research anchors: Tversky's feature-based similarity, formal equivalence relations, metric learning, semantic similarity, analogy theory and record linkage.
- Technical anchors: embedding distances, threshold calibration, invariance, nearest-neighbor retrieval and evaluation against labeled matches/nonmatches.
- Evidence rule: distinguish representational similarity from causal resemblance or functional interchangeability; state dimension, transformation and consequence.

**Reference register convention.** For every cited claim, record source title/author or standards body, edition or release, persistent identifier/URL, access date when online, quoted passage or page/section, claim supported, evidence tier, and known counterevidence. External works mentioned here are **reading leads, not bundled or automatically verified citations**. Resolve authoritative editions before use.

## Assets Notes

**Existing package assets (verified against release `pluginrel_6ad31a9c75dc81918fe03685a5cd24bc`):**

- **Bundled local reference:** none specific to this skill was listed in the current release.
- **Shared branding only:** `assets/construct-icon.png` exists at plugin root. It is not evidence, a skill dataset, or a specialized analysis asset.
- **No other similarity-specific templates, data files, test corpora, schemas, or visualizations were found in the release file inventory.**

**Recommended assets to develop and validate:**

- **Proposed, not yet bundled:** similarity definition and feature-weight registry.
- **Proposed, not yet bundled:** positive/negative near-match benchmark.
- **Proposed, not yet bundled:** metric, threshold, calibration and slice evaluation.
- **Proposed, not yet bundled:** analogy/correspondence mapping ledger.
- **Proposed, not yet bundled:** substitutability-failure and false-merge cases.

**Asset registration standard.** Every future file should carry purpose, source/creator, provenance, license/consent, version, schema or media type, integrity digest, restrictions, expected consumer, and validation status. Keep examples distinct from normative specifications and empirical datasets. Do not claim a proposed asset exists until it has been bundled and audited.

## Dependencies

**Package/runtime dependencies.** This skill is a Markdown instruction module; no skill-specific executable runtime, package manager dependency, remote API, or MCP tool dependency is declared in the inspected plugin package. Invocation of tools or sources is conditional on access, authorization, and the question being asked.

**Cross-skill reasoning dependencies (invoke selectively, not automatically):**

- `skills/difference/SKILL.md` — necessary discriminatory dimensions; a **conceptual** dependency, not a required code import.
- `skills/uniqueness/SKILL.md` — identity/equivalence boundaries; a **conceptual** dependency, not a required code import.
- `skills/taxonomy/SKILL.md` — category-aware matching; a **conceptual** dependency, not a required code import.
- `skills/validity/SKILL.md` — calibrate similarity metrics; a **conceptual** dependency, not a required code import.
- `skills/information/SKILL.md` — metadata and embeddings; a **conceptual** dependency, not a required code import.

**Handoff contract.** Input: entities, purpose, representation and similarity criterion. Output: qualified match/analogy, score or relation, confidence, threshold and invalid-use warnings.

**Dependency rules.** Preserve the ownership boundary between specialist skills; pass a stated purpose, definitions, provenance, constraints and confidence with every handoff. If a required skill, external source, authorization or test environment is unavailable, mark the gap rather than simulating evidence or claiming a test ran.

<!-- CONSTRUCT-SKILL-NOTES:END -->
