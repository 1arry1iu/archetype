<!-- CONSTRUCT-SKILL-NOTES:BEGIN version=1 -->

## Reference Notes

**Reference scope.** Context-specific warranted reliance for claims, measurements, inference, models, systems and agents.

- Standards anchors: the Standards for Educational and Psychological Testing where relevant, VVUQ practice, NIST AI Risk Management Framework and domain-specific assurance criteria.
- Research anchors: construct validity, measurement invariance, causal identification, external validity, robustness, falsification and adversarial red teaming.
- Evidence rule: distinguish verification ('built correctly') from validation ('fit for stated use'); confidence is use-conditional and subject to failure modes and monitoring.

**Reference register convention.** For every cited claim, record source title/author or standards body, edition or release, persistent identifier/URL, access date when online, quoted passage or page/section, claim supported, evidence tier, and known counterevidence. External works mentioned here are **reading leads, not bundled or automatically verified citations**. Resolve authoritative editions before use.

## Assets Notes

**Existing package assets (verified against release `pluginrel_6ad31a9c75dc81918fe03685a5cd24bc`):**

- **Bundled local reference:** none specific to this skill was listed in the current release.
- **Shared branding only:** `assets/construct-icon.png` exists at plugin root. It is not evidence, a skill dataset, or a specialized analysis asset.
- **No other validity-specific templates, data files, test corpora, schemas, or visualizations were found in the release file inventory.**

**Recommended assets to develop and validate:**

- **Proposed, not yet bundled:** claim–use–context–acceptance-criteria matrix.
- **Proposed, not yet bundled:** evidence and rebuttal/assurance case graph.
- **Proposed, not yet bundled:** measurement/causal/generalization threat register.
- **Proposed, not yet bundled:** stress, negative-control and out-of-distribution test suite.
- **Proposed, not yet bundled:** revalidation triggers and retirement policy.

**Asset registration standard.** Every future file should carry purpose, source/creator, provenance, license/consent, version, schema or media type, integrity digest, restrictions, expected consumer, and validation status. Keep examples distinct from normative specifications and empirical datasets. Do not claim a proposed asset exists until it has been bundled and audited.

## Dependencies

**Package/runtime dependencies.** This skill is a Markdown instruction module; no skill-specific executable runtime, package manager dependency, remote API, or MCP tool dependency is declared in the inspected plugin package. Invocation of tools or sources is conditional on access, authorization, and the question being asked.

**Cross-skill reasoning dependencies (invoke selectively, not automatically):**

- `skills/model/SKILL.md` — representational assumptions; a **conceptual** dependency, not a required code import.
- `skills/evaluation/SKILL.md` — evaluate performance without conflating validity; a **conceptual** dependency, not a required code import.
- `skills/judgement/SKILL.md` — calibrate uncertain conclusions; a **conceptual** dependency, not a required code import.
- `skills/information/SKILL.md` — evidence provenance; a **conceptual** dependency, not a required code import.
- `skills/workflow/SKILL.md` — execute ongoing assurance; a **conceptual** dependency, not a required code import.

**Handoff contract.** Input: proposed use, claims, population/context, hazards and evidence. Output: validated-for-use scope, unsupported regions, uncertainty, controls and review triggers.

**Dependency rules.** Preserve the ownership boundary between specialist skills; pass a stated purpose, definitions, provenance, constraints and confidence with every handoff. If a required skill, external source, authorization or test environment is unavailable, mark the gap rather than simulating evidence or claiming a test ran.

<!-- CONSTRUCT-SKILL-NOTES:END -->
