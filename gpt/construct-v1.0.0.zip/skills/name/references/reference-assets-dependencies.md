<!-- CONSTRUCT-SKILL-NOTES:BEGIN version=1 -->

## Reference Notes

**Reference scope.** Precise names, terms, identifiers, namespaces, resolution and renaming governance.

- Standards anchors: terminology principles (e.g., ISO 704), URI syntax (RFC 3986), Unicode normalization, internationalized identifiers and namespace conventions.
- Research anchors: onomastics, sociolinguistics, reference theory, entity resolution, human factors and naming collision/security threat models.
- Evidence rule: lexical uniqueness does not prove referential uniqueness; resolve collisions within a defined namespace, population, time and language context.

**Reference register convention.** For every cited claim, record source title/author or standards body, edition or release, persistent identifier/URL, access date when online, quoted passage or page/section, claim supported, evidence tier, and known counterevidence. External works mentioned here are **reading leads, not bundled or automatically verified citations**. Resolve authoritative editions before use.

## Assets Notes

**Existing package assets (verified against release `pluginrel_6ad31a9c75dc81918fe03685a5cd24bc`):**

- **Bundled local reference:** none specific to this skill was listed in the current release.
- **Shared branding only:** `assets/construct-icon.png` exists at plugin root. It is not evidence, a skill dataset, or a specialized analysis asset.
- **No other name-specific templates, data files, test corpora, schemas, or visualizations were found in the release file inventory.**

**Recommended assets to develop and validate:**

- **Proposed, not yet bundled:** term/name register with definition, owner, language and status.
- **Proposed, not yet bundled:** collision, confusable and transliteration tests.
- **Proposed, not yet bundled:** persistent-identifier and redirect specification.
- **Proposed, not yet bundled:** deprecation, alias and rename-history ledger.

**Asset registration standard.** Every future file should carry purpose, source/creator, provenance, license/consent, version, schema or media type, integrity digest, restrictions, expected consumer, and validation status. Keep examples distinct from normative specifications and empirical datasets. Do not claim a proposed asset exists until it has been bundled and audited.

## Dependencies

**Package/runtime dependencies.** This skill is a Markdown instruction module; no skill-specific executable runtime, package manager dependency, remote API, or MCP tool dependency is declared in the inspected plugin package. Invocation of tools or sources is conditional on access, authorization, and the question being asked.

**Cross-skill reasoning dependencies (invoke selectively, not automatically):**

- `skills/difference/SKILL.md` — distinctiveness criteria; a **conceptual** dependency, not a required code import.
- `skills/uniqueness/SKILL.md` — one-of-one identifier checks; a **conceptual** dependency, not a required code import.
- `skills/taxonomy/SKILL.md` — terms attached to stable concepts; a **conceptual** dependency, not a required code import.
- `skills/information/SKILL.md` — entity identity and provenance; a **conceptual** dependency, not a required code import.
- `skills/format/SKILL.md` — identifier encoding rules; a **conceptual** dependency, not a required code import.

**Handoff contract.** Input: entities/concepts, scope, audiences, languages and constraints. Output: controlled naming system, collision checks, resolution rules and change governance.

**Dependency rules.** Preserve the ownership boundary between specialist skills; pass a stated purpose, definitions, provenance, constraints and confidence with every handoff. If a required skill, external source, authorization or test environment is unavailable, mark the gap rather than simulating evidence or claiming a test ran.

<!-- CONSTRUCT-SKILL-NOTES:END -->
