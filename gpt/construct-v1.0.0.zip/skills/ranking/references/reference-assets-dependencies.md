<!-- CONSTRUCT-SKILL-NOTES:BEGIN version=1 -->

## Reference Notes

**Reference scope.** Relative ordering of alternatives with explicit objectives, relevance, preferences, uncertainty and exposure effects.

- Technical anchors: pairwise-comparison models (e.g., Bradley–Terry), information retrieval metrics including NDCG, multicriteria decision analysis and learning-to-rank.
- Governance anchors: rank stability, bias audits, exposure fairness, feedback loops, group effects and counterfactual evaluation.
- Evidence rule: an ordered list is not an absolute measure of merit; specify candidate set, scoring criteria, tie policy, uncertainty and downstream impact.

**Reference register convention.** For every cited claim, record source title/author or standards body, edition or release, persistent identifier/URL, access date when online, quoted passage or page/section, claim supported, evidence tier, and known counterevidence. External works mentioned here are **reading leads, not bundled or automatically verified citations**. Resolve authoritative editions before use.

## Assets Notes

**Existing package assets (verified against release `pluginrel_6ad31a9c75dc81918fe03685a5cd24bc`):**

- **Bundled local reference:** none specific to this skill was listed in the current release.
- **Shared branding only:** `assets/construct-icon.png` exists at plugin root. It is not evidence, a skill dataset, or a specialized analysis asset.
- **No other ranking-specific templates, data files, test corpora, schemas, or visualizations were found in the release file inventory.**

**Recommended assets to develop and validate:**

- **Proposed, not yet bundled:** candidate/criterion and score provenance registry.
- **Proposed, not yet bundled:** pairwise comparison and tie-resolution matrix.
- **Proposed, not yet bundled:** ranking stability and bootstrapped intervals.
- **Proposed, not yet bundled:** relevance labels, exposure audit and counterfactual tests.
- **Proposed, not yet bundled:** rank rationale and appeals register.

**Asset registration standard.** Every future file should carry purpose, source/creator, provenance, license/consent, version, schema or media type, integrity digest, restrictions, expected consumer, and validation status. Keep examples distinct from normative specifications and empirical datasets. Do not claim a proposed asset exists until it has been bundled and audited.

## Dependencies

**Package/runtime dependencies.** This skill is a Markdown instruction module; no skill-specific executable runtime, package manager dependency, remote API, or MCP tool dependency is declared in the inspected plugin package. Invocation of tools or sources is conditional on access, authorization, and the question being asked.

**Cross-skill reasoning dependencies (invoke selectively, not automatically):**

- `skills/difference/SKILL.md` — feature distinctions; a **conceptual** dependency, not a required code import.
- `skills/similarity/SKILL.md` — matching/near-duplicate logic; a **conceptual** dependency, not a required code import.
- `skills/evaluation/SKILL.md` — absolute performance evidence; a **conceptual** dependency, not a required code import.
- `skills/judgement/SKILL.md` — uncertain comparative evidence; a **conceptual** dependency, not a required code import.
- `skills/priority/SKILL.md` — consequential action allocation; a **conceptual** dependency, not a required code import.

**Handoff contract.** Input: candidate universe, comparator criteria, evidence and objective. Output: ordered set with ties/uncertainty, rationale, validity checks and use limits.

**Dependency rules.** Preserve the ownership boundary between specialist skills; pass a stated purpose, definitions, provenance, constraints and confidence with every handoff. If a required skill, external source, authorization or test environment is unavailable, mark the gap rather than simulating evidence or claiming a test ran.

<!-- CONSTRUCT-SKILL-NOTES:END -->
