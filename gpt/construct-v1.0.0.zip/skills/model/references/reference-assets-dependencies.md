<!-- CONSTRUCT-SKILL-NOTES:BEGIN version=1 -->

## Reference Notes

**Reference scope.** Purposeful conceptual, causal, statistical, computational or engineering representations of reality.

- Foundational anchors: systems modeling, causal inference (Pearl and alternatives), statistical model criticism, verification/validation/uncertainty quantification and model risk management.
- Engineering anchors: assumptions logs, system boundaries, interfaces, calibration data, identifiability, sensitivity, uncertainty propagation, scenario testing and monitoring.
- Evidence rule: model adequacy is use-dependent; fitting historical observations alone neither proves mechanism nor guarantees distribution-shift robustness.

**Reference register convention.** For every cited claim, record source title/author or standards body, edition or release, persistent identifier/URL, access date when online, quoted passage or page/section, claim supported, evidence tier, and known counterevidence. External works mentioned here are **reading leads, not bundled or automatically verified citations**. Resolve authoritative editions before use.

## Assets Notes

**Existing package assets (verified against release `pluginrel_6ad31a9c75dc81918fe03685a5cd24bc`):**

- **Bundled local reference:** none specific to this skill was listed in the current release.
- **Shared branding only:** `assets/construct-icon.png` exists at plugin root. It is not evidence, a skill dataset, or a specialized analysis asset.
- **No other model-specific templates, data files, test corpora, schemas, or visualizations were found in the release file inventory.**

**Recommended assets to develop and validate:**

- **Proposed, not yet bundled:** model specification and assumptions register.
- **Proposed, not yet bundled:** structural/causal graph and parameter dictionary.
- **Proposed, not yet bundled:** test-data lineage, calibration and holdout policy.
- **Proposed, not yet bundled:** VVUQ/uncertainty test report and model card.
- **Proposed, not yet bundled:** operational monitoring and retirement checklist.

**Asset registration standard.** Every future file should carry purpose, source/creator, provenance, license/consent, version, schema or media type, integrity digest, restrictions, expected consumer, and validation status. Keep examples distinct from normative specifications and empirical datasets. Do not claim a proposed asset exists until it has been bundled and audited.

## Dependencies

**Package/runtime dependencies.** This skill is a Markdown instruction module; no skill-specific executable runtime, package manager dependency, remote API, or MCP tool dependency is declared in the inspected plugin package. Invocation of tools or sources is conditional on access, authorization, and the question being asked.

**Cross-skill reasoning dependencies (invoke selectively, not automatically):**

- `skills/information/SKILL.md` — data semantics/provenance; a **conceptual** dependency, not a required code import.
- `skills/format/SKILL.md` — machine-readable representation; a **conceptual** dependency, not a required code import.
- `skills/judgement/SKILL.md` — uncertainty assessment; a **conceptual** dependency, not a required code import.
- `skills/validity/SKILL.md` — fitness for purpose; a **conceptual** dependency, not a required code import.
- `skills/workflow/SKILL.md` — deployment and lifecycle control; a **conceptual** dependency, not a required code import.

**Handoff contract.** Input: target system, decision context, phenomena/data, assumptions and limits. Output: explicit model, test harness, uncertainty envelope, use conditions and monitoring plan.

**Dependency rules.** Preserve the ownership boundary between specialist skills; pass a stated purpose, definitions, provenance, constraints and confidence with every handoff. If a required skill, external source, authorization or test environment is unavailable, mark the gap rather than simulating evidence or claiming a test ran.

<!-- CONSTRUCT-SKILL-NOTES:END -->
