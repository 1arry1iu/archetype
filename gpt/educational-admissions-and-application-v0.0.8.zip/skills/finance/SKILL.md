---
name: finance
description: "Use for finance education, accounting and finance degrees, financial concepts, quantitative reasoning, career paths, and finance-specific admissions readiness. Consult references/finance-full-original-skill.md for the complete FIN-20 specification; use scholarships-and-financial-aid for education funding awards."
metadata:
  construct_id: "FIN-20"
  domain_group: "disciplinary_specialists"
  integration_appendix: "1.0.0"
  plugin: "educational-admissions-and-application"
  routing_role: "specialist"
---

# FINANCE (FIN-20)

The complete original finance skill content is preserved byte-for-byte as a supporting reference: `references/finance-full-original-skill.md`. Consult that document for domain-specific instructions and frameworks; apply the educational-admissions-and-application core skill for cross-domain coordination.

# SKILL INTEGRATION APPENDIX
*References, Assets, Dependencies, Interoperability,
and Evolution*

This is the integration contract for **Finance**. Its specialist domain is **Finance education, finance programs, financial literacy and quantitative program/career reasoning**. It supplements the original skill specification without replacing its instructions or evidentiary requirements. Inventories below describe files verified in the packaged release; the content of archived materials is not automatically authoritative or current.

## 1. REFERENCE NOTES
### 1.1 Reference Inventory
**Verified local reference inventory:** 3 file(s). All paths below are relative to `skills/finance/`; prefix with `skills/finance/` for plugin-root paths. Only these listed files are registered as existing:

- `references/finance-full-original-skill.md` — Complete FIN-20 original specification, retained as the substantive finance reference.
- `references/finance-knowledge-atlas.zip` — ZIP knowledge atlas for Finance concepts, relationship maps and source leads; consult for deeper topical exploration, not as a live policy source.
- `references/finance-profile.zip` — ZIP Construct profile for Finance sections, factors, capability hierarchy and associated representations; consult for detailed construct architecture.

### 1.2 Reference Descriptions and Purposes
**Domain coverage:** Finance education, finance programs, financial literacy and quantitative program/career reasoning. Use the Construct profile to expand designed factors and SOPs, the knowledge atlas to navigate topical concepts and research leads, and any source ledgers, crosswalks or schema files for their explicitly named support roles. Priority varies with the question; neither packaged source nor model implies current official requirements.

- `references/finance-knowledge-atlas.zip` contains, among other archived members, `finance-knowledge-atlas/ATLAS.md`, `finance-knowledge-atlas/VALIDATION.json`, `finance-knowledge-atlas/README.md`, `finance-knowledge-atlas/sources.csv`; these are ZIP members (not standalone plugin files).
- `references/finance-profile.zip` contains, among other archived members, `finance-profile/FIN-20_PROFILE.md`, `finance-profile/FIN-20_SOP.md`, `finance-profile/FIN-20_VALIDATION.json`, `finance-profile/README.md`; these are ZIP members (not standalone plugin files).

### 1.3 Reference Selection and Retrieval
First consult this `SKILL.md` for **finance education, finance programs, financial literacy and quantitative program/career reasoning**. Open a specific profile member only when a deeper capability, factor, example, or operating procedure is needed; open a specific atlas member only when a map, claim ledger or research pathway is needed. For official eligibility, procedures, costs, deadlines and legal status, verify separately against the current source for the institution, jurisdiction and intake. For ZIP files, inspect their member list and relevant README first; extract only selected members rather than loading both archives automatically.

### 1.4 Reference Relationships and Usage Rules
Reference precedence: (1) the current task and authoritative, dated, purpose-specific external rules for factual claims; (2) this skill’s governing instructions for method; (3) the original Construct profile and specialized SOP resources for conceptual detail; (4) knowledge atlases, examples and historical notes for background. Archive contents can contain repeated representations of the same model: deduplicate by claim identifier and provenance rather than counting formats as corroboration. Record the exact file/member path, version, date, citation and use restriction. `references/` is not `assets/`; a template found here is a reference-located exemplar, not proof that a separate asset exists.

## 2. ASSETS NOTES
### 2.1 Asset Inventory
- **Skill-local `assets/` inventory:** **none**. No files are registered under this skill’s `assets/` folder in the inspected release.
- **Existing shared plugin branding assets (plugin-root paths):** `assets/logo.png` and `assets/composer-icon.png`. Both are presentation artwork, not skill-local templates, schemas or evidence.

### 2.2 Asset Descriptions and Purposes
No skill-local template, reusable model, schema, dataset or fixture may be presumed to exist when the inventory is empty. Reusable-looking items inside a listed `references/` package remain reference materials until their intended role and usage rights are inspected. The shared logo and composer icon support plugin identification only. Do not repurpose branding as independent evidence or a decision tool.

### 2.3 Asset Selection and Usage
For a **finance-program and readiness analysis with explicit assumptions and numeric source checks**, first determine whether an existing registered asset matches the task; none is currently available locally unless newly added and verified. If no reusable asset matches, create the output for this particular task with explicit input fields, version, review status, assumptions and provenance. Confirm formats and any privacy, attribution, licensing or accessibility constraints before future reuse. Do not fabricate an asset path or claim a tool was run.

### 2.4 Asset Relationships and Usage Rules
Keep reference sources, user-provided materials, generated case outputs and shared branding in separate roles. A source-ledger file may substantiate a generated report; it does not become a validated production schema by virtue of being packaged. Add any future assets to `skills/finance/assets/` deliberately, document actual paths and expected I/O, and regression-test compatibility before registering them here.

## 3. DEPENDENCIES
### 3.1 Primary Skill Dependencies
**Primary collaborators (on demand, not hard imports):** `skills/program-fit/SKILL.md` (Program Fit); `skills/evidence/SKILL.md` (Evidence).
Primary means common division of expertise rather than a requirement to load another skill before this one can answer. Every skill remains directly invocable for its own narrow task.

### 3.2 Conditional Skill Dependencies
**Conditional collaborators:** `skills/business-analytics/SKILL.md` (Business Analytics); `skills/career/SKILL.md` (Career); `skills/scholarships-and-financial-aid/SKILL.md` (Scholarships And Financial Aid).
Invoke a conditional collaborator only when applicant level, jurisdiction, profession, funding, testing, research, recognition or document work is substantively present; pass the precise unresolved question, not an entire case by default.

### 3.3 Complementary Skills
**Complementary expertise:** `skills/graduate-admissions/SKILL.md` (Graduate Admissions); `skills/us-graduate-education/SKILL.md` (Us Graduate Education).
Complements can improve completeness and presentation but are never silently treated as prerequisites. Select only the smallest group of skills that changes the result materially.

### 3.4 Invocation and Boundary Rules
**This skill owns:** finance education, finance programs, financial literacy and quantitative program/career reasoning. **Boundary:** Finance subject expertise is not individualized regulated investment advice or verified fee/aid eligibility. Resolve overlap by the user’s primary decision first, then assign discrete subtasks according to domain ownership. `educational-admissions-and-application` coordinates genuinely multi-domain cases, but does not form a mandatory recursive dependency. `evidence` validates sources; `evaluation` judges merit against criteria; `judgement` handles uncertainty; `priority` orders actions; `workflow` manages process state. Do not substitute one for another. Conflicts require an explicit issue log and escalation to authoritative sources or the user, rather than circular invocation.

## 4. CROSS-SKILL HANDOFFS
### 4.1 Handoff Triggers
Handoff from **Finance** when the task crosses into a named collaborator’s scope, requires a jurisdiction- or program-specific interpretation that this skill cannot own, or needs independent evidence/method verification. Trigger with a clear unresolved claim or decision: for example, whether **finance education, finance programs, financial literacy and quantitative program/career reasoning** has implications for eligibility, authentic writing, funding, program fit, research or submissions.

### 4.2 Input and Output Contracts
**Required input:** objective, case stage, relevant school/program, country and intake (when known), applicant-approved facts, exact question, governing constraints, source identifiers, confidence and open uncertainties. Do not require personal information irrelevant to the subtask. **Expected output:** finance-program and readiness analysis with explicit assumptions and numeric source checks, plus a concise finding, referenced rules/assumptions, issue severity, recommended action, verification status and clearly named receiving owner. A handoff is an information transfer, not permission to perform external actions.

### 4.3 Information and Context Transfer
Use a compact shared record: `case_id` (pseudonymous if possible), `task_id`, `sender_skill`, `receiver_skill`, `decision_question`, `jurisdiction`, `intake`, `input_facts`, `source_ledger`, `assumptions`, `uncertainties`, `consent_limits`, `requested_output`, `status`, and `return_owner`. Preserve dates, units, quotes, applicant authorship, original file paths and contradictory evidence. Classify unverified statements as hypotheses; do not silently promote them to policy facts. Minimize sensitive data.

### 4.4 Coordination and Responsibility Rules
The originating skill owns its scoped deliverable and defines acceptance criteria; the receiving skill owns only the delegated specialist analysis. The EAA central skill may consolidate across pathways; `workflow` may track handoff state. External submission, contact, edits to third-party records or disclosure of applicant documents require separate authorization. Conflicting interpretations remain visible with source/version until resolved by appropriate authority; no infinite bidirectional delegation.

### 4.5 Completion and Return Conditions
Return when the requested output is supplied with source paths, assumptions and remaining gaps, or when work is blocked with a precise reason and responsible next party. Mark each handoff `complete`, `qualified`, or `blocked`; do not claim completion based on an unanswered request. The originating skill reconciles the received result with its own scope, records unresolved differences and returns control to the user for final educational decisions.

## 5. MAINTENANCE & EVOLUTION
### 5.1 Version and Change Management
This integration convention accompanies plugin version **0.0.7** (appendix revision **1.0**, 27 October 2026); the original Construct profile edition inside the skill is unchanged and is not superseded. Track content and resource changes in plugin-root `INTEGRATION_CHANGELOG.md`, with modified paths, motivations, reviewers when known and rollback information. Keep manifest versions synchronized; do not retrospectively rewrite historical profile dates.

### 5.2 Reference and Asset Synchronization
On release, re-enumerate `skills/finance/references/` and `skills/finance/assets/`, validate all listed paths and file hashes, reconcile ZIP member changes and refresh descriptions only for verified files. Shared brand artwork is checked under plugin-root `assets/`. Mark proposed resources as `PROPOSED — NOT PACKAGED`, never as available. Remove or quarantine stale path references and document replacement paths.

### 5.3 Dependency Compatibility
Retest listed cross-skill names, trigger rules, I/O record fields and ownership boundaries whenever a collaborator is renamed, revised, retired or extended. No mandatory cycles are permitted; optional peers may depend on each other conceptually without recursive auto-invocation. Maintain compatibility of provenance, consent and uncertainty fields as schemas evolve.

### 5.4 Integrity and Consistency Checks
Check for exactly one final `# SKILL INTEGRATION APPENDIX`, the complete five-section / 22-subsection order, valid relative paths, correct filename case, readable frontmatter, UTF-8 encoding and a skill file size below 1 MiB. Compare the pre-appendix original specification byte-for-byte with the baseline; validate that archives and all unchanged binary resources are preserved. Confirm no nonexistent icon, data source, schema or tool is represented as installed. Distinguish structural QA from evidence of outcomes or professional certification.

### 5.5 Continuous Improvement and Evolution
Review interoperability after representative single-skill and multi-skill cases, catalog false handoffs and missing contexts, update only affected inventory and dependency entries, and record regression findings. Favor selective reference loading, accessible outputs, reproducible source links and applicant agency. When requirements or policies change, prioritize new authoritative evidence and controlled revisions over inherited Construct assertions.
