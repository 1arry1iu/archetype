<!-- CONSTRUCT-SKILL-NOTES:BEGIN version=1 -->

## Reference Notes

**Reference scope.** Assessment and probability calibration under uncertainty before action.

- Anchors: Bayesian updating, proper scoring rules (including Brier/log scores), structured expert judgement, forecasting tournaments, signal detection and causal reasoning.
- Debiasing anchors: reference classes, independent estimates, premortems, disconfirmation, calibration plots and sensitivity to priors.
- Evidence rule: separate evidence strength from decision preference, distinguish aleatory and epistemic uncertainty, and retain probabilities/intervals with assumptions.

**Reference register convention.** For every cited claim, record source title/author or standards body, edition or release, persistent identifier/URL, access date when online, quoted passage or page/section, claim supported, evidence tier, and known counterevidence. External works mentioned here are **reading leads, not bundled or automatically verified citations**. Resolve authoritative editions before use.

## Assets Notes

**Existing package assets (verified against release `pluginrel_6ad31a9c75dc81918fe03685a5cd24bc`):**

- **Bundled local reference:** none specific to this skill was listed in the current release.
- **Shared branding only:** `assets/construct-icon.png` exists at plugin root. It is not evidence, a skill dataset, or a specialized analysis asset.
- **No other judgement-specific templates, data files, test corpora, schemas, or visualizations were found in the release file inventory.**

**Recommended assets to develop and validate:**

- **Proposed, not yet bundled:** forecast and judgement ledger with outcome resolution.
- **Proposed, not yet bundled:** evidence weight, prior and alternative-hypothesis table.
- **Proposed, not yet bundled:** calibration and scoring dashboard.
- **Proposed, not yet bundled:** red-team/independent-judgement template.

**Asset registration standard.** Every future file should carry purpose, source/creator, provenance, license/consent, version, schema or media type, integrity digest, restrictions, expected consumer, and validation status. Keep examples distinct from normative specifications and empirical datasets. Do not claim a proposed asset exists until it has been bundled and audited.

## Dependencies

**Package/runtime dependencies.** This skill is a Markdown instruction module; no skill-specific executable runtime, package manager dependency, remote API, or MCP tool dependency is declared in the inspected plugin package. Invocation of tools or sources is conditional on access, authorization, and the question being asked.

**Cross-skill reasoning dependencies (invoke selectively, not automatically):**

- `skills/knowledge/SKILL.md` — source quality and unknowns; a **conceptual** dependency, not a required code import.
- `skills/validity/SKILL.md` — validate predictive and inferential uses; a **conceptual** dependency, not a required code import.
- `skills/evaluation/SKILL.md` — judge quality only when criteria apply; a **conceptual** dependency, not a required code import.
- `skills/priority/SKILL.md` — handoff assessments to resource decisions; a **conceptual** dependency, not a required code import.
- `skills/question/SKILL.md` — choose highest-value uncertainty reductions; a **conceptual** dependency, not a required code import.

**Handoff contract.** Input: proposition, horizon, evidence, priors and reference class. Output: calibrated conclusion, competing hypotheses, uncertainty and revision trigger.

**Dependency rules.** Preserve the ownership boundary between specialist skills; pass a stated purpose, definitions, provenance, constraints and confidence with every handoff. If a required skill, external source, authorization or test environment is unavailable, mark the gap rather than simulating evidence or claiming a test ran.

<!-- CONSTRUCT-SKILL-NOTES:END -->
