# Release history and refresh protocol

- **2026-10-27 / v1.0:** First research synthesis. 35 publicly verifiable official/authoritative entry points; 18-chapter atlas; multi-level taxonomy; purpose/authority decision logic; jurisdiction routing; workflows; counterexample casebook; frontier agenda; editable templates; offline HTML.

## Triggers for a new version

1. UNESCO Global or regional convention ratification, entry into force, implementation or authoritative interpretation.
2. EU recognition or professional qualification rules changes, including automatic recognition and microcredential policy.
3. National credential agencies' rules, designated evaluators, eligibility and report validity changes.
4. Accreditation or recognized issuer status for a case's award period.
5. Digital credential specifications, signing / revocation infrastructures or identified security vulnerabilities.
6. New expert adjudication evidence that refutes a generic equivalence inference, materiality threshold or automated tool reliability.

## Required change record

For each update: URL + archived/retrieved date, source version, claim identifier, old statement, revised statement, validity period, responsible editor, change rationale, review evidence and whether previously issued guidance must be corrected. Never silently rewrite an old determination to pretend its original version was accurate.
