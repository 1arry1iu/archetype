# Casebook — Counterexamples That Challenge Shallow Equivalency

Fictional educational scenarios. These **do not** decide any real person's credential or predict an authority's decision. They expose one inference error each.

| ID | Scenario | Tempting but invalid shortcut | More defensible decision process | Authority/source |
|---|---|---|---|---|
| C01 | A recognized foreign bachelor's is presented for a U.S. master's application | foreign bachelor = automatic master's admission | verify school's preferred evaluator; admission criteria, prerequisites and selection separate | US institution [S11] |
| C02 | A foreign degree's name translates to “Master” but training is a one-year post-secondary short qualification | title alone fixes level | use home-system position, entry requirements, outcomes and progression | institutional evaluator [S14][S19] |
| C03 | Degree issued by a college that lost accreditation in 2024, award dated 2018 | current nonaccreditation voids all old awards | historical issuer and program status at award date, transition arrangements | appropriate national authority [S19][S21] |
| C04 | ECTS module appears similar to a U.S. major course | numerical credits alone ensure course transfer | compare outcomes, level, lab/placement, policy and prerequisites | receiving institution [S08] |
| C05 | An applicant provides an IRCC-approved ECA for foreign nursing school | immigration assessment grants nursing licensure | verify province, regulator, tests and clinical requirements | licensing authority [S15] |
| C06 | Signed European Digital Credential from an unfamiliar provider | signature means recognized university award | validate issuer's degree-awarding powers and relevant education system | recipient + regulator [S27][S28] |
| C07 | A refugee's university archive was destroyed | missing original means no prior study | permitted structured alternative evidence and interview; state uncertainty | receiver/EQPR-informed process [S26] |
| C08 | Two ASEAN systems reference level 6 | all national level 6 awards fully substitute | compare target qualification profile; national body retains decision | national authority [S25] |
| C09 | UK ENIC confirms degree level; employer asks for GPA | level statement provides grade conversion | obtain official native grading key and approved interpretation | recipient [S13] |
| C10 | ZAB comparability statement submitted as German medical license | ZAB grants practice | investigate regulated health profession authority and specific legal route | Germany regulator [S20] |
| C11 | Undergraduate diploma from online branch campus in another country | teaching campus country is necessarily award country | establish awarding institution, branch authorization and QA scope in study period | host/source authorities [S01][S19] |
| C12 | U.S.-style course credits used to claim ECTS in Europe | constant universal conversion ratio | disclose institutional normalization assumptions and target recognition rules | receiving institution [S08] |
| C13 | A stack of online course certificates is presented as a master's degree | summed training hours = awarded master's | examine explicit provider stacking agreements, awarding powers, assessments | recipient [S29] |
| C14 | EU higher-education automatic recognition is interpreted as guaranteed admission to competitive MSc | procedural access = selection success | qualification-access rule and program-specific requirements remain distinct | admissions institution [S09] |
| C15 | A professional licence issued in country A is claimed to authorize work everywhere | professional licences are globally interchangeable | establish occupation and applicable destination reciprocity/directive/MRA conditions | destination regulator [S10] |
| C16 | An evaluator identifies likely strong prior learning but documentation conflicts | choose binary pass/fail from uncertain data | issue pending or conditional evaluation, ask proportionate clarification and allow correction | competent authority [S05][S26] |

## Adversarial validation cases

1. **Same name, different issuer:** separate institutional identity from translated brand name.
2. **Same issuer, program not approved:** check program-level standing and study mode.
3. **Same NQF level, different competency:** reject naive level-only transfer.
4. **Valid digital proof, revoked award:** enforce current status verification.
5. **True qualification, wrong owner:** confirm identity binding.
6. **False institution website:** cross-check regulator registry instead of candidate-supplied link alone.
7. **Refugee inaccessible source registrar:** do not equate information unavailability with adverse authenticity finding.
8. **Language-dependent AI extraction:** preserve original-language phrase; provide second-language human check.
9. **New law applied to old award:** inspect transition/effective-date clauses.
10. **Appeal reversal after missing syllabus found:** revisit substantive recognition and downstream credit, log versions.
