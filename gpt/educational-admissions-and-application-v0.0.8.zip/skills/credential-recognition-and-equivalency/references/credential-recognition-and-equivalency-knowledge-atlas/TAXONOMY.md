# CRE-26 — Hierarchical Atlas of Constructs

A map of topics, not a claim that a qualification is equivalent. Sections contain factor → subfactor → sub-subfactor (facets).

## CRE.S01: Conceptual foundations
*Meaning, identity, purpose and decision boundaries*  
Sources: S01, S04, S06

### CRE.S01.F01: Ontology and referents
- **Credential**: artifact · attestation
- **Qualification**: system-recognized learning · awarding right
- **Award**: individual attainment · date
- **Evidence**: document · provenance

### CRE.S01.F02: Comparison claims
- **Identity**: same record · same award
- **Similarity**: feature overlap · graduated match
- **Equivalence**: reference frame · materiality
- **Substitutability**: intended purpose · conditions

### CRE.S01.F03: Authority and purpose
- **Academic access**: general eligibility · selection criteria
- **Credit transfer**: course outcomes · residency
- **Employment**: employer policy · occupation
- **Professional practice**: legal entitlement · registration

### CRE.S01.F04: Levels of assertion
- **Verified**: source confirmation · scope
- **Compared**: target system · limitations
- **Decided**: named authority · effective date
- **Appealable**: reasons · review route

## CRE.S02: Normative regimes
*Treaties, legislation, recommendations and institutional sovereignty*  
Sources: S01, S02, S03, S09

### CRE.S02.F01: International legal basis
- **Convention applicability**: party · entry into force
- **Principles**: fairness · transparency
- **Rights**: information · appeal
- **Limits**: specific qualifications · domestic law

### CRE.S02.F02: Regional recognition
- **Lisbon**: substantial difference · information centres
- **Tokyo**: Asia-Pacific · transparency
- **Addis**: African mobility · implementation
- **Buenos Aires**: Latin American cooperation · party status

### CRE.S02.F03: Domestic rules
- **National law**: degree authority · recognition mandate
- **Autonomous institutions**: selection · credit policy
- **Sector standards**: profession-specific tests · protected titles
- **Immigration law**: visa category · designated report

### CRE.S02.F04: Source hierarchy
- **Binding text**: current version · statutory reach
- **Regulator guidance**: procedure · exemptions
- **University requirements**: accepted evaluator · program prerequisites
- **Advisory report**: scope · reliance limits

## CRE.S03: Home-system validation
*Authentic standing at date of award*  
Sources: S14, S19, S21

### CRE.S03.F01: Issuer status
- **Legal identity**: names · mergers
- **Awarding powers**: jurisdiction · dates
- **Program authorization**: field · level
- **Quality assurance**: national agency · scope

### CRE.S03.F02: Historical status
- **Enrollment time**: registration · regulation
- **Award time**: permission · accreditation
- **Program history**: restructuring · teach-out
- **Archived evidence**: registries · catalogs

### CRE.S03.F03: Transnational provision
- **Branch campus**: physical location · host approval
- **Franchise**: teaching partner · awarding body
- **Joint award**: multiple signatories · governing agreements
- **Distance mode**: legal permission · quality model

### CRE.S03.F04: Credential category
- **Academic degree**: bachelor · master
- **Vocational award**: occupation · level
- **Research degree**: thesis · doctoral scope
- **Honorary award**: not earned · non-equivalence

## CRE.S04: Authenticity and integrity
*Trust in documents, issuers and record linkage*  
Sources: S19, S27, S28

### CRE.S04.F01: Identity linkage
- **Holder identity**: name variants · ID
- **Consent**: recipient scope · data minimization
- **Duplicate names**: disambiguation · aliases
- **Post-award changes**: legal name · issuer rename

### CRE.S04.F02: Document verification
- **Direct issuer confirmation**: registry · registrar
- **Transcript evidence**: seal · secure delivery
- **Translation**: qualified translator · source original
- **Revocation**: status · issuance history

### CRE.S04.F03: Digital assurance
- **Signature validation**: key chain · tamper
- **Issuer reputation**: recognized institution · authorization
- **Credential subject**: holder match · stable ID
- **Presentation privacy**: selective disclosure · correlation risk

### CRE.S04.F04: Fraud and error
- **Forgeries**: altered grades · manufactured papers
- **Diploma mills**: phony licensing · rapid awards
- **Registry compromise**: revoked keys · fake websites
- **False positives**: biased profiling · procedural remedy

## CRE.S05: Academic architecture
*Degree structure, award rights and learning progression*  
Sources: S04, S14, S19

### CRE.S05.F01: Qualification level
- **Framework level**: national reference · EQF or AQRF
- **Academic cycle**: short cycle · bachelor
- **Graduate cycle**: master · doctorate
- **Research intensity**: thesis · research credit

### CRE.S05.F02: Entry and progression
- **Entry qualifications**: prior award · bridging
- **Rights in source system**: further study · profession
- **Terminal versus transfer**: exit award · progression
- **Top-up structures**: advanced entry · stacked credit

### CRE.S05.F03: Curriculum and outcomes
- **Discipline depth**: core content · advanced theory
- **Breadth**: general education · electives
- **Research methods**: statistics · epistemology
- **Laboratory and clinical**: hands-on learning · supervision

### CRE.S05.F04: Assessment
- **Examination**: stakes · proctoring
- **Projects**: authorship · standard
- **Dissertation**: originality · defense
- **Learning outcomes**: actual assessed competence · syllabus claims

## CRE.S06: Substantial differences
*Material obstacles assessed in light of target purpose*  
Sources: S04, S05, S06

### CRE.S06.F01: Comparative frame
- **Desired activity**: study · employment
- **Reference qualification**: required level · content
- **Sufficient outcomes**: core requirements · preparedness
- **Local context**: law · professional safety

### CRE.S06.F02: Difference types
- **Input difference**: duration · study mode
- **Output difference**: missing competence · depth
- **Status difference**: unrecognized program · award rights
- **Legal difference**: mandatory hours · protected title

### CRE.S06.F03: Materiality and evidence
- **Causal relevance**: target success · legal requirement
- **Burden of reasons**: documented obstacle · trace
- **Proportionality**: least restrictive response · alternatives
- **Counterfactual**: if gap bridged · if record recovered

### CRE.S06.F04: Remedial outcomes
- **Partial recognition**: usable prior learning · remaining gap
- **Conditional admission**: prerequisites · deadline
- **Bridging**: course · exam
- **Reassessment**: new evidence · appeal

## CRE.S07: Grades and performance
*Context-sensitive interpretation of achievement*  
Sources: S08, S13

### CRE.S07.F01: Scale provenance
- **Native scale**: boundaries · grade legend
- **Cohort context**: distribution · honors
- **Time series**: historical scale · policy shift
- **Institutional policy**: GPA approach · minimum

### CRE.S07.F02: Cross-scale evidence
- **Percentile**: data quality · comparability
- **Class of award**: degree classification · threshold
- **GPA estimate**: evaluator-specific method · precision
- **Rounding**: institution rules · uncertainty

### CRE.S07.F03: Distortions
- **Scale compression**: high-mark rarity · top grade
- **Grade inflation**: cohort drift · policy
- **Pass-fail**: missing ranking · assessment quality
- **Subject heterogeneity**: discipline · course difficulty

### CRE.S07.F04: Communication
- **Original grades preserved**: no overwrite · source label
- **Indicative interpretation**: not official conversion · caveat
- **Transcript annotations**: missing · withdrawn
- **Appeals**: calculation error · policy mismatch

## CRE.S08: Credits and academic transfer
*Learning outcomes, workload and accepted exemptions*  
Sources: S08, S16

### CRE.S08.F01: Credit systems
- **ECTS**: workload · outcomes
- **Semester credits**: local policy · contact time
- **National credits**: program structure · conversion law
- **Noncredit learning**: RPL · challenge exam

### CRE.S08.F02: Course mapping
- **Syllabi**: topic coverage · edition
- **Learning outcomes**: cognitive level · assessment
- **Lab and placement**: time · competence
- **Currency**: recent field changes · prerequisite

### CRE.S08.F03: Transfer constraints
- **Residency requirement**: minimum credits · capstone
- **Transfer maximum**: institution policy · degree share
- **Grade threshold**: minimum passing · repeat
- **Sequence**: prerequisite chain · corequisite

### CRE.S08.F04: Articulations
- **Formal agreement**: partner institutions · dates
- **Block transfer**: pathway level · credit package
- **Course-by-course**: granular matching · electives
- **Reverse transfer**: credentials earned · home agreement

## CRE.S09: Country and region intelligence
*Jurisdiction-specific routing and authority*  
Sources: S11, S13, S15, S17, S18, S20, S22, S23, S24, S25

### CRE.S09.F01: North America
- **United States**: institution · private evaluation
- **Canada admissions**: institution autonomy · transfers
- **Canada immigration**: IRCC ECA · designated bodies
- **Professional regulators**: province · state

### CRE.S09.F02: Europe
- **United Kingdom**: UK ENIC · recipient
- **Germany**: ZAB · anabin
- **Other Europe**: ENIC-NARIC · local authority
- **EU regulated professions**: Directive 2005/36/EC · contact point

### CRE.S09.F03: Asia-Pacific
- **Australia**: provider admission · skills assessor
- **New Zealand**: NZQA IQA · visa policy
- **India**: UGC 2025 · sector bodies
- **China**: CSCSE · domestic use

### CRE.S09.F04: Africa and ASEAN
- **South Africa**: SAQA · NQF
- **ASEAN**: AQRF · national decision
- **Africa regional**: Addis · state-party check
- **Latin America**: Buenos Aires · implementation

## CRE.S10: Immigration and employment
*Purpose-specific rights and administrative evidence*  
Sources: S11, S15, S17, S35

### CRE.S10.F01: Immigration categories
- **Points-based**: ECA validity · designation
- **Skilled visa**: skills assessing authority · occupation
- **Job-sponsored**: employer requirement · regulator
- **Academic visa**: admission evidence · visa rules

### CRE.S10.F02: Employer recognition
- **Nonregulated jobs**: employer discretion · job fit
- **Public service**: degree level proof · eligibility
- **HR screening**: credential labels · fairness
- **Collective rules**: profession-specific · contractual

### CRE.S10.F03: Regulated practice
- **Title protection**: legal definition · registration
- **Exams**: local knowledge · competence
- **Supervised work**: placement · hours
- **Language and ethics**: patient safety · professional fitness

### CRE.S10.F04: Separability
- **Credential ECA**: immigration only · report date
- **Academic comparability**: level only · conditions
- **License**: practice rights · jurisdiction
- **Visa**: immigration status · work limits

## CRE.S11: Nonformal and emerging credentials
*Recognition beyond conventional full-time degrees*  
Sources: S01, S29

### CRE.S11.F01: Microcredentials
- **Issuer standing**: recognized provider · QA
- **Learning outcome**: competence · assessment
- **Workload**: hours · credit
- **Stackability**: published articulation · limit

### CRE.S11.F02: RPL and experiential
- **Work evidence**: job tasks · portfolio
- **Competence assessment**: challenge · demonstration
- **Informal learning**: validation method · access
- **Safeguards**: equal opportunity · audit

### CRE.S11.F03: Online and flexible
- **Distance programs**: program authorization · assessment
- **MOOCs**: completion versus assessed skill · issuer
- **Bootcamps**: training versus award · employment
- **Hybrid delivery**: placement requirements · mode approval

### CRE.S11.F04: Partial and alternative
- **Incomplete study**: credit record · no earned degree
- **Foundation year**: access pathway · progression
- **Apprenticeship**: national vocational status · occupation
- **Military education**: accreditation · credit recommendations

## CRE.S12: Refugee and disrupted education
*Fair evaluation where standard proof is unsafe or unavailable*  
Sources: S01, S26

### CRE.S12.F01: Evidence reconstruction
- **Available records**: photos · course evidence
- **Structured interview**: domain expert · triangulation
- **Competence demonstration**: skills test · challenge
- **Missing evidence**: inference limit · confidence

### CRE.S12.F02: Safety and dignity
- **Contact risk**: unsafe issuer approach · consent
- **Trauma-informed interview**: language · accommodation
- **Avoiding discrimination**: nationality proxy · fairness
- **Data minimization**: confidentiality · retention

### CRE.S12.F03: Recognition pathways
- **EQPR**: assessment format · nonbinding
- **Conditional access**: bridging · provisional study
- **National alternatives**: legislation · exemptions
- **Appeal**: new records · reconsideration

### CRE.S12.F04: Uncertainty protocol
- **Verified**: issuer proof · document
- **Corroborated**: independent sources · consistency
- **Self reported**: testable narrative · scope
- **Not established**: missing proof · not negative identity

## CRE.S13: Professional sectors
*Profession-specific educational and legal gateways*  
Sources: S10, S15, S17

### CRE.S13.F01: Health professions
- **Medicine**: degree · safe practice
- **Nursing**: clinical hours · regulator
- **Dentistry**: skill assessment · scope
- **Pharmacy**: training · registration

### CRE.S13.F02: Law and regulated care
- **Law**: local jurisdiction · bar
- **Psychology**: protected acts · graduate training
- **Social work**: regulatory scope · placements
- **Counseling**: state protection · supervision

### CRE.S13.F03: Engineering and design
- **Engineering**: professional engineer · licensure
- **Architecture**: protected title · practice
- **Surveying**: local land law · license
- **Skilled trades**: apprenticeship · competence

### CRE.S13.F04: Education and finance
- **Teaching**: teacher registration · pedagogy
- **Accounting**: professional exams · statutory audit
- **Actuarial**: membership · exam
- **Aviation**: license · flight hours

## CRE.S14: Decisions and appeals
*Human-governed conclusions, reasons and rights*  
Sources: S01, S05, S11

### CRE.S14.F01: Case intake
- **Intended purpose**: named use · destination
- **Recipient mandate**: legal authority · accepted provider
- **Document request**: proportionate · clear
- **Consent**: necessary purpose · sharing

### CRE.S14.F02: Case determination
- **Verification result**: source evidence · uncertainty
- **Comparability findings**: dimensions · reference
- **Gap explanation**: material · remediable
- **Outcome**: recognized · conditional

### CRE.S14.F03: Procedural justice
- **Written reasons**: rule · evidence
- **Appeal avenue**: deadline · authority
- **Corrections**: document · calculation
- **Accessibility**: language · accommodation

### CRE.S14.F04: Case lifecycle
- **Versioning**: decision date · rule edition
- **Supersession**: new law · new evidence
- **Retention**: schedule · privacy
- **Audit**: random checks · disparity

## CRE.S15: Data and knowledge engineering
*Semantics, provenance, graphs and computable contracts*  
Sources: S07, S25, S27

### CRE.S15.F01: Identifiers
- **Issuer ID**: namespace · authority
- **Credential ID**: award key · privacy
- **Framework ID**: jurisdiction · version
- **Decision ID**: recipient · timestamp

### CRE.S15.F02: Data model
- **Claim**: subject · predicate
- **Evidence**: artifact · locator
- **Mapping**: source and target · conditions
- **Decision**: scope · effect

### CRE.S15.F03: Crosswalk validity
- **One-to-many**: alternatives · profiles
- **Nontransitivity**: chain risk · local law
- **Historic versions**: valid-from · valid-to
- **Conflict handling**: opposed sources · review

### CRE.S15.F04: Machine action
- **Extraction**: assistive OCR/LLM · uncertainty
- **Verification**: seal · registry
- **Human decision**: sign-off · appeal
- **Audit**: reproducibility · provenance

## CRE.S16: Digital credentials
*Issuer/verifier ecosystems and trust limitations*  
Sources: S27, S28

### CRE.S16.F01: Technical standards
- **VC data model**: issuer · subject
- **Secure proof**: integrity · signer
- **Credential status**: revocation · expiry
- **Schema**: machine readable · semantics

### CRE.S16.F02: Educational semantics
- **Learning activities**: duration · mode
- **Achievements**: outcomes · assessment
- **Entitlements**: declared rights · scope
- **Accreditation claims**: jurisdiction · issuer

### CRE.S16.F03: Privacy and security
- **Selective disclosure**: data minimization · unlinkability
- **Key compromise**: rotation · recovery
- **Cross-service tracking**: correlation metadata · consent
- **Offline verification**: staleness · trust

### CRE.S16.F04: Evaluation
- **Cryptographic success**: signature not truth · issuer risk
- **Trust policy**: authorized issuer · valid award
- **Destination mapping**: academic comparability · regulator
- **Adversarial cases**: fraud · revocation

## CRE.S17: Fairness and human rights
*Unbiased access and proportionate assessment*  
Sources: S01, S26, S27

### CRE.S17.F01: Anti-discrimination
- **Country-of-origin bias**: stereotypes · proxy variables
- **Language barriers**: translation · access
- **Disability**: accessible process · reasonable measures
- **Economic burden**: fees · financial access

### CRE.S17.F02: Procedural rights
- **Notice**: requirements · missing items
- **Explanation**: substantial differences · authority
- **Appeal**: independent route · correction
- **Data rights**: access · retention

### CRE.S17.F03: Bias measurement
- **Acceptance disparity**: case mix · denominators
- **False denial**: later reversal · appeal
- **Processing time**: language · country
- **Automation drift**: model changes · thresholds

### CRE.S17.F04: Human oversight
- **Competent evaluator**: training · authority
- **Independent check**: conflict of interest · review
- **Redress**: reopen · remedy
- **Transparency**: evaluation criteria · uncertainty

## CRE.S18: Governance and quality
*Institutional SOPs, competence and trustworthy operations*  
Sources: S04, S14, S19

### CRE.S18.F01: Decision ownership
- **Applicant**: good faith · accurate records
- **Awarding institution**: issuer confirmation · accuracy
- **Evaluator**: method · reason
- **Recipient**: actual outcome · appeal

### CRE.S18.F02: Service quality
- **Timeliness**: published targets · exceptions
- **Consistency**: interrater checks · benchmark
- **Traceability**: source references · logs
- **Accuracy**: audit samples · corrections

### CRE.S18.F03: Risk management
- **Fake claims**: fraud response · due process
- **Information errors**: stale registry · fix
- **Privacy incident**: containment · notification
- **Regulatory update**: change management · legal review

### CRE.S18.F04: Indicators
- **Quality metrics**: false positive · false negative
- **Access metrics**: fee burden · appeals
- **Outcome metrics**: student success · professional safety
- **Drift metrics**: mapping changes · source updates

## CRE.S19: Research methods and evidence
*Disciplined inquiry, validation and falsification*  
Sources: S04, S27

### CRE.S19.F01: Source methodology
- **Primary texts**: law · regulator
- **Evidence triangulation**: registries · issuer
- **Temporal capture**: snapshots · dates
- **Publication integrity**: version · provenance

### CRE.S19.F02: Empirical design
- **Case audit**: decision samples · consent
- **Comparative study**: matched cases · legal variation
- **Process experiment**: human versus AI · errors
- **Causal inference**: selection bias · confounders

### CRE.S19.F03: Validity tests
- **Construct**: purpose-specific meaning · coverage
- **Predictive**: success in destination · confounding
- **Procedural**: appeals · explanations
- **External**: other institutions · years

### CRE.S19.F04: Uncertainty
- **Unknown policy**: recheck · abstain
- **Missing evidence**: do not invent · alternatives
- **Conflicting sources**: recency · authority
- **Sparse outcomes**: qualify · monitor

## CRE.S20: Frontier experiments
*Tested innovation without conferring unearned authority*  
Sources: S09, S25, S27, S28, S29

### CRE.S20.F01: Graph interoperability
- **Multi-jurisdiction map**: ontology · temporal edges
- **Reciprocal trust**: credential assurance · governance
- **Automated crosswalk**: bounded similarity · nontransitivity
- **Longitudinal updates**: diff · provenance

### CRE.S20.F02: AI-assisted recognition
- **Structured extraction**: citation linked · review
- **Materiality assessment**: target criterion · test
- **Uncertainty abstention**: human fallback · safe threshold
- **Bias testing**: languages · jurisdictions

### CRE.S20.F03: Privacy-preserving access
- **Selective predicates**: threshold proof · issuer
- **Wallet portability**: format · trust registry
- **Offline assurance**: revocation lag · expiry
- **Anti-correlation**: metadata minimization · unlinkability

### CRE.S20.F04: Alternative validation
- **Refugee pathway**: interviews · performance
- **Skills transcript**: granular outcomes · QA
- **Competence portfolio**: evidence weight · authenticity
- **Lifelong stack**: credit contract · ceiling

## CRE.S21: SOPs and usable tools
*Operational routing, templates and release gates*  
Sources: S04, S11, S15, S17

### CRE.S21.F01: Applicant SOP
- **Choose target**: purpose · body
- **Ask requirements**: report type · vendor
- **Assemble documents**: transcript · syllabi
- **Confirm rights**: appeal · conditions

### CRE.S21.F02: Evaluator SOP
- **Establish system**: award date · authority
- **Verify evidence**: issuer · chain
- **Analyze differences**: learning outcomes · purpose
- **Report**: limits · rationale

### CRE.S21.F03: Institution SOP
- **Publish policy**: requirements · scope
- **Train assessors**: consistency · materials
- **Provide remedy**: bridge · appeal
- **Govern updates**: version · independent review

### CRE.S21.F04: Release QA
- **Source complete**: URLs · dates
- **Internal validity**: cross-references · schema
- **Safety check**: no false entitlement · no discrimination
- **Packaging**: reproducible checksums · manifest

