# Frontier and Research Agenda — Credential Recognition and Equivalency

**Evidence cut-off: 27 October 2026.** The frontier here means *current practical developments plus open scientific and institutional problems*. It does **not** claim that every proposal is a deployed standard or validated policy. Anchor references appear as IDs in `source_ledger.csv`.

## Level 1: Normative and operational advances with clear primary-source anchors

- The UNESCO Global Convention has been in force since **5 March 2023** and a UNESCO update reports **42 States Parties in July 2026**; domestic implementation, scope and new ratifications must be checked before case use. **Anchor:** S01–S03. **Boundary:** procedural rights ≠ guaranteed recognition in any destination.
- The **2025 W3C Verifiable Credentials Data Model v2.0** is a formal technical Recommendation. Issuer authentication and tamper-evidence are advances in format/trust infrastructure, not a demonstration that learning outcomes are true. **Anchor:** S27.
- The EU's **European Digital Credentials for Learning** supports verified digital educational records, while education authority and program quality assurance remain a separate inquiry. **Anchor:** S28.
- EU microcredential policy dating from **2022** provides a policy vocabulary for flexible learning claims, but stackability/credit remains conditional. **Anchor:** S29.
- **India's UGC regulation index** lists the foreign-qualification recognition/equivalence regulation dated **4 April 2025**. A 2026 regulatory change inquiry is plausible, but the atlas does not assume the complete operative text or exemptions from an index alone. **Anchor:** S23. Check the final gazetted text and sectoral authorities for all real decisions.
- The **Revised Arab States convention** is listed by UNESCO as entering into force in **2026**; specific state-party and operative dates remain case-dependent. **Anchor:** S03.

## Level 2: Researchable bottlenecks and study designs

| ID | Question and potential innovation | Hypothesis requiring testing | Suggested design | Success criterion | Most important failure mode |
|---|---|---|---|---|---|
| F01 | Historical accreditation ledger | Time-indexed registry improves true validity decisions | compare ordinary vs time-annotated review on historical cases | fewer erroneous negative/positive recognition claims | incomplete historic registry, false certainty |
| F02 | Evidence-grounded AI triage | Assisted extraction reduces workload without increasing harmful mistakes | preregistered blinded comparison of trained humans alone vs humans plus retrieval and model | unchanged/improved false denial, minutes saved, explanation completeness | hallucinated national law or biased proxy |
| F03 | Cross-framework graph | Provenance-aware mappings yield better referral accuracy | matched use cases across country frameworks, with explicit nontransitivity | higher correct routing and abstention | transitive-overreach and level absolutism |
| F04 | Refugee alternatives | structured interview + portable learning test improves access | longitudinal cohort comparison with ethical consent and independent reviewers | greater completion of case decisions and comparable subsequent success | retraumatization, fraud overreach, uneven access |
| F05 | Privacy-preserving prerequisites | selective-disclosure predicate can reduce data exposure | pilot limited to a named curriculum requirement | fewer disclosed fields without worse verification errors | correlation metadata, signer revocation, coercive demand |
| F06 | Microcredential articulation | published stack contracts improve valid credit recognition | program-level quasi-experiment on disclosed crosswalks | increase in accurate credit awarded and learner completion | volume of hours substituted for quality |
| F07 | Fairness in credential evaluation | transparent materiality standards reduce arbitrary country-origin effects | blinded vignettes with equal outcomes, varied country labels | lower unsupported outcome variance | hidden evaluator stereotypes, legal differences ignored |
| F08 | Regulator/licensing modularity | common evidence packet reduces repeated document burdens | multi-authority trial for same profession (where lawful) | lower repeat costs without compromising regulation | cross-jurisdictional consent failures |
| F09 | Revocation-aware digital credentials | real-time credential-status checks reduce acceptance of invalid claims | red-team credential verification scenarios | detect expired/revoked/impostor docs with low error | offline staleness, private data leakage |
| F10 | Outcome validity of recognition | recognition decisions should predict study/practice preparedness rather than formatting similarity | outcome-tracking with selection-bias adjustment | calibrated academic progression or supervised competence | attributing success differences to recognition alone |

## Level 3: Unresolved hypotheses — treat as experimental

**H1: Bitemporal qualification knowledge graphs.** Store both `valid_time` (institution/award was valid in the real world) and `record_time` (when the system learned/recorded it). **Prediction:** materially fewer false mismatches from later institution closures, mergers and retrospective registry changes. **Falsifier:** equal or worse decision error under independently adjudicated historical cases.

**H2: Recognition as typed inference, not text matching.** Model `authorization_at_award`, `curricular_sufficiency`, `formal_rights`, `practical_safety`, and `recipient_policy` as separate predicates. **Prediction:** fewer unsupported “equivalent bachelor/master” claims in complex multi-purpose cases. **Falsifier:** experts do not make fewer scope errors than existing workflows.

**H3: Materiality counterfactual testing.** For each claimed substantial difference, ask: *if this gap were remediated, would the applicant meet the stated purpose?* **Prediction:** better targeting of bridge courses and fewer blanket denials. **Risk:** biases in defining the destination curriculum as unquestionably optimal. **Falsifier:** bridge completions do not predict comparable outcomes.

**H4: Recognition-by-claim with minimal disclosure.** Rather than forwarding an entire lifelong transcript, learners may prove named criteria such as “completed accredited introductory statistics” while keeping unrelated grades private. **Prediction:** less excessive data processing. **Risk:** selective disclosures without sufficient identity, credential status or educational context. **Falsifier:** increased spoofing, inability to resolve nuanced admissions judgments, or overbroad tracking.

**H5: Oversight-ready AI narrative reports.** AI drafts should carry citation anchors from original legislation, authority-specific decisions and verified course material plus a machine-readable uncertainty log. **Prediction:** reduced reviewer time while maintaining evidence-level accuracy. **Falsifier:** improvement exists only for easy, widely documented systems; degradation in low-resource languages and unknown institutions.

## Minimum research protocol for a frontier claim

1. **Preregister** the decision-specific hypothesis and comparator. Specify jurisdictions, credential types, use cases, historical periods and non-goals.
2. **Construct gold-standard decisions** through plural expert adjudication. Keep disagreement as data; do not force an artificial single “truth” on matters of discretion.
3. **Sample the difficult tail:** institution closures, joint degrees, online delivery, vocational credentials, low-resource languages, displaced learners and protected professions.
4. **Define errors asymmetrically:** false rejection of a legitimate applicant and unsafe acceptance into regulated practice have different consequences; report both.
5. **Measure process and outcomes:** latency, fees, evidence requirements, appeal reversal, applicant burden, academic success, training bridge performance, legal compliance and privacy incidents.
6. **Disaggregate performance fairly:** geography/language/system type/years where lawful and statistically supportable, without building ethnic or country stereotypes into automated decisions.
7. **Report uncertainty and abstention rates:** a tool that abstains appropriately is often better than one that fabricates a precise equivalence.
8. **Revalidate under policy drift:** fixed historical evaluation sets and genuinely new time-window sets, with change-triggered audits.
9. **Require human authorization:** research tools cannot issue admission/immigration/licensure recognition findings autonomously.
10. **Publish failure examples and reproducible decision criteria** without exposing personal academic documents.

## Priority tiers (expert synthesis, not measured ranking)

**Near-term high value:** bitemporal registries, explicit purpose fields on reports, applicant-directed evaluator choice before payment, standardized adverse-decision explanations, source-aware automation, privacy controls. **Medium-term:** machine-readable learning outcomes, interagency consentful evidence reuse, calibrated partial-recognition routes. **Longer-term experimental:** privacy-preserving cross-border proofs, outcome-calibrated equivalence graphs, universal linked attestations and autonomous crosswalk reasoning. Do not deploy higher-risk ideas merely because they are technologically feasible.
