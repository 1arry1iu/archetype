# Credential Recognition — Operational Playbooks

**Applies to:** admissions staff, applicants, evaluators, academic registrars, professional regulators, and institutions. Source IDs resolve through `source_ledger.csv`. None of these checklists substitutes for an authorized decision.

## Playbook A: routing a new case

**Mandatory intake fields**

| Field | Example or allowable answer | Why it matters |
|---|---|---|
| intended_use | graduate admission / advanced standing / job / regulated practice / immigration | determines authority |
| destination | country + region/state + named institution/body | prevents false worldwide mapping |
| award_country / award_year | recorded from award and transcript | time-indexed recognition |
| issuer_legal_identity | name, registry ID, campus, history | accredited-at-award check |
| awarding_body | may differ from teaching provider | transnational program risk |
| credential_type | diploma, degree, short-cycle, vocational, microcredential, partial learning | reference award |
| field_and_level | program name, national level if known | discipline-specific mapping |
| mode_and_location | campus, distance, transnational, joint | QA scope |
| recipient_accepted_assessor | written instruction and date | cost and legal effect |
| regulated_profession | yes/no/unknown + occupation | license gate |
| documentary_constraints | missing originals, refugee, inaccessible registrar | alternative evidence |
| next_deadline | submission date | prioritization, not promise |

### Decision route

```text
START → identify intended purpose and named recipient
  ├── Academic admission → admissions office sets evidence and entry criteria
  │      └── If course exemptions sought, trigger separate transfer-credit review
  ├── Immigration → immigration authority decides designated report/validity
  ├── Employment, not legally regulated → employer determines relevant evidence
  └── Regulated occupation → statutory board or named recognition authority
              └── possible profession-specific exam/assessment + licensing

In ALL routes: identity → issuer-at-award status → authenticity →
  qualification level/profile → material outcomes → written scoped outcome.
```

**Stop and refer rather than guess** when law, status, recipient policy, accreditation history or identity is unresolved; when original and translation contradict; when licensing rights are implicated; or when a claimed automated equivalence has no auditable basis.

## Playbook B: evidence packet

**Minimum often helpful (not universally mandatory):** final award certificate; official transcript/mark sheets; year-correct grading legend; university/program identity; dated syllabus/course descriptions; degree structure and learning outcomes; entry requirement; program authorization details; translated versions if required; holder-name change records; institution-issued letter regarding study mode/joint award if ambiguous.

**Optional in specialist or difficult cases:** degree supplement, full dissertation, assessment exemplars, practical placement logs, professional registration certificate, postgraduate research-methods mapping, military/corporate training evidence, challenge examinations, archive/closure records, accreditation certificate valid in the award period.

**Chain-of-custody fields:** evidence ID, origin, document type, language, issuer, collection timestamp, period described, verified-by, verification channel, confidence, discrepancies, access restriction, retention schedule and last check.

## Playbook C: evaluator procedure

1. Specify **recognition claim** as `{for whom, for what, by whom, when, under which rule}`.
2. Verify the degree-awarding body, not only the teaching center; separate authenticity from recognized standing.
3. Extract original qualification claims without translating titles into assumed equivalents.
4. Identify the domestic reference award/prerequisite bundle and whether target is academic or occupational.
5. Map outcomes and level; add studies' length, workload, research and placements as **evidence**, not blind gates.
6. Record differences under **content**, **learning outcomes**, **legal requirements**, **status**, **evidence unknown**.
7. Test materiality: would each difference prevent the stated learning or lawfully required function?
8. Consider partial/conditional recognition, credit, bridge, assessment or new evidence where feasible.
9. Issue a rationale with `disposition`, `scope`, `conditions`, `independently verified`, `not verified`, `decision rights`, `sources`, `review route`.
10. Obtain a second review for novel jurisdiction, contradictory records, severe adverse decision, displaced learner, unvalidated AI recommendation or protected profession.

**Decision hierarchy:** verified law and recipient policy > corroborated official qualification information > authenticated award materials > reasonable comparative judgment > unknown. The last two MUST be labeled.

## Playbook D: applicant email to admissions or licensing authority

> Subject: Accepted assessment route for a foreign qualification
>
> I hold a [qualification title] awarded by [institution, country] in [year]. I am seeking [specific intended use] for [named program/profession]. Could you confirm (1) whether you assess this award directly, (2) whether you require a named external evaluator and report type, (3) which transcripts, translations, course syllabi, or direct-issuer submissions are needed, (4) whether an existing report can be reused, and (5) how conditional decisions and appeals work? I would like to confirm the accepted process before commissioning a paid assessment.

## Playbook E: adverse decision and appeal review

**Check:** Were the criteria disclosed and within jurisdiction? Was the identity/award matched accurately? Did the assessor distinguish home-system recognition from comparison? Is a degree-level difference being treated as a subject-specific difference? Does the alleged difference actually obstruct the **intended purpose**? Is uncertainty caused by missing evidence rather than absence of learning? Was a lawful alternative or partial recognition considered? Are reasons reviewable? Was contemporary source status mistakenly applied to an earlier award?

**Review packet:** original decision and date; cited rule; factual errors and corrections; independent issuer or accreditation evidence; course-to-target outcome map; proposed bridge if needed; requested remedy; appeal deadline and authority. **Do not promise appeal success.**

## Playbook F: AI-augmented credential review — controlled use only

**Permitted assistive functions:** document inventory, cross-language metadata extraction with original text preserved, source URL retrieval, tentative course-to-outcome mapping, contradiction spotting, draft of a reasoned memo. **Human-only decision:** legally binding recognition, refusal, fraud finding, licensing, immigration evaluation, or academic admission.

**Required controls:** citations at proposition level; no unsourced country equivalence; refusal to extrapolate across unverified years; schema-valid outputs; recognition of unknowns; cross-lingual performance tests; consent/privacy review; gold-set evaluator comparisons; false refusal and fraud-miss reporting; protected-characteristic fairness monitoring; source retrieval-date logging; revocation-aware credentials; audit and appeal.

### Human decision memo template

```text
CASE / DECISION ID:
Named holder and award:
Original award title, language, country, period, issuer and awarding body:
Intended purpose / destination / recipient:
Authority and applicable law/policy [source + version]:
Evidence received, origin and verification status:
Institution/program recognized at award date? [verified / conditional / unknown]:
Qualification level, type, subject and home-system progression:
Target reference qualification/prerequisite/competency:
Learning outcomes accepted and learning outcomes in question:
Material differences specifically relevant to the intended use:
Mitigations and alternative / partial recognition options:
Disposition [recognize / conditional / partial / pending / refuse / out-of-scope]:
Effect, restrictions, uncertainty and what this decision does NOT grant:
Decision maker / date / expiry or reconsideration triggers:
Reasoned explanation, appeal route and accessibility arrangements:
```

## Playbook G: update and incident response

**Policy change:** archive old rule, record new rule, identify effective date and transition clauses, review only cases legally affected, notify relevant parties and log reason. **Fraud indication:** preserve evidence safely, verify independently, protect due process, suspend automated decisions, escalate proportionately. **Incorrect public equivalence:** correct statement and mark old version superseded. **Algorithm drift:** freeze automated recommendation, re-run contrastive cases, retrain/revalidate only with authorized review.
