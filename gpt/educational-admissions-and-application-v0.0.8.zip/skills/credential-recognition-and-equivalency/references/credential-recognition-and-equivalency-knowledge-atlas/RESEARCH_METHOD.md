# Research Protocol, Source Appraisal and Limitations

**Review type:** targeted, cross-jurisdictional *critical evidence map and comparative policy synthesis*, created **27 October 2026**. It is not a preregistered systematic or exhaustive legal review. This distinction is material: it would be misleading to publish a PRISMA flow diagram or exhaustive country claim without a corresponding executed review protocol and screening log.

## The questions that controlled source selection

- **RQ1 — Definition:** What is being verified, compared, recognized or authorized, and what is the relationship among these operations?
- **RQ2 — Authority:** Who has competent power to decide for admission, course credit, employment, immigration and regulated professional practice?
- **RQ3 — Evidence:** Which issuer, home-system status, curriculum, learning outcomes, history and documentary evidence are necessary to make a defensible judgment?
- **RQ4 — Fairness:** How should material differences, missing records and conditional pathways be treated?
- **RQ5 — Interoperability:** Which global/regional qualification frameworks and digital credentials aid transparency without creating unearned rights?
- **RQ6 — Frontier:** What is presently specified or used, and what still requires empirical/legal validation?

## Search and verification practice

**Primary domains searched:** `unesco.org`, `enic-naric.net`, `ear.enic-naric.net`, `europa.eu`, `eur-lex.europa.eu`, `ed.gov`, `canada.ca`, `cicic.ca`, `education.gov.au`, `nzqa.govt.nz`, `zab.kmk.org`, `saqa.org.za`, `ugc.gov.in`, `cscse.edu.cn`, `asean.org`, `coe.int`, `w3.org`, and government-related immigration and recognition sites.

**Query families used (representative, not a claim of exhaustiveness):** UNESCO Global Convention and regional conventions; Lisbon “substantial differences” and recognition purpose; EQF/ECTS; U.S. foreign qualifications; Canadian immigration ECA versus institutional admission; UK ENIC Statement; Germany ZAB and anabin; Australian admission versus skills assessment; NZQA IQA; South African SAQA; India UGC 2025 equivalence; China CSCSE evaluation; ASEAN AQRF; refugee qualifications passport; 2025 W3C VC standards; Europass digital education credentials; European microcredentials and regulated professional recognition.

**Inclusion priority:** current and primary treaty texts; government/regulator statements; national information centre instructions; formal qualification frameworks; published technical standards; and operational professional guidance. Prioritize source pages whose issuer has competence for the **specific** claim. Do not borrow an organization’s authority in one domain to prove unrelated claims.

**Exclusions from authoritative status:** unverified commercial conversion charts, lead-generation “equivalency” vendors, degree-mill lists lacking due-process context, anonymous forum advice, generalized claims about all countries, and unsupported forecasts. Secondary or community sources can inspire research questions but not settle legal applicability.

**Comparison method:** extract subject, scope, date, decision owner, recognition type, constraints and source URL; separate treaty obligation from domestic procedure; reconcile putative conflicts by intended purpose or effective period; encode missing evidence as unknown; test counterexamples before recommending a rule. The source register preserves direct links and checked date, and a structured claim ledger maps important statements to individual sources.

## Evidence hierarchy and confidence

1. **Normative primary** — treaty/regulation where in force and applicable; application demands current law and party status.
2. **Direct competent-authority guidance** — excellent for the service actually described, but may be nonbinding or change.
3. **Professional recognition methodology** — ENIC-NARIC handbooks; persuasive where relevant, not a national statute.
4. **Technical specifications** — strong for data/cryptographic semantics, not for educational quality or visa law.
5. **Analytic synthesis** — the atlas's own comparisons and proposals; explicitly nonauthoritative and testable.

The labels **High / Conditional / Experimental** express support for *that proposition and purpose*, not a quantitative probability. No arbitrary numerical certainty percentage was assigned.

## Out-of-scope commitments

No attempt was made to evaluate individual diplomas, verify private applicants, crawl all recognized-institution registries, exhaust every country's educational law or licensing requirements, calculate universal conversion rates or establish future ratifications. No unsupported nationwide admission acceptance, professional authorization, immigration outcome, price or processing deadline is asserted.

## Falsification / quality checks

A claim fails release review if it lacks traceable support, confuses verification with recognition, treats level frameworks as legal entitlements, applies a current accreditation status to a historical award without support, claims credential signature proves educational truth, fails to identify the actual authority or gives adverse binary decisions to applicants with missing records instead of describing possible authorized alternatives.

**Structural QA completed:** source IDs and URL definitions cross-check, taxonomy dimensions and counts, machine-readable JSON and CSV exports, packaged-file SHA-256 checksums, and ZIP integrity. This is **not** a substantive third-party legal audit and does not certify that all source sites will remain unchanged.

## Critical epistemic note

The presence of a source citation does not make an interpretation correct; the source must support the precise claim. For a real case, re-open the authoritative primary text, check the date and scope, verify applicable updates, and document the specific decision-making body's published standard. The Atlas avoids treating a technically convincing output as a substitute for independent verification or legitimate human authority.
