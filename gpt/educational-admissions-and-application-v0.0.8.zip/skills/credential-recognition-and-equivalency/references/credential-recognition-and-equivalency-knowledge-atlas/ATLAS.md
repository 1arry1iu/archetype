# Credential Recognition and Equivalency — Knowledge Atlas (CRE-26)

**Edition:** 1.0 · **Evidence cut-off:** 27 October 2026 · **Domain:** international educational admissions, academic mobility, employment, professional authorization, and refugee/alternative pathways · **Status:** reference synthesis, **not** a recognition decision or legal opinion.

> **Governing thesis.** A credential is not intrinsically “equivalent” to another credential. An authorized decision maker determines whether evidence concerning a specific achievement is sufficiently comparable **for a stated purpose, within a specific jurisdiction, on a specific date**. Authentication, recognition, equivalence, placement, credit transfer, immigration assessment, and licensure are different operations. A positive result in one cannot silently substitute for another.

## Reader's map

1. [Ontology and terminology](#1-ontology-and-terminology) · 2. [Legal and institutional architecture](#2-legal-and-institutional-architecture) · 3. [Recognition evidence and comparison](#3-recognition-evidence-and-comparison) · 4. [Outcomes and decision logic](#4-outcomes-and-decision-logic) · 5. [Quality assurance and time](#5-quality-assurance-and-time) · 6. [Credits, grades and prerequisites](#6-credits-grades-and-prerequisites) · 7. [Global and regional instruments](#7-global-and-regional-instruments) · 8. [Jurisdiction atlas](#8-jurisdiction-atlas) · 9. [Professional practice](#9-professional-practice) · 10. [Nontraditional learning](#10-nontraditional-learning) · 11. [Displacement and missing records](#11-displacement-and-missing-records) · 12. [Authenticity and credential fraud](#12-authenticity-and-credential-fraud) · 13. [Decision and appeal workflow](#13-decision-and-appeal-workflow) · 14. [Applicants and admissions officers](#14-applicants-and-admissions-officers) · 15. [Research frontier](#15-research-frontier) · 16. [Quality, uncertainty and safeguards](#16-quality-uncertainty-and-safeguards) · 17. [Examples and counterexamples](#17-examples-and-counterexamples) · 18. [Evidence and maintenance](#18-evidence-and-maintenance).

## Research contract and epistemic labels

This is a **critical, source-led landscape review**, not a systematic review of all laws or of all 190+ education systems. Research prioritized UNESCO treaties and convention implementation pages, recognition networks, governments, national qualifications authorities, and standards bodies, with cross-checks against purpose-specific guidance. Source ledger includes 35 public primary/official guidance sources, identifiers **S01–S35**, stable URLs and a research-check date. The cited page may change after the evidence cutoff. Legislative applicability, country ratifications, provider status, credential issuance permissions, immigration criteria, tariffs, processing times and appeals routes require **live re-verification before use**.

**Evidence labels:** **N** = binding or potentially applicable normative text (must verify party/jurisdiction and current version); **G** = nonbinding but authoritative guidance; **P** = documented operational practice; **I** = reasoned synthesis/design inference; **F** = emerging frontier hypothesis requiring independent validation. **High confidence** attaches to explicit official propositions; **conditional confidence** to context-specific comparisons; **hypothesis** to proposed AI/native digital systems. Direct links in source citations are defined at the foot of this file.

### Core invariants (use in every case)

- **I1 — Intended-use boundary:** An assessment for a master's admission cannot, without a new authority's decision, license a professional or fulfill immigration rules. [S06][S11][S15]
- **I2 — Authority boundary:** The recipient—admissions institution, employer, immigration body, or regulator—specifies the acceptable evaluator, evidence, and binding effect. [S11][S16][S17]
- **I3 — Recognition is not verification:** A genuine document can evidence a qualification that is not comparable for a target purpose; a digitally signed false claim may pass integrity checks. [S19][S27]
- **I4 — Equal framework level is not interchangeability:** Qualification framework levels express broad learning outcomes; they do not automatically prove field coverage, admission eligibility, curriculum equivalence or professional rights. [S07][S25]
- **I5 — Differences must be material:** Where the Lisbon/Global Convention principles govern, recognition should generally be granted unless relevant substantial differences are demonstrated; do not equate a nonidentical course length or title with a disqualifying difference by default. [S01][S05]
- **I6 — Time matters:** Institution authorization, program approval, study mode permissions, degree titles, curriculum and recognition laws must be checked **as of the award/program period**, not only today. [S19][S21]
- **I7 — Data minimization:** Verify only information necessary for the decision; preserve applicant consent, human review, the right to explanation and safeguards against discriminatory proxy comparisons. [S01][S27]

---

## 1. Ontology and terminology
*Separating documentary proof, learning achievement, equivalence and legal consequence*

**Credential** denotes a documentary or digital attestation of learning, awarded status or competence. **Qualification** denotes a recognized package of learning outcomes/competencies (sometimes tied to a national framework). **Record** denotes transcript, assessment, course description, diploma supplement or certified registry entry. **Competent authority** is the institution or legally responsible body empowered to evaluate or decide for a particular purpose. **Recognition** is acknowledgment of the standing/value of a foreign qualification for a specified use. **Equivalence/comparability** describes a relationship found under criteria and a reference qualification/system; it is not universally transitive.

| Operation | Core question | Typical output | Not implied |
|---|---|---|---|
| Identity matching | Is the holder the person associated with the record? | verified identity link | document genuineness |
| Authenticity verification | Was the document genuinely issued, unaltered, and not revoked? | verified record status | academic standing/level |
| Institutional/program status | Was the award authorized and quality-assured in the home system at award time? | status finding | equal target curriculum |
| Academic level comparison | How does the award's level/function relate to target framework? | level/comparability opinion | access to a named program |
| Admissions recognition | Is it an acceptable entry qualification for this program? | admissible/conditional/non-admissible | admission offer |
| Course/credit recognition | Which completed learning outcomes substitute for target study requirements? | credit exemptions/advanced standing | grade conversion or title award |
| Grade interpretation | How strong was performance in its local grading context? | contextual grade comparison | deterministic GPA translation |
| Immigration ECA | Does the award meet a migration pathway's credential rules? | program-specific report | professional license |
| Professional recognition | Does education/training/experience satisfy profession-specific legal rules? | permission to proceed or register, sometimes conditioned | transfer of general academic credit |
| Recognition of prior learning (RPL) | What skills can be established outside a formal degree? | validated learning, credit or admission access | full degree without rules |

**Useful distinctions:** *Comparability* is an evidenced correspondence, not identity. *Substantial difference* is a context-sensitive obstacle to the intended use, not just any difference. *Automatic recognition* may remove a separate assessment step for access to further studies **without waiving selective admission requirements**. *Credential portability* concerns technical/documentary presentation, while *rights portability* depends on legal recognition. [S05][S09][S27]

**Relational ontology:** `Person → holds → Qualification → awarded_by → Institution → authorized_at → Date`; `Qualification → contains → LearningOutcome`; `Authority → decides → RecognitionDecision`; `RecognitionDecision → for_use → IntendedPurpose`; `Decision → within → Jurisdiction`; `Decision → supported_by → EvidenceRecord`. An `EquivalenceAssertion` must bind all of `{source credential, reference system, comparison dimensions, purpose, authority, version/time, evidence, restrictions}`. The ontology and graph file operationalize these relations.

## 2. Legal and institutional architecture
*Authority is plural: a national treaty may create procedural standards without replacing admissions or licensing decisions*

At least five layers interact: (i) international convention/treaty and its state-party applicability; (ii) national legislation, regulation and ministries; (iii) degree-level and qualification frameworks; (iv) autonomous institutions, accreditation/quality assurance and admission policies; and (v) sectoral professional licensing and immigration rules. A cross-border equivalency letter must be read against **the actual requested decision**, not treated as a universal recognition passport.

International instruments establish principles of fairness, transparency, access to information, non-discrimination, transparent reasons and appeal, and in some contexts a presumption against refusing recognition absent a relevant substantial difference. A treaty provision may permit countries to establish an *assessment opportunity* rather than mandatory automatic recognition, and depends on applicable law and party status. Do not assert that every signatory recognizes every foreign degree. [S01][S02]

**Jurisdictional decision ownership** is irreducible. The United States distributes decisions among schools, employers, state licensing boards and federal immigration authorities; the U.S. Department of Education does not issue foreign degree evaluations. Canada distinguishes academic institution decisions from IRCC-designated assessments for immigration. Australia distinguishes providers' admission decisions from migration skills assessment and regulated occupational registration. [S11][S15][S16][S17]

**Source hierarchy for a real case:** (1) current binding law and regulator instructions; (2) current specific recipient policy; (3) official national recognition agency, education ministry or ENIC/NARIC; (4) verifiable issuing university/awarding authority records; (5) accredited evaluation organizations accepted by the recipient; (6) scholarly comparability studies. Unverified agents, generic equivalency charts, search snippets and social media cannot displace a binding recipient rule.

## 3. Recognition evidence and comparison
*From home-system standing to purpose-specific target-system sufficiency*

**Dimension A: holder and records.** Identity, official naming variants, award date, language and script, diploma/transcript chain of custody, issuing authority, digital signature or institutional verification, amendments, revocations, honorary versus earned status, joint- and dual-award identity. The *absence* of documentation is not automatically equivalent to *absence* of learning.

**Dimension B: home-system status.** The institution's legal permission to operate **at the relevant date**; awarding powers and jurisdiction; recognized program and campus; qualification standing in the national system; whether a pathway is general academic, vocational, professional, research, access, bridging or short-cycle. Cross-border franchise/branch campuses require identification of awarding institution, location, legal regime and quality assurance.

**Dimension C: learning.** Entry prerequisites; full-time-equivalent workload and duration; curriculum breadth/depth; achieved learning outcomes; assessments and integrity; research/thesis expectations; laboratories, clinical or supervised placements; professional practice hours; progression entitlements and rights in home country; mode (in-person, online, blended, competency-based) and whether the mode had valid quality oversight. UK ENIC and NZQA describe multivariable assessment rather than single-factor matching. [S14][S19]

**Dimension D: reference target.** Target qualification *level*, *type*, *subject profile*, *prerequisite bundle*, *specific module*, *outcome*, *rights* and *regulated practice standard* must be distinguished. A foreign master's can compare in **level** with a domestic master's yet lack the **methods preparation** required for a research doctorate. A bachelor degree in medicine may be at the same broad level as a bachelor in another discipline but not satisfy safe-practice licensing competencies.

**Dimension E: materiality and remedy.** Ask whether the demonstrated difference materially blocks the intended activity, whether it can be remedied via bridging/placement/restricted recognition, and whether denying recognition is proportionate. Lisbon-style recognition guidance advises comparing outcomes and considering actual objectives, not default refusal because of different duration or title. [S05][S06]

**Evidence matrix:** strong evidence includes authoritative public registry records, verified transcripts, syllabus/learning outcomes dated to study, recognized qualifications frameworks, issuer direct confirmation and licensing requirements. Medium-strength evidence includes issuer catalogs, archived academic handbooks and formal national evaluations. Weak evidence includes unverified online degree equivalence tables, self-translated transcripts, websites that only reflect present status, and opaque algorithmic predictions.

## 4. Outcomes and decision logic
*An opinion should disclose both what it establishes and what it does not establish*

**Decision vocabulary:** recognized for access; recognized for specified level/type; recognized with specific advanced standing; conditionally recognized subject to bridging or document verification; partially recognized; insufficient evidence/pending; not recognized for the specified use with reasons; out-of-scope. These are **analytic labels**, not universally prescribed legal categories.

**Substantial difference test (purpose-aware):** (1) define the target activity; (2) identify required learning or formal entitlement; (3) establish the foreign qualification's home-system function and outcomes; (4) map outcomes to target needs; (5) isolate real gaps rather than cosmetic differences; (6) assess whether those gaps predict inability or legal noncompliance; (7) consider partial recognition or bridging; (8) record reasons, legal basis, recourse and uncertainty. [S04][S05]

**Formal assertion:** `recognizes(A, Q, P, J, T, E) → {outcome, conditions, scope, explanation, appeal}` where `A=decision authority`, `Q=qualified achievement`, `P=intended purpose`, `J=jurisdiction`, `T=decision and award-date context`, and `E=evidence`. This is **not a deterministic equivalency equation**: judgment can vary lawfully across different purposes and decision makers.

**Nontransitivity:** If framework X references framework Y and Y references Z, no valid inference follows that an individual credential from X is automatically identical to Z. Differences in reference criteria, accreditation, stage, profile and law defeat automatic chain equivalence. Explicitly document each bridge, assumptions and losses. [S07][S25]

**No single world-wide conversion table exists** for degree titles, credit or grades. Prefer a decision memo with separated `authentication_status`, `institutional_status`, `level_opinion`, `field_outcome_mapping`, `admission_result`, `credit_result`, and `licensing_status` rather than one green “equivalent” flag.

## 5. Quality assurance and time
*Authorization and comparability are historical facts mediated by changing systems*

An evaluator must know whether the issuing institution/program held appropriate authority **when the qualification was earned**. Later accreditation does not automatically validate earlier awards; later loss of accreditation does not alone invalidate properly awarded historical qualifications. Distinguish institutional accreditation, professional/program accreditation, national recognition, degree-awarding powers and teaching/franchise agreements. Legitimate differences exist across countries; lack of one particular accreditation *label* may not imply illegitimacy.

A decision record should store `enrolled_from`, `enrolled_to`, `awarded_on`, `recognition_registry_checked_at`, `registry_effective_interval`, `regulatory_version`, `source_snapshot`, `accrediting_body`, `program_id`, `campus`, `mode`, `credential_title_language` and `verified_issuer`. For a joint degree, record the award of each partner, shared transcript arrangements and jurisdictional identity. The ZAB explicitly checks whether institution/program was recognized at graduation; NZQA starts by placing the award in its home system. [S19][S21]

**Red flags, not automatic fraud findings:** degree granted in days, unfamiliar accreditation claims, vague issuing authority, mismatch between transcript and curriculum, unsubstantiated professional rights, registry inconsistencies, fabricated apostille or website. Investigate proportionately; give applicants a chance to clarify. Avoid adverse decisions solely because of language, nationality, country risk stereotypes or a changed institution name.

## 6. Credits, grades and prerequisites
*Learning and performance are context-sensitive, not simple arithmetic*

### Credit
The ECTS is a European framework for learning workload/outcomes and supports transparency, accumulation and transfer; it is not a guarantee that a target institution will accept a course. A reasonable credit decision compares workload **plus** learning outcomes, level, currency, assessment quality, lab/placement contact, residency requirements and the receiving program's policy. [S08]

**Do not publish a universal ECTS ↔ US semester credit or hours ↔ credit identity**. Some organizations use approximations, but these are policy-specific, and workload systems and what counts as transferable academic credit differ. Treat conversions as conditional formulas tied to named institutional rules, with a manual exception path.

### Grades
Percent, GPA, division/class and honors scales are not interval-identical. An 80 in one system may reflect a distinct grading distribution or threshold from 80 elsewhere. Use the source institution's official scale, achievement distributions when reliable, program requirements, fail/pass boundaries, cohort history and relevant professional guidance. A third-party GPA estimate must not be substituted for the recipient's policy. UK ENIC states its general Statement of Comparability does **not** comment on grades. [S13]

### Prerequisites
For transfer or graduate admission, calculate a **course-to-outcome** matrix: core knowledge; research methods; math/language preconditions; supervised practice; laboratory competencies; thesis/independent study; quantitative and qualitative methods; recency. Institutions may grant admission without every elective being transferable or may accept overall degree standing while requiring bridge modules.

## 7. Global and regional instruments
*International procedural cooperation, not a universal equivalence decree*

| Instrument/framework | Geography / effect | Recognition implication |
|---|---|---|
| UNESCO Global Convention (2019; in force 5 Mar 2023) | Parties worldwide; UNESCO reported **42 states in July 2026** | Fair, transparent, non-discriminatory recognition framework; substantial differences, review/appeal; check state-party applicability [S01][S02] |
| Lisbon Recognition Convention (1997) and EAR guidance | European region plus participating jurisdictions | Recognition oriented toward demonstrated substantial difference and due process; national implementation governs [S04][S05] |
| Tokyo Convention (2011; in force 2018) | Asia-Pacific parties | Fairer information exchange and recognition practice [S03][S30] |
| Addis Convention (2014; in force Dec 2019) | African regional parties | Regional higher-education recognition and cooperation [S03][S31] |
| Buenos Aires Convention (2019; in force 2022) | Latin America/Caribbean parties | Regional recognition principles and mobility [S03] |
| Revised Arab States Convention (2022; in force 2026 per UNESCO) | Arab-region parties | Newer regional framework; verify current party and implementation status [S03] |
| EQF (eight levels) | European qualifications transparency | Translation grid for knowledge, skills and responsibility; **not automatic recognition** [S07][S32] |
| ASEAN Qualifications Reference Framework (eight levels) | ASEAN voluntary country referencing | Comparability information; national authorities retain decision-making [S25] |
| EU 2018 Council recommendation | EU Member States | Policy commitment toward automatic *recognition for access*; does not compel admission to an individual program or replace professional licensing [S09][S10] |

**Treaty applicability checklist:** Is the destination a State Party? Is the source a State Party where required? On what dates was the treaty in force for each? Does domestic law implement the relevant obligation? Which authority has competence? Does a special rule govern professional practice or admissions selection? What documents and appeals are required? Do not collapse “adoption,” “signature,” “ratification,” and “entry into force.”

## 8. Jurisdiction atlas
*Illustrative high-value national systems; always defer to current destination authority*

| Destination | Primary pathway / operator | Core rule of use | Source |
|---|---|---|---|
| **United States** | Applying college, employer, state licensure board, or immigration authority; private evaluators as requested | No central federal foreign-degree evaluation; recipient determines accepted service and effect | [S11][S12] |
| **Canada** | University/college for admissions; designated ECA organizations for immigration; provincial/territorial regulator for licensed profession | Immigration ECA and academic admission/registration are separate; IRCC ECA does not grant a professional license | [S15][S16][S33] |
| **United Kingdom** | UK ENIC Statement of Comparability plus university/employer/regulator decision | Advisory comparison, not legal admissions entitlement; no grade or English proficiency equivalence in standard Statement | [S13][S14] |
| **Germany** | anabin information / ZAB degree Statement of Comparability; universities and professional regulators separately | Degree-level comparison; no automatic admission, grade conversion or regulated-practice right | [S20][S21] |
| **Australia** | University or RTO for study; approved occupation assessors for migration; registration authority for professional occupation | Different purpose-specific streams; general OQUs may advise some eligible residents | [S17] |
| **New Zealand** | NZQA International Qualification Assessment (IQA), where required; recipient/immigration authority additionally | Comparison to NZQCF level/type; foreign countries' evaluations cannot automatically replace NZQA's | [S18][S19][S35] |
| **South Africa** | SAQA evaluation and NQF placement; admissions/sector regulator/employer has further criteria | Verified comparison does not itself satisfy admission/registration requirements | [S22] |
| **India** | UGC equivalence regime under 2025 regulation, plus destination institution/professional council rules | Verify up-to-date UGC text, implementation and exceptions before relying; not all disciplines necessarily follow one pathway | [S23] |
| **China** | CSCSE overseas qualification authentication/evaluation for foreign higher education awards; recipient sets further use requirements | Technical validation of legitimacy, authenticity and relationship to Chinese credentials; verify current eligible courses/modes | [S24] |
| **ASEAN** | National ministry/NQF/QF agency, educational institution, profession regulator, AQRF as translation device | AQRF facilitates comparisons but does not itself overrule sovereign recognition decisions | [S25] |
| **Other European states** | Country ENIC/NARIC information centre; higher-education institution or licensed profession authority | Country-specific rules and, for applicable cases, Lisbon/EU principles; no EU-wide admissions guarantee | [S04][S10] |

**Coverage caveat:** This table is a *routing map*, not a degree-by-degree equivalence registry. It deliberately avoids inventing equivalencies for unresearched countries. Country-, institution- and year-specific dossiers require actual records, current policy and national framework documents; further important systems include France (ENIC-NARIC France), the Netherlands (Nuffic), Sweden (UHR), Ireland (QQI/NARIC), Japan, Korea, Gulf states and additional Latin American and African national authorities. The present edition does not validate those country procedures individually.

## 9. Professional practice
*Licensed professional practice is not awarded by academic comparability alone*

At least three questions must be separately answered: Does the person possess an authentic award? Does their prior learning meet the jurisdiction's training standard? Are they eligible for licensure **under law**, which may require professional examination, language competence, supervision, work experience, ethics and character checks, registration, immigration/work authorization, continuing professional development or local law knowledge?

EU law has a distinct framework under Directive 2005/36/EC for regulated professions and special arrangements in specified categories; consult the regulated-professions database and the destination's national contact point. This is not an EU-wide override for any foreign qualification. [S10]

**Professional field watchpoints:** medicine and dentistry (clinical practice standards, specialist recognition), nursing and midwifery (safety and language), pharmacy (practice scope and examinations), law (bar routes and jurisdictional law), architecture/engineering (accredited education, professional practice and protected titles), teaching (teacher registration and pedagogy), psychology and social work (scope of practice), accounting/auditing (separate professional and statutory requirements). Distinguish titles that are legally protected from occupations that are not regulated in a destination.

## 10. Nontraditional learning
*Online, micro-, vocational, experiential and partial awards are first-class evidence categories, not automatically full degrees*

**Micro-credentials** certify learning outcomes from short experiences; their evidence quality depends on issuer authority, assessment, workload, level, quality assurance and transparent stacking rules. The EU adopted a 2022 recommendation fostering their recognition, but a micro-credential does not universally convert into credits, degree prerequisites or a license. [S29]

**RPL/validation of prior learning** evaluates work, self-directed learning, apprenticeships, military learning and other nonformal evidence against demonstrable outcomes; permissible outcomes vary by country/provider. Credit may be assessed through portfolio, challenge exam, interview, practical performance and documented experience. Quality assurance requires explicit standards and safeguards against class- or language-based advantage.

**Online and transnational provision** needs examination of the awarding body, period of operation, campus/franchise permissions, assessment integrity and whether distance mode was recognized under the relevant legal framework. UNESCO Global Convention addresses non-traditional modes within comparable quality-assurance frameworks; it does not proclaim every MOOC a degree. [S01]

**Partial studies, transfer, joint degrees and interruption:** preserve individual achieved outcomes and courses. A student may hold strong transferable learning without holding a complete destination-comparable qualification. “Not yet degree-complete” should not be represented as “no learning.”

## 11. Displacement and missing records
*Inclusive reconstruction of educational history without fabricating certainty*

Refugees and other displaced learners may lack transcripts because of institutional collapse, persecution, natural disaster or inaccessible archives. Assessment pathways should allow alternative evidence, structured interviews, course reconstructions, affidavits, available exam records or supervised challenge assessment, with proportional security/privacy safeguards. The Council of Europe's **European Qualifications Passport for Refugees** uses a combination of available records and structured interview, but **does not constitute a formal recognition act**. [S26]

Separate **credible reconstruction of claimed learning** from **verified documentary authentication**. Record what has been independently confirmed, what was self-reported, what has been inferred and which opportunities are offered conditionally. Do not demand proof that would put individuals or relatives at risk, nor label the applicant fraudulent merely because originals cannot be produced. Convention-based provisions and destination laws may create special duties and pathways. [S01][S26]

## 12. Authenticity and credential fraud
*Technical trust is necessary but not sufficient for educational or legal trust*

**Checks:** issuer identity and current/historical authority; original issue channel; authorization of representative/transcript sender; ledger or verification portal status; digital seal/signature; revocation data; metadata consistency; anti-tamper forensic flags; independently confirmed accreditation; translated record traceability. Escalate suspicious cases to trained human review with privacy restrictions, not automatic rejection.

**Apostille/legalization** may authenticate signatures/seals for cross-border document use but ordinarily does not validate the academic content, qualification level or confer recognition. **Electronic seal** may verify who signed a credential and whether its contents were tampered with, but does not establish the truth of learning outcomes, issuer educational standing or recipient acceptance. The W3C explicitly distinguishes verifiability from truth of the encoded claims. [S27]

**European Digital Credentials for Learning** provide signed electronic records and authentication checks. Cryptographic integrity, sender authenticity, education quality, recognition and authorization remain separate layers. [S28]

**Threat model:** fabricated schools/accreditors; legitimate institution impersonation; degree mills; forged transcripts; compromised registries/signing keys; fraudulent issuer agent; misleading degree-title translations; credential substitution; AI-generated fake documents; replayed credentials; unconsented cross-verifier profiling. Defenses: known-issuer trust anchors, key status, revocation, issuance timestamps, recipient-side policy, secure identity matching, explainable denial, minimal disclosure and auditing.

## 13. Decision and appeal workflow
*A case should be reproducible, humane, and amendable when evidence changes*

1. **Intake:** record intended purpose, destination country/body, academic level, field, regulation, dates and whether use is regulated.
2. **Authority routing:** identify who can decide; ask which evaluation service and report type they accept **before payment**.
3. **Record assembly:** academic certificate, issuer transcript, grading key, diploma supplement, curriculum/outcomes, registration dates, mode, translations, name history, ID and program recognition evidence.
4. **Verification:** validate legitimate issuing power at time of award; document issuer-response provenance; escalate contradictions proportionately.
5. **Comparison:** compare level, profile, outcomes, assessment, duration/workload, progression and regulated requirements; explicitly test only material differences.
6. **Decision:** separate authenticity from equivalency, partial recognition, credits, grades, admission/registration and conditional pathways.
7. **Communicate:** write a purpose-bounded finding with evidence, legal/academic criteria, conditions, missing information and any possible alternative routes.
8. **Review/appeal:** publish timelines and decision authority where available; allow corrections, new evidence and independent review as law/policy requires.
9. **Re-evaluation trigger:** new recipient, new purpose, newly located records, changed regulation, newly verified fraud or accreditation history, expired immigration report.

**Recommended case states:** `received → scope_checked → documents_pending → verification_in_progress → comparison_in_progress → human_review → decision_issued → reconsideration_or_appeal → closed`, with paths for `insufficient_evidence`, `fraud_referral`, `withdrawn` and `superseded`. Never represent “pending” as “negative equivalence.”

## 14. Applicants and admissions officers
*Operational advice that reduces avoidable cost and refusal*

**Applicants:** get the target school's/licensing board's **exact instructions in writing**; identify whether credential-by-credential, course-by-course, general statement, immigration ECA or profession-specific verification is required; confirm accepted vendors, translations, original-versus-scanned records and time validity. Collect syllabi and grading scales early; preserve translations and issued records; verify current processing requirements; request a reasoned written decision if refused. Where rules permit, consider bridge programs or prerequisite courses rather than assuming a whole degree must be repeated.

**Admissions offices:** maintain a recognition policy version and transparent authority matrix; evaluate degree access separately from program selection and credit; document each substantial difference and its relevance; accept equivalent alternate evidence where legal and safe; prohibit crude one-size GPA conversion; reserve human appeal; track consistency across reviewer, country and language groups; audit false refusals and time-to-resolution.

**Evaluation providers:** identify target use, standards, source periods, home/target education systems, documents verified versus submitted, confidence limitations, comparison-level rationale and which onward authorities may still impose additional conditions. Provide copyable source and decision identifiers.

## 15. Research frontier
*Emerging directions as of October 2026: plausible, useful, but not equal to demonstrated deployment*

| Frontier direction | Established anchor | Research gap / falsifiable question | Assurance requirement |
|---|---|---|---|
| Machine-verifiable educational credentials | W3C VC 2.0 Recommendation (15 May 2025); Europass EDC [S27][S28] | Can interoperable issuer and accreditation attestations reduce verification delays **without** increasing fraud and surveillance? | Real issuer trust roots, revocation, longitudinal fraud tests, privacy and semantic validation |
| Cross-framework qualification knowledge graphs | EQF/AQRF references [S07][S25] | Can provenance-bearing, time-indexed mappings reduce ambiguous degree level opinions across countries? | Nontransitivity checks, auditability, human ownership, false-equivalence rate |
| Human-supervised AI qualification assessment | Source-based qualification-evaluation practice [S04][S19] | Can LLM/RAG systems extract evidence and draft decisions without discriminatory error and hallucinated laws? | Traceable citations, adversarial tests, expert sign-off, rejection/abstention capability |
| Skills and learning-outcome microcredentials | 2022 EU microcredentials approach [S29] | When does stacking demonstrably substitute for degree learning rather than simply signaling participation? | Assessment quality, explicit accumulation contracts, longitudinal student outcomes |
| Recognition for undocumented learners | EQPR pathway [S26] | Which combinations of structured interviews, challenge tasks and sparse documents best balance access and accuracy? | Trauma-informed process, false-refusal audits, safe data handling |
| Automatic academic recognition | EU recommendation [S09] | Does removal of procedural checks actually increase mobility while maintaining program fit? | Track time, appeals, conditional decisions and denial patterns, distinguish eligibility from offers |
| Transnational online degree recognition | UNESCO nontraditional mode provisions [S01] | Which quality assurance and assessment integrity signals generalize across border/branch/online models? | Issuer-period validation, measurable learning outcomes, modality neutrality where justified |
| Privacy-preserving selective disclosure | W3C VC privacy discussion [S27] | Can students prove prerequisite completion without exposing the full transcript? | Unlinkability tests, subject binding, anti-correlation, recipient necessity review |

**Do not assert:** that blockchain itself establishes degree legitimacy; that AI can authoritatively recognize a qualification; that a global convention makes every degree automatically equivalent; that any regional eight-level framework entitles employment; or that digitization automatically eliminates discriminatory evaluation.

## 16. Quality, uncertainty and safeguards
*Evaluation tests for the atlas itself and for recognition organizations*

**Validity dimensions:** construct validity (what does “comparable” mean?), authority validity (does reviewer have the right to decide?), content validity (are essential outcomes measured?), historical validity (does the source period match award period?), criterion validity (does recognition predict successful study/practice?), fairness (are equivalent cases treated consistently?), consequential validity (false denials and unsafe acceptance), process validity (reasons, appeal, traceability) and privacy/security.

**Calibration rubric:** **A — directly supported** by current official authority for the stated scope; **B — likely supported but requires explicit local policy check**; **C — tentative comparative inference pending document inspection**; **D — unresolved / disputed / unsupported**. These letters are **research confidence labels**, not applicant merit, credential rank or expected admission chances.

**Release failure conditions:** unlinked legal claim; policy dated after assessment without historical applicability check; country framework collapsed into an individual entitlement; unsupported “degree = degree” mapping; conflation of ECA/UK ENIC/ZAB statements with regulator decisions; no uncertainty; automatic negative decision on missing records; no right to contest where required; unsupported country coverage presented as complete.

## 17. Examples and counterexamples
*Illustrative tests of principle; not real case determinations*

**Case A — foreign bachelor → U.S. master's.** Candidate has a valid foreign bachelor's from an authorized university. A private report considers its level comparable to U.S. bachelor's. The graduate program may still require a field prerequisite, minimum grade standing, English proficiency or course-by-course evaluation. **Outcome:** degree-level comparability ≠ admission. [S11]

**Case B — international MD → Canadian medical practice.** Immigration ECA assesses academic level for a migration purpose. Provincial professional licensure has separate supervised practice/exam/registration standards. **Outcome:** ECA ≠ medical authorization. [S15]

**Case C — foreign master's → German doctoral admission.** ZAB issues a Statement showing graduate-level comparison. A particular doctorate requires methods training, supervisor fit and an institution-specific decision. **Outcome:** ZAB is not an admissions offer. [S20]

**Case D — UK ENIC statement → GPA demand.** The comparability statement identifies level but does not evaluate grades. **Outcome:** grade interpretation needs distinct evidence or evaluator policy. [S13]

**Case E — same EQF level, different courses.** Two qualifications share an EQF level but one lacks laboratory outcomes essential to the receiving degree. **Outcome:** framework comparability need not yield course substitution. [S07][S08]

**Case F — digitally sealed degree from unauthorized issuer.** The seal is cryptographically valid and proves a named issuer signed a file; the issuer lacks recognized degree-awarding powers. **Outcome:** authenticity of signed bytes ≠ valid academic qualification. [S27]

**Case G — refugee with destroyed transcript.** Alternative evidence and interview support probable completion of prior study. A qualifications passport can report credible assessed facts but does not itself substitute for the university's formal recognition decision. **Outcome:** fair evaluation without overstating certainty. [S26]

**Case H — ASEAN framework chain.** Country A and B each reference the AQRF at the same level. Country B's licensing body requires a clinical placement absent from A's training. **Outcome:** comparison tools do not create regulatory right. [S25]

## 18. Evidence and maintenance
*Reproducible updates, source hierarchy and intentionally bounded coverage*

All source identifiers are in `source_ledger.csv` and `sources.json`; machine-readable nodes are in `taxonomy.json`; practical decision tools in `WORKFLOWS.md`, `CASEBOOK.md`, `JURISDICTIONS.csv` and `COMPARISON_TEMPLATE.csv`. `FRONTIER.md` ranks unresolved questions by policy consequence, research readiness and validation feasibility. `CHANGELOG.md` specifies dated, event-driven maintenance triggers. A local `index.html` supports keyword exploration without a server.

**Update cadence suggestion:** before each consequential case, check all relevant recipient and regulator pages; quarterly verify the source list; re-audit on convention ratification, national regulation, immigration-policy change, issuance-technology standards change or an adverse appeal ruling. No proactive updates are run by this static artifact.

**Known blind spots:** localized court jurisprudence; qualification equivalence for individual countries not documented above; historical accreditation registers by awarding year; some vocational/trade regimes; bilateral mutual-recognition arrangements; fee/turnaround tables; country-specific grading conversions; regulatory exemptions; regulatory status post-October 2026. These are intentionally not invented.

---

## Source links (verified official entry points)

[S01]: https://www.unesco.org/en/legal-affairs/global-convention-recognition-qualifications-concerning-higher-education?hub=70286
[S02]: https://www.unesco.org/en/higher-education/global-convention/about?hub=70286
[S03]: https://www.unesco.org/en/higher-education/conventions?hub=415
[S04]: https://enic-naric.net/page-EAR-manual
[S05]: https://ear.enic-naric.net/emanual/Chapter10/Recommendation.aspx
[S06]: https://ear.enic-naric.net/emanual/Chapter5/Recommendation.aspx
[S07]: https://europass.europa.eu/en/european-qualifications-framework-eqf
[S08]: https://doi.org/10.2766/87592
[S09]: https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX%3A32018H1210%2801%29
[S10]: https://employment-social-affairs.ec.europa.eu/policies-and-activities/skills-and-qualifications/recognition-professional-qualifications/getting-recognition-professional-qualifications_en
[S11]: https://www.ed.gov/about/initiatives/international-affairs/recognition-of-foreign-qualifications
[S12]: https://naces.org/members/
[S13]: https://www.enic.org.uk/individuals/statement-of-comparability
[S14]: https://www.enic.org.uk/individuals/how-we-check-qualifications
[S15]: https://www.canada.ca/en/immigration-refugees-citizenship/services/immigrate-canada/express-entry/documents/education-assessment.html
[S16]: https://www.cicic.ca/875/get_information_on_academic_credential_assessment_and_recognition_for_admission_purposes.canada
[S17]: https://www.education.gov.au/international-education/recognise-overseas-qualifications
[S18]: https://www2.nzqa.govt.nz/international/recognise-overseas-qual/iqa/
[S19]: https://www2.nzqa.govt.nz/international/recognise-overseas-qual/how-we-evaluate/
[S20]: https://zab.kmk.org/en/statement-comparability
[S21]: https://zab.kmk.org/index.php/en/statement-of-comparability/faq
[S22]: https://saqa.org.za/services/evaluation-of-%20foreign-qualifications/
[S23]: https://www.ugc.gov.in/regulations/
[S24]: https://www.cscse.edu.cn/zwfw/lxfwzxwsfwdt2020/xlxwrz32/qtxx/2026042823585825550/index.html
[S25]: https://asean.org/our-communities/economic-community/services/aqrf/
[S26]: https://www.coe.int/en/web/education/recognition-of%20-refugees-qualifications
[S27]: https://www.w3.org/TR/2025/REC-vc-data-model-2.0-20250515/
[S28]: https://europass.europa.eu/en/european-digital-credentials-learning
[S29]: https://education.ec.europa.eu/education-levels/higher-education/micro-credentials
[S30]: https://www.unesco.org/en/articles/asia-pacific-regional-convention-recognition-qualifications-higher-education?hub=365
[S31]: https://www.unesco.org/en/legal-affairs/revised-convention-recognition-studies-certificates-diplomas-degrees-and-other-academic?hub=66927
[S32]: https://europass.europa.eu/en/description-eight-eqf-levels
[S33]: https://www.canada.ca/en/immigration-refugees-citizenship/corporate/partners-service-providers/foreign-educational-credential-assessment.html
[S34]: https://enic-naric.net/page-EAR-HEI-manual
[S35]: https://www.immigration.govt.nz/work/requirements-for-work-visas/green-list-occupations-qualifications-and-skills/check-if-you-need-an-international-qualification-assessment/
