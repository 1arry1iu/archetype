<!-- CONSTRUCT-SKILL-NOTES:BEGIN version=1 -->

## Reference Notes

**Reference scope.** Coordinated, stateful, recoverable, observable and governed multi-actor processes.

- Standards anchors: BPMN 2.0 / process modeling, state machines, process mining and durable-execution patterns.
- Engineering anchors: idempotency, retries, compensating transactions/sagas, event sourcing, audit logging, access controls, human-in-the-loop approvals and reliability SLOs.
- Evidence rule: a diagram is not an executable guarantee; test error paths, authority boundaries, failure recovery and actual runtime observability.

**Reference register convention.** For every cited claim, record source title/author or standards body, edition or release, persistent identifier/URL, access date when online, quoted passage or page/section, claim supported, evidence tier, and known counterevidence. External works mentioned here are **reading leads, not bundled or automatically verified citations**. Resolve authoritative editions before use.

## Assets Notes

**Existing package assets (verified against release `pluginrel_6ad31a9c75dc81918fe03685a5cd24bc`):**

- **Bundled local reference:** none specific to this skill was listed in the current release.
- **Shared branding only:** `assets/construct-icon.png` exists at plugin root. It is not evidence, a skill dataset, or a specialized analysis asset.
- **No other workflow-specific templates, data files, test corpora, schemas, or visualizations were found in the release file inventory.**

**Recommended assets to develop and validate:**

- **Proposed, not yet bundled:** BPMN/state-transition process specification.
- **Proposed, not yet bundled:** dependency DAG, role/authority/RACI matrix.
- **Proposed, not yet bundled:** idempotency/retry/compensation test cases.
- **Proposed, not yet bundled:** event trace, SLO and runbook template.
- **Proposed, not yet bundled:** change control, incident and rollback policy.

**Asset registration standard.** Every future file should carry purpose, source/creator, provenance, license/consent, version, schema or media type, integrity digest, restrictions, expected consumer, and validation status. Keep examples distinct from normative specifications and empirical datasets. Do not claim a proposed asset exists until it has been bundled and audited.

## Dependencies

**Package/runtime dependencies.** This skill is a Markdown instruction module; no skill-specific executable runtime, package manager dependency, remote API, or MCP tool dependency is declared in the inspected plugin package. Invocation of tools or sources is conditional on access, authorization, and the question being asked.

**Cross-skill reasoning dependencies (invoke selectively, not automatically):**

- `skills/priority/SKILL.md` — resolve queues and operational precedence; a **conceptual** dependency, not a required code import.
- `skills/format/SKILL.md` — interface/data contracts; a **conceptual** dependency, not a required code import.
- `skills/information/SKILL.md` — context and event provenance; a **conceptual** dependency, not a required code import.
- `skills/validity/SKILL.md` — test process fitness; a **conceptual** dependency, not a required code import.
- `skills/evaluation/SKILL.md` — measure performance and impact; a **conceptual** dependency, not a required code import.

**Handoff contract.** Input: objective, actors, authorities, dependencies, systems and failure risks. Output: executable flow contract, handoffs, monitoring, recovery and audit evidence.

**Dependency rules.** Preserve the ownership boundary between specialist skills; pass a stated purpose, definitions, provenance, constraints and confidence with every handoff. If a required skill, external source, authorization or test environment is unavailable, mark the gap rather than simulating evidence or claiming a test ran.

<!-- CONSTRUCT-SKILL-NOTES:END -->
