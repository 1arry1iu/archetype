<!-- Historical appendix preserved exactly below; superseded by current SKILL.md integration section. -->

# SKILL INTEGRATION APPENDIX
*References, Assets, Dependencies, Interoperability, and Evolution*

This appendix standardizes integration for **WORKFLOW**. It supplements, never overrides, the preceding skill specification. All listed file availability is based on the inspected Construct `0.9.30` source inventory; re-inventory the active release before relying on filenames. Integration relationships are conceptual and invoked on demand, not mandatory imports or undisclosed tool privileges.

## 1. REFERENCE NOTES
### 1.1 Reference Inventory
**Existing local reference files** (paths relative to `skills/workflow/`; the same files have plugin-root paths prefixed by `skills/workflow/`):

- `references/workflow-profile.zip` — profile resource.
- `references/workflow-knowledge-atlas.zip` — atlas resource.
- `references/reference-assets-dependencies.md` — note resource.

### 1.2 Reference Descriptions and Purposes
`workflow-profile.zip` supports high-fidelity profile elaboration and illustrative architecture; `workflow-knowledge-atlas.zip` supports thematic exploration and source-guided knowledge mapping. Neither bundle by itself authorizes an empirical claim or tool action.
`reference-assets-dependencies.md` contains earlier source leads and cross-skill notes. Its former file-inventory statements may be stale; the live plugin manifest and source file list take precedence on availability.

### 1.3 Reference Selection and Retrieval
Start with this skill’s `SKILL.md` and the declared use case. Select specific reference material only where the needed factor hierarchy, worked example, knowledge map or domain nuance is not already resolved. For ZIP resources inspect archive members and citations before treating any internal file as an authoritative source; do not eagerly extract both ZIPs for routine tasks.
For deep domain synthesis, inspect the profile first if structural detail is needed, or the knowledge atlas first if the primary gap is topical evidence and relationships; expand selectively, respecting provenance.

### 1.4 Reference Relationships and Usage Rules
Interpret `SKILL.md` as the runnable entrypoint; expanded section sources (where present) as detailed authored specifications; profile bundles as reusable representations; knowledge atlases as navigational/exploratory material; and note files as historical guidance. Resolve conflicts by current source/version, explicit task scope and evidence quality—not by file size or eloquence. Record selected path, component/member, version, provenance, caveats and reason for retrieval. Paths to nonexistent or proposed files are not valid sources.

## 2. ASSETS NOTES
### 2.1 Asset Inventory
- **Existing skill-local assets:** none listed under `skills/workflow/assets/` in the inspected release. Do not infer a template or dataset from the skill title.
- **Existing shared plugin asset:** `assets/construct-icon.png` at the plugin root (not in this skill’s `assets/` folder).

### 2.2 Asset Descriptions and Purposes
No skill-specific reusable asset is registered as present. Any future schema, prompt template, synthetic example, test fixture or visualization must be created and separately added before being referenced as an available file.
`assets/construct-icon.png` is shared visual branding only. It must not be represented as a test artifact, ontology, template, or independent evidence.

### 2.3 Asset Selection and Usage
For a reusable deliverable, first verify whether an appropriate asset was added in the active release. If none exists, create a new clearly labeled candidate and validate it before reuse. Input and output schemas are task-specific until an asset is actually registered.
Use the icon only in authorized presentation contexts, observing any applicable brand usage constraints. No automatic asset load is required for analytical tasks.

### 2.4 Asset Relationships and Usage Rules
Distinguish existing resource, externally retrieved content and proposed asset. Preserve originals, attribution, authoring/version history, format, license/consent limits, expected input/output contracts and integrity checks. An asset does not silently upgrade the authority of a reference or grant access to tools. Proposed artifacts must be labeled **proposed—not bundled** until packaged and audited.

## 3. DEPENDENCIES
### 3.1 Primary Skill Dependencies
**Primary conceptual integrations for** authorized, stateful orchestration of actors, data, decisions and recovery (not unconditional runtime requirements):
- `skills/priority/SKILL.md` — consequential allocation of scarce attention, effort and resources; invoke for the part owned by that specialist when the task crosses its boundary.
- `skills/format/SKILL.md` — encoding, schemas, interoperability, transformation and representational fidelity; invoke for the part owned by that specialist when the task crosses its boundary.

### 3.2 Conditional Skill Dependencies
- `skills/information/SKILL.md` — consult when the task materially requires semantic information architecture, provenance, retrieval and evidence objects.
- `skills/validity/SKILL.md` — consult when the task materially requires context-specific warranted reliance on claims, instruments, models and operations.
- `skills/evaluation/SKILL.md` — consult when the task materially requires merit, worth, performance, effects and evaluative criteria.

### 3.3 Complementary Skills
- `skills/construct/SKILL.md` — complementary perspective for integrated work; do not duplicate that specialist’s results as though independently established.

### 3.4 Invocation and Boundary Rules
**Owner of this skill:** Authorized, stateful orchestration of actors, data, decisions and recovery. **Do not collapse:** Task list versus executable state machine; orchestration capability versus permission; retry versus compensation. Dependencies are reasoning handoffs, not executable imports. First determine whether a single-skill answer suffices. When multiple skills qualify, assign one lead based on the requested deliverable and give each helper a narrowly scoped task; no mandatory cycles, reciprocal auto-invocation, or transitive dependency loading. Resolve conflict by user intent, responsible specialist’s scope, explicit evidence and human authority. If a dependency is unavailable, label the unmet check, do not invent its results.

## 4. CROSS-SKILL HANDOFFS
### 4.1 Handoff Triggers
Action plans need executable sequencing, data contracts, permission gates or lifecycle tests. Trigger a handoff only when the decision quality, semantic correctness, risk control or output fidelity would materially improve; otherwise continue locally.

### 4.2 Input and Output Contracts
**Required input:** Process objective, actors, permissions, states, events, dependencies and failure model. **Expected output:** Workflow state graph, actor/handoff contracts, recovery, monitoring and audit evidence. Use a handoff record with `request_id`, `source_skill`, `target_skill`, `task/purpose`, `entities/referents`, `definitions`, `context`, `source_refs`, `assumptions`, `uncertainty`, `constraints/permissions`, `requested_output`, `version` and `return_owner`. The receiver returns `deliverable`, `supporting_reasoning`, `source/provenance`, `limits`, `unresolved`, `status` and `return_owner`.

### 4.3 Information and Context Transfer
Transmit only necessary facts and context. Preserve exact source paths/member names, claim-to-source linkage, time frame, intended use, confidence semantics, contradictory evidence, cultural/ethical context, privacy restrictions and decisions already made. Keep user-supplied facts distinct from fictional generations, inferences and tested observations. If transformations change semantics, annotate the change rather than silently replacing the source claim.

### 4.4 Coordination and Responsibility Rules
The lead skill controls scope, sequencing, integration and delivery; the specialist owns its domain result, assumptions and caveats. One lead, named subtask owners, explicit return points. Use a directed acyclic execution plan even if the conceptual skills network is reciprocal. Capability does not imply tool permission. Resolve competing definitions by revisiting purpose and canonical referent, recording the adopted rule and unresolved disagreements. Avoid circular self-approval and double-counting shared sources.

### 4.5 Completion and Return Conditions
Close the handoff when the requested domain artifact and provenance/limitations are returned, contract fields are populated, critical unknowns are flagged, and the lead can integrate without misattribution. If blocked, return `blocked` with missing evidence, unavailable resource or permission; if partial, return `partial` with explicit scope. The originating lead retains final publication/decision responsibility and performs overall consistency checks.

## 5. MAINTENANCE & EVOLUTION
### 5.1 Version and Change Management
Maintain a skill-version/appendix-version pair and plugin release identifier; this appendix uses schema `1`. Record date, changed subsections, author/editor, reason, expected downstream impacts and rollback path in a release-level change log. The inspected baseline is Construct `0.9.30` (`pluginrel_6addea7000dc8191a9e4abe5a47bca51`), not a guarantee of future state. Increment plugin semantic version on publication and synchronize duplicate manifest versions without altering unrelated configuration.

### 5.2 Reference and Asset Synchronization
Before release, rescan `skills/workflow/references/`, `skills/workflow/assets/`, and relevant plugin-root shared assets. Verify exact paths, file types, existence, readable archive members, expected inputs/outputs and permission/provenance metadata. Update the inventory when resources change; remove or mark stale only after verifying the owning source. Historical note files must not override observed current availability.

### 5.3 Dependency Compatibility
When a named specialist is renamed, removed or its contract materially changes, update this appendix and each reciprocal handoff that actually relies on it. Confirm skill paths resolve, role boundaries remain stable, and handoff payload fields/terminology are compatible. Do not introduce mandatory dependency cycles or escalate permissions by cross-skill invocation.

### 5.4 Integrity and Consistency Checks
Run a non-destructive release audit: original `SKILL.md` byte prefix unchanged; precisely one integration appendix at end; five numbered sections and all 21 required subsections present; every registered file exists; no proposed resource advertised as bundled; dependencies point to installed skills; no self-dependency; all 21 use consistent handoff keys; both manifests agree on version; source hashes and changed-file list recorded. Test selected cross-skill flows and disclose untested behavior.

### 5.5 Continuous Improvement and Evolution
Collect failed retrievals, stale references, boundary conflicts, handoff ambiguities and observed user outcomes. Propose changes with tests, risk assessment, review and approval before activation. Revise only justified components; retain prior versions and explicit migration/retirement conditions. Do not treat unobserved future performance as validated merely because the appendix documents a procedure.

<!-- CONSTRUCT-SKILL-INTEGRATION-APPENDIX:END -->
