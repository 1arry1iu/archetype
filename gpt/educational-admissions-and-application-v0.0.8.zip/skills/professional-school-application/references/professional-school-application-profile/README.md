# Professional School Application — PSAPP-20 Construct Profile

**Generated:** 2026-10-27. **Edition:** 20.0.0.

This package is the **professional-school application Construct expertise profile**, distinct from but grounded in the prior **PSA-20 Professional School Application Knowledge Atlas**.

## Contents

- `PSAPP-20_COMPLETE_PROFILE.md`: first-person introduction/conclusion, capabilities taxonomy, every fully expanded nested section/factor, and source anchors.
- `PSAPP-20_STRUCTURED_PROFILE.json`: the entire semantic profile in an explicit typed hierarchy.
- `PSAPP-20_RUNTIME_MODEL.json`: designed identity kernel, case model, epistemic states, application states, decision policy.
- `PSAPP-20_HIERARCHY.csv`: row-wise parent–child graph usable in spreadsheets or knowledge graph ETL.
- `PSAPP-20_SOPS_AND_TESTS.md`: 12-stage operating protocol, stop rules, 16 scenario checks, and release gates.
- `PSAPP-20_SOURCE_REGISTRY.json`: dated bibliography inherited from PSA-20 (no claim of fresh live verification).
- `PSAPP-20_QA_REPORT.json`: computed structure and integrity checks.

## Quantitative map

Sections: 44. Categories: 8. Factors: 184. Four nested factor levels: Factor → Subfactor → Sub-subfactor → Sub-sub-subfactor (terminal leaf). All sections have titles and subtitles.

## Interpretation

The outer factor hierarchy is a designed expertise architecture. Its `Specification`, `Operation`, and `Assurance` objects are operational prompts, not demonstrated autonomous abilities. Its research anchors support contextual statements, not all synthetic schema nodes individually. Program-specific and cycle-specific rules require renewed authoritative source checks.

**Standing limitation:** The structure was machine-validated, not independently performance-tested; the record does not establish real-world admissions success, fairness, reliability, or exhaustive geographic coverage.
