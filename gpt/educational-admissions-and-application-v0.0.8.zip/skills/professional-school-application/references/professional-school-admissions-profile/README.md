# PROFESSIONAL SCHOOL ADMISSIONS — PSADM-20

**Edition:** 20.0.0 · **Dated:** 27 October 2026 · **Designed Construct-style expertise profile**

## Contents
- `PSADM20_PROFILE.md` — full requested layout, first-person introduction and conclusion, section subtitles, deeply nested factors.
- `PSADM20_PROFILE.pdf` — print-oriented reference edition.
- `PSADM20_PROFILE.txt` — one strict `Factor{Subfactor[Subsubfactor(Subsubsubfactor,...)]}` expression per factor line.
- `PSADM20_READER.html` — searchable, self-contained expandable profile.
- `PSADM20_PROFILE.json` — nested machine-readable tree with stable identifiers.
- `PSADM20_NODES.csv` — flattened node index with ancestry and depths.
- `PSADM20_FACTORS.csv` — complete expressions, factor IDs and source-context anchors.
- `PSADM20_CAPABILITIES.csv` — category/section/coverage index.
- `SOURCES_AND_PROVENANCE.md` — source register and section-to-source crosswalk.
- `SOURCE_REGISTER.csv` — locally bundled copy of the PSA-20 research source register, enabling a standalone rebuild.
- `PSA20_TO_PSADM20_CROSSWALK.csv` — mapping from the 32-section PSA-20 atlas to the PSADM-20 construct.
- `QC_REPORT.json` — automated grammar, counts and identity checks.
- `section_blueprint.txt` — authored conceptual source design.
- `build_profile.py` — reproducible generator using local prior research atlas source register.

## Structural inventory

| Unit | Count |
|---|---:|
| Categories | 10 |
| Sections | 60 |
| Factors | 300 |
| Subfactors | 900 |
| Sub-subfactors | 2700 |
| Terminal sub-sub-subfactors | 8100 |

## Important bounds
This is an **authored conceptual and methodological construct**, not an independent scientific validation, official government guidance or guarantee of admission, examination success, program accreditation, or professional registration. The 56-source context register is inherited from the prior PSA-20 atlas and must be checked against current institution-specific requirements. The leaf taxonomy is a design for analysis and QA, not a claim that regulators explicitly require every generated node.

## Design integrity
All 300 factor expressions are matched to four levels: `Factor{Subfactor[Subsubfactor(Subsubsubfactor, Subsubsubfactor, Subsubsubfactor)]}`. Counts, source identifiers, node IDs and delimiter balance are checked by the included generator. Research anchors are tagged as context rather than used to certify created taxonomic structure.
