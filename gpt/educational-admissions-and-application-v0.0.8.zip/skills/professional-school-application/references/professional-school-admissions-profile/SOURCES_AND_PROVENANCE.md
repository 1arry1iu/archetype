# PSADM-20 — EVIDENCE AND PROVENANCE REGISTER

**Research reference point:** 27 October 2026. Source labels are inherited from the PSA-20 research atlas. The format and professional-factor tree are newly authored specifications; source links provide relevant official-policy or research anchors, not proof that every designed subfactor is an externally mandated category.

**Interpretation:** authoritative current rule requires re-verification by profession, institution, applicant category and admission cycle. No numeric odds, official recognition determination or policy generalization is implied.

## Section-to-source crosswalk

| Section | Topic | Source anchors |
|---:|---|---|
| 1 | Meta-Architecture Of Professional School Admissions | S02, S05 |
| 2 | Professional Education Ontology | S20, S33, S34 |
| 3 | Actors, Authority And Regulatory Ecology | S01, S17, S20 |
| 4 | Professional Identity And Vocational Fit | S02, S41 |
| 5 | Entry-Route And Professional Lifecycle Models | S20, S48 |
| 6 | Evidence And Epistemology Of Admission | S36, S37 |
| 7 | Comparative National And Regional Systems | S24, S28, S29, S31 |
| 8 | Statutory Eligibility And Hard Constraints | S01, S17, S24 |
| 9 | Academic Record And Qualification Equivalence | S28, S33 |
| 10 | Admissions Testing And Assessment Routes | S03, S18, S26 |
| 11 | Accreditation, Licensure And Right To Practise | S20, S33, S34, S35 |
| 12 | Immigration, Residency And Public Funding | S33, S56 |
| 13 | Foundational Academic Preparation | S03, S17 |
| 14 | Experiential Learning And Professional Exposure | S04, S07 |
| 15 | Research, Projects And Technical Portfolios | S36 |
| 16 | Competencies, Character And Professional Values | S02, S07 |
| 17 | Impact, Contribution And Leadership Evidence | S02 |
| 18 | Personal Circumstance And Contextual Readiness | S02 |
| 19 | Application Narratives And Motivation | S25, S43 |
| 20 | Recommendations And Third-Party Evidence | S07, S45 |
| 21 | Interviews And Multiple Mini Interviews | S04, S37, S39 |
| 22 | Situational Judgment And Professional Reasoning | S38, S26 |
| 23 | Disclosure, Conduct And Suitability | S44 |
| 24 | Portfolios, Work Samples And Practical Auditions | Conceptual domain (no singled-out anchor) |
| 25 | Holistic And Mission-Aligned Review | S02, S41 |
| 26 | Psychometrics And Predictive Validity | S36, S38 |
| 27 | Selection Models And Offer Decisions | S17, S22 |
| 28 | Fairness, Accessibility And Structural Opportunity | S02, S39 |
| 29 | Admission Data, Statistics And Transparency | S22, S40 |
| 30 | Ethics, Power And Appeal Systems | S41 |
| 31 | Human Medicine Admissions | S01, S08, S10, S28, S31 |
| 32 | Dentistry And Oral Health Admissions | S09, S27 |
| 33 | Veterinary Medicine Admissions | S11 |
| 34 | Pharmacy Admissions | S13, S14, S35 |
| 35 | Nursing, Midwifery And Allied Health Admissions | S15, S46 |
| 36 | Physician Assistant And Advanced Clinical Programmes | S12, S47 |
| 37 | Law School Admissions | S17, S18, S20, S22 |
| 38 | Business And Management School Admissions | S23 |
| 39 | Public Health, Policy And Social-Work Admissions | S16 |
| 40 | Engineering, Architecture And Design Professional Routes | Conceptual domain (no singled-out anchor) |
| 41 | Education, Psychology And Other Regulated Programmes | Conceptual domain (no singled-out anchor) |
| 42 | Specialized And Interdisciplinary Professional Pathways | Conceptual domain (no singled-out anchor) |
| 43 | Cross-Border Credential And Practice Mobility | S33, S34, S56 |
| 44 | Centralized Application Services And Submissions | S01, S08, S09, S11, S12, S17 |
| 45 | Application Strategy And Portfolio Construction | S01, S22 |
| 46 | Financial Aid, Debt And Pathway Economics | S41 |
| 47 | Offer, Matriculation And Enrollment Transitions | S42 |
| 48 | Applicant Casework, Advising And Decision Audits | S01, S17 |
| 49 | Admissions Research And Evidence Synthesis | S36, S37, S38 |
| 50 | Admissions Artificial Intelligence Governance | S05, S06 |
| 51 | Secure Information And Applicant Data Lifecycle | S06 |
| 52 | Institutional Selection Evaluation And Quality Control | S02, S04 |
| 53 | Complaints, Appeals, Audits And Redress | S41 |
| 54 | Knowledge Atlas Maintenance And Interoperability | S05 |
| 55 | Frontier Of Validity And Causal Selection Science | S36, S38 |
| 56 | Frontier Of Generative Ai And Agentic Admissions | S05, S06 |
| 57 | Scenarios, Stress Tests And Adversarial Cases | S02, S39 |
| 58 | Standard Operating Procedures Of Psadm-20 | S01, S41 |
| 59 | Comparative Case Simulation And Decision Intelligence | Conceptual domain (no singled-out anchor) |
| 60 | Continuity, Validation And Controlled Evolution | S05, S02 |

## Source register

| ID | Issuer | Resource and date/context | URL |
|---|---|---|---|
| S01 | AAMC | 2027 AMCAS Applicant Guide (2027 cycle) | https://students-residents.aamc.org/applying-medical-school-amcas/publication/2027-amcas-applicant-guide |
| S02 | AAMC | Mission-Aligned Selection and Retention (current) | https://www.aamc.org/services/member-capacity-building/mission-aligned-selection-and-retention |
| S03 | AAMC | Using MCAT Data in 2027 Medical Student Selection (2027 cycle) | https://www.aamc.org/services/mcat-admissions-officers/resources |
| S04 | AAMC | Conducting Effective Structured Undergraduate Admission Interviews (current) | https://www.aamc.org/services/admission-interview-foundations/conducting-effective-structured-interviews |
| S05 | AAMC | Guide to Navigating AI Use Cases in Medical Education Selection (current) | https://www.aamc.org/about-us/medical-education/responsible-ai-medical-school-and-residency-selection/guide-navigating-ai-use-cases-medical-education-selection |
| S06 | AAMC | Use of Artificial Intelligence in AAMC Service Programs (current) | https://www.aamc.org/services/use-artificial-intelligence-aamc-service-programs |
| S07 | AAMC | Guidelines for Writing a Letter of Evaluation (current) | https://students-residents.aamc.org/prehealth-advisors/guidelines-writing-letter-evaluation |
| S08 | AACOM | Apply to Medical School: AACOMAS (2026–27) | https://www.aacom.org/become-a-doctor/apply-to-medical-school |
| S09 | ADEA | ADEA AADSAS Applicant (2026–27) | https://www.adea.org/home/application-services/become-a-dentist |
| S10 | TMDSAS | Entry Year 2027 Application Guide (2027 entry) | https://tmdsas.com/application-guide/ |
| S11 | AAVMC | VMCAS 2027 Applicant Guide (2027 entry) | https://www.aavmc.org/wp-content/uploads/2026/06/AAVMC-VMCAS-ApplicantGuide-2027-updated.pdf |
| S12 | PAEA | CASPA for PA Programs and Program Directory (2026–27) | https://paeaonline.org/resources/member-resources/caspa |
| S13 | AACP / PharmCAS | 2026–27 PharmCAS launch (2026–27) | https://www.pharmcas.org/node/51 |
| S14 | AACP | PCAT Resources: Retirement of the PCAT (January 2024 onward) | https://www.aacp.org/resource/pcat-resources |
| S15 | AACN | NursingCAS Application Service (current) | https://www.aacnnursing.org/our-initiatives/nursingcas-application-service |
| S16 | ASPPH | SOPHAS — Centralized Application Service for Public Health (site cycle banner may lag) | https://aspph.org/student-journey/sophas/ |
| S17 | LSAC | JD Application Requirements (current) | https://www.lsac.org/applying-law-school/jd-application-process/jd-application-requirements |
| S18 | LSAC | Specifications of the LSAT and LSAT Argumentative Writing (2026–27) | https://www.lsac.org/lsat/register-lsat/accommodations/specifications-lsat-and-lsat-argumentative-writing |
| S19 | LSAC | LSAT Argumentative Writing (current) | https://www.lsac.org/lsat/about/lsat-argumentative-writing |
| S20 | American Bar Association | 2026–27 Standards for Approval of Law Schools (2026–27) | https://www.americanbar.org/groups/legal_education/accreditation/standards/ |
| S21 | American Bar Association | Standard 503 Variance Application (2026–29 application dates) | https://www.americanbar.org/groups/legal_education/accreditation/questionnaires/503-variance/ |
| S22 | American Bar Association | ABA Required Disclosures and Statistics (current) | https://www.americanbar.org/groups/legal_education/accreditation/statistics/ |
| S23 | GMAC | GMAT Exam (Focus Edition) (current) | https://www.gmac.com/gmat-other-assessments/about-the-gmat-focus-edition/gmat-focus-edition |
| S24 | UCAS | 2027-entry Dates and Deadlines (2027 entry) | https://www.ucas.com/applying/applying-to-university/dates-and-deadlines-for-uni-applications |
| S25 | UCAS | Personal Statement Toolkit: Three Questions (2027 entry) | https://www.ucas.com/advisers/help-and-training/toolkits/personal-statement-toolkit |
| S26 | UCAT Consortium | UCAT Test Format and Scoring (2026 cycle format) | https://www.ucat.ac.uk/about-ucat/test-format-and-scoring/ |
| S27 | Dental Schools Council | Dental School Entry Requirements for October 2027 Entry (2027 entry) | https://www.dentalschoolscouncil.ac.uk/making-an-application/uk-dental-school-entry-requirements/ |
| S28 | AFMC | Admission Requirements of Canadian Faculties of Medicine (2027 guide listed) | https://www.afmc.ca/data-holdings/afmc-admission-requirements-of-canadian-faculties-of-medicine/ |
| S29 | UCAT ANZ | UCAT ANZ Universities and Test Requirement (2026 test / 2027 entry) | https://www.ucat.edu.au/about-ucat-anz/universities/ |
| S30 | ACER | Graduate Medical School Admissions Test (GAMSAT) (2026) | https://gamsat.acer.org/ |
| S31 | National Testing Agency (India) | NEET(UG) 2026 official site (2026) | https://neet.nta.nic.in/ |
| S32 | Consortium of National Law Universities | CLAT 2027 official information (2027 entry) | https://consortiumofnlus.ac.in/clat-2027/index.html |
| S33 | ECFMG / Intealth | World Directory Sponsor Notes and Recognized Accreditation Policy (2026) | https://ecfmg.org/resources/sponsor-notes.html |
| S34 | General Medical Council | Institutions Awarding UK Medical Degrees (current) | https://www.gmc-uk.org/education/how-we-quality-assure-education-and-training/approving-education-and-training/institutions-awarding-uk-medical-degrees |
| S35 | Accreditation Council for Pharmacy Education | ACPE Program Lookup (current) | https://www.acpe-accredit.org/program-lookup/ |
| S36 | Medical Education research | Insights into undergraduate medical student selection tools: systematic review and meta-analysis (2024) | https://pmc.ncbi.nlm.nih.gov/articles/PMC11494217/ |
| S37 | Medical Education research | Best practices for interviewing applicants for medical school admissions: systematic review (2022) | https://pmc.ncbi.nlm.nih.gov/articles/PMC9510545/ |
| S38 | Medical Education research | Validity of constructed-response situational judgement tests: systematic review and meta-analysis (2026) | https://pubmed.ncbi.nlm.nih.gov/42242715/ |
| S39 | JAMA Network Open | Applicant Demographics and Multiple Mini Interview Performance at a Medical School Over 5 Years (2026) | https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2848010 |
| S40 | LSAC Research | 2024–25 Law School Applicant Profile (2024–25 applicant cohort) | https://www.lsac.org/data-research/research/lsacs-knowledge-report-2024-25-law-school-applicant-profile |
| S41 | LSAC | Statement of Good Admission and Financial Aid Practices (current) | https://www.lsac.org/about/lsac-policies/statement-good-admission-and-financial-aid-practices |
| S42 | PharmCAS | Deadlines, Priority versus Final Deadline (2026–27) | https://www.pharmcas.org/application-instructions/deadlines |
| S43 | UCAS | Medicine Personal Statement Guide (current) | https://www.ucas.com/applying/applying-to-university/writing-your-personal-statement/personal-statement-guides/medicine-personal-statement-guide |
| S44 | LSAC | Misconduct and Irregularities (current) | https://www.lsac.org/applying-law-school/misconduct-irregularities |
| S45 | LSAC | Letters of Recommendation (current) | https://www.lsac.org/applying-law-school/jd-application-process/credential-assembly-service-cas/letters-recommendation |
| S46 | AACN | 2026–27 NursingCAS Cycle Launch (August 2026) | https://www.aacnnursing.org/news-data/all-news/article/2026-2027-nursingcas-application-cycle-launch |
| S47 | PAEA | CASPA Program Directory (2026–27) | https://paeaonline.org/our-programs |
| S48 | GMC | Approving education and training (current) | https://www.gmc-uk.org/education/how-we-quality-assure-education-and-training/approving-education-and-training |
| S49 | NTA India | 2026 NEET UG Admission Bulletin (2026) | https://neet.nta.nic.in/admission-bulletin/ |
| S50 | UCAT ANZ | 2026 UCAT ANZ Test Cycle (2026) | https://www.ucat.edu.au/about-ucat-anz/ucat-anz-test-cycle/ |
| S51 | AAMC | Before You Apply — 2027 AMCAS (2027 cycle) | https://students-residents.aamc.org/how-apply-medical-school-amcas/you-apply |
| S52 | LSAC | 2026 LSAT format and modality (current) | https://www.lsac.org/lsat/prepare/types-lsat-questions |
| S53 | AFMC | Aspirants and Applicants / 2027 Guide (2027 guide listed) | https://www.afmc.ca/strategic-priorities/education/aspirants-applicants/ |
| S54 | Consortium of NLUs | CLAT 2027 UG Instructions (2027 entry) | https://clat2027.consortiumofnlus.ac.in/clat-2027/ug-instructions.html |
| S55 | AAMC | Structured interview rubric practices (current) | https://www.aamc.org/services/admission-interview-foundations/conducting-effective-structured-interviews |
| S56 | ECFMG | 2026 ECFMG Certification Requirements (2026) | https://www2.ecfmg.org/2026ib/certification-requirements.html |

## Evidence governance

- **Official-policy status:** current rules must be checked against primary issuing authorities; this profile is not their substitute.
- **Empirical-research status:** prediction, fairness, measurement and AI claims need population-specific validation.
- **Designed-construct status:** ontology, archetypes, operational cycles and taxonomies are an original design, not scientific discoveries.
- **Frontier status:** causal and AI proposals are research hypotheses and require independent safety/validity evaluation.
