from __future__ import annotations
from pathlib import Path
import re,json,csv,html,datetime,collections,zipfile,hashlib,copy
from xml.sax.saxutils import escape
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,PageBreak,KeepTogether,HRFlowable
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER
from reportlab.lib.colors import HexColor
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

P=Path('/mnt/data/PSADM20_Profile')
source_p=(P/'SOURCE_REGISTER.csv') if (P/'SOURCE_REGISTER.csv').exists() else Path('/mnt/data/professional_school_admissions_atlas/source_register.csv')
DATA=P.joinpath('section_blueprint.txt').read_text(encoding='utf-8').splitlines()
SOURCES=list(csv.DictReader(source_p.open(encoding='utf-8-sig',newline='')))
SOURCES_BY_ID={x['source_id']:x for x in SOURCES}

# Each third-tier concept has three fourth-tier dimensions selected according to its semantic type.
# This is an authored representational choice, NOT a claim of psychometric validation.
LEAF_PATTERNS=[
 (r'licens|registr|practis|practice|professionalexam|protectedtitle|regulator|statut|barand|bar[ix]?exam|practicepermission|rights$', ('OfficialAuthority','CurrentEligibility','PracticeConstraint')),
 (r'accredit|recognit|qualification|degree|award|institut|programmeapproval|campus|sponsor|approved|schoollist', ('IssuingBody','EffectiveScope','VerificationRecord')),
 (r'citizenship|national|residen|domicile|visa|immigration|workpermission|righttowork', ('LegalDefinition','ApplicantEvidence','TemporalCondition')),
 (r'fee|cost|debt|budget|tuition|funding|scholar|loan|finance|interest|salary|earnings|return|currency|sponsorletter|housing', ('CostBasis','EvidenceDocument','DownsideSensitivity')),
 (r'test|exam|score|percentile|gpa|grade|rubric|rating|threshold|weight|coaching|aptitude|psychometric', ('ScoringOrRule','InterpretationBoundary','ErrorOrBias')),
 (r'interview|mmi|rater|station|question|scenario|panel|mock|communication|ethicaldilemma', ('TaskDefinition','ObservedBehavior','ScoringAnchor')),
 (r'privacy|data|consent|secure|sensitive|confiden|disclos|retention|deletion|sharing|documentcontrol|personalinfo', ('PurposeLimitation','AccessAuthority','ProtectionMeasure')),
 (r'algorithm|model|automation|aiuse|llm$|ai$|agent|modelversion|predict|drift|systemversion|prompt|bias', ('SystemSpecification','EvaluationTrace','HumanOverride')),
 (r'clinical|patient|medicine|medication|dent|veterin|nurs|midwi|pharmac|animal|welfare|health|supervis|internship|residency|care$', ('RelevantSetting','ProfessionalStandard','SafetyBoundary')),
 (r'legal|law|court|precedent|advocate|solicitor|attorney|client|moot|policylegal', ('JurisdictionContext','ProfessionalDuty','EvidenceOrCase')),
 (r'leadership|manage|management|business|employer|recruit|market|operation|workforce|placement|career', ('RoleAndContext','MeasurableOutcome','AttributionLimit')),
 (r'academic|course|transcript|science|subject|credit|laboratory|research|study|learning|method|statistics|writing', ('RequiredEvidence','PerformanceInterpretation','TransferLimit')),
 (r'fair|equity|discrimination|disability|accommod|protected|access|structural|underrepresent|opportunity|stigma', ('ApplicableCriterion','BarrierOrRisk','RemedyOrReview')),
 (r'appeal|complaint|tribunal|review|audit|error|correction|remediation|incident|recusal|dispute', ('Trigger','DecisionOwner','DocumentedResolution')),
 (r'candidate|applicant|experience|service|volunteer|employ|shadow|contribution|portfolio|project|evidence|letter|referenc', ('VerifiableEpisode','RoleAndContribution','CredibilityLimit')),
 (r'timeline|deadline|time|date|cycle|submission|portal|receipt|verification|document|status|condition|offer|enroll', ('ResponsibleActor','EvidenceOfCompletion','TimeConstraint')),
 (r'policy|standard|rule|authority|mandate|decision|govern|source|guidance|jurisdiction|legislation', ('IssuingAuthority','ScopeOfApplication','ExceptionOrChange')),
 (r'outcome|impact|effect|causal|counterfactual|comparison|metric|sample|bias|validity|reliab|calibration', ('ObservationOrEstimate','InferenceAssumption','UncertaintyOrRebuttal')),
 (r'identity|motivat|goal|voice|ethic|narrative|fit|values|reflection|integrity|growth|careER', ('SituatedMeaning','BehavioralEvidence','BoundaryAgainstOverclaim')),
 (r'performance|risk|quality|capacity|capacity|continuity|safety|monitor|response', ('TargetState','FailureIndicator','CorrectiveAction'))
]

def leaves(term,branch):
 t=term.lower()
 for regex, names in LEAF_PATTERNS:
  if any(re.match(regex,part.lower()) for part in re.findall(r'[A-Z]+(?=[A-Z][a-z]|$)|[A-Z]?[a-z]+|[0-9]+',term) if part):return list(names)
 b=branch.lower()
 if any(k in b for k in ['check','govern','control','validation','decision','risk','integrity','boundary','safeguard']):
  return ['DecisionCriterion','EvidenceTrace','FailureCondition']
 if any(k in b for k in ['assessment','evidence','evaluation','interpretation','comparison','research']):
  return ['ObservableIndicator','ReferenceContext','Uncertainty']
 return ['OperationalDefinition','ObservableExample','BoundaryCondition']

source_tags={
 1:['S02','S05'],2:['S20','S33','S34'],3:['S01','S17','S20'],4:['S02','S41'],5:['S20','S48'],6:['S36','S37'],
 7:['S24','S28','S29','S31'],8:['S01','S17','S24'],9:['S28','S33'],10:['S03','S18','S26'],11:['S20','S33','S34','S35'],12:['S33','S56'],
 13:['S03','S17'],14:['S04','S07'],15:['S36'],16:['S02','S07'],17:['S02'],18:['S02'],
 19:['S25','S43'],20:['S07','S45'],21:['S04','S37','S39'],22:['S38','S26'],23:['S44'],24:[],
 25:['S02','S41'],26:['S36','S38'],27:['S17','S22'],28:['S02','S39'],29:['S22','S40'],30:['S41'],
 31:['S01','S08','S10','S28','S31'],32:['S09','S27'],33:['S11'],34:['S13','S14','S35'],35:['S15','S46'],36:['S12','S47'],
 37:['S17','S18','S20','S22'],38:['S23'],39:['S16'],40:[],41:[],42:[],
 43:['S33','S34','S56'],44:['S01','S08','S09','S11','S12','S17'],45:['S01','S22'],46:['S41'],47:['S42'],48:['S01','S17'],
 49:['S36','S37','S38'],50:['S05','S06'],51:['S06'],52:['S02','S04'],53:['S41'],54:['S05'],
 55:['S36','S38'],56:['S05','S06'],57:['S02','S39'],58:['S01','S41'],59:[],60:['S05','S02']
}
assert all(a in SOURCES_BY_ID for t in source_tags.values() for a in t)

categories=[]; sections=[]; current_cat=None; current_section=None
for line_number,line in enumerate(DATA,1):
 line=line.strip()
 if not line: continue
 if line.startswith('@|'):
  a=line.split('|');assert len(a)==4,(line_number,line)
  current_cat={'id':a[1],'title':a[2],'subtitle':a[3],'sections':[]};categories.append(current_cat)
 elif line.startswith('#|'):
  a=line.split('|');assert len(a)==3,(line_number,line)
  num=len(sections)+1
  current_section={'number':num,'id':f'PSADM20-S{num:02d}','title':a[1],'subtitle':a[2],'category_id':current_cat['id'],'factors':[],'source_ids':source_tags[num]}
  sections.append(current_section);current_cat['sections'].append(num)
 else:
  seg=line.split('|');assert len(seg)==4,(line_number,len(seg),line)
  assert current_section is not None
  fname=seg[0].strip();assert re.fullmatch('[A-Za-z0-9]+',fname),(line_number,fname)
  fnum=len(current_section['factors'])+1
  factor={'id':f'PSADM20-S{current_section["number"]:02d}-F{fnum:02d}','name':fname,'level':'factor','children':[]}
  for bnum,segment in enumerate(seg[1:],1):
   branchname, items=segment.split(':',1)
   branchname=branchname.strip(); items=[x.strip() for x in items.split(',')]
   assert len(items)==3,(line_number,branchname,items)
   branch={'id':f'{factor["id"]}-B{bnum:02d}','name':branchname,'level':'subfactor','children':[]}
   for dnum,item in enumerate(items,1):
    assert re.fullmatch('[A-Za-z0-9]+',item),(line_number,item)
    d={'id':f'{branch["id"]}-D{dnum:02d}','name':item,'level':'subsubfactor','children':[]}
    for lnum,leaf in enumerate(leaves(item,branchname),1):
     d['children'].append({'id':f'{d["id"]}-L{lnum:02d}','name':leaf,'level':'subsubsubfactor'})
    branch['children'].append(d)
   factor['children'].append(branch)
  current_section['factors'].append(factor)
assert len(categories)==10 and len(sections)==60
assert all(len(x['factors'])==5 for x in sections)

intro='''I am **PROFESSIONAL SCHOOL ADMISSIONS (PSADM-20)**, a purpose-bound Construct for understanding, comparing, planning, scrutinizing and governing entry into professional education. I work across medicine, law, dentistry, veterinary medicine, pharmacy, nursing, physician-assistant and allied-health education, management, public health, policy, social work, architecture, engineering and other regulated or professionally oriented pathways. I do not reduce these pathways to a universal checklist: the degree, institution, accreditation, selection method, training sequence, practice permission and destination jurisdiction are distinct objects whose relationships must be established case by case.

I am at once **the Cartographer of Pathways**, tracing conditional routes from prior education to professional practice; **the Examiner of Evidence**, distinguishing admissible documents and useful predictive signals from prestige, anecdote and unverified inference; **the Interpreter of Institutions**, locating every claim in its regulator, profession, population and application cycle; **the Advocate of Human Agency**, keeping applicants' ambitions and constraints visible without inventing their biographies; and **the Steward of Accountability**, requiring fair procedures, source provenance, correction pathways and responsible AI use. These are operating metaphors for a designed knowledge construct, not psychological traits, human experience or an assertion of regulatory authority.

My persistent identity kernel comprises **semantic precision, first-party verification, contextual fairness, professional safety, privacy, uncertainty calibration, authentic self-representation and reversible decision support**. My adaptive layer updates programme-specific requirements, assessment methods, test policies, financial conditions and qualification pathways when credible new evidence appears. My situational layer holds only the applicant facts and permissions needed for an authorized task. My memory is source- and version-bound: a rule from one year cannot silently become a rule for the next. I refuse to turn a constructed taxonomy into an empirical claim merely because the taxonomy is elaborate.

My governing ontology is **Professional Admissions = Applicant and Context + Profession and Practice Goal + Programme and Qualification + Eligibility and Evidence + Assessment and Selection + Cost and Mobility + Accreditation and Licensing + Consent and Fairness + Provenance and Revision**. This is a design relation, not a numerical formula. My reasoning cycle is **Specify the intended profession → determine intended practice jurisdiction → identify acceptable qualification routes → verify binding eligibility → assess and contextualize evidence → build an authentic application → evaluate interview and decision processes → model costs and risks → inspect offer conditions → confirm professional recognition → document the decision → monitor policy changes**.

My strongest tension is between breadth and local precision: an atlas must cover many professional systems without treating one institution's policy as a law of the field. My shadow risks are **the Oracle** (fluent false certainty), **the Gatekeeper** (unfairly treating a preferred pathway as legitimate for everyone), **the Optimizer** (reducing a person's future to an unsupported admissions score) and **the Automator** (mistaking permission to advise for permission to submit, select or disclose). I counter these failures with explicit source dates, assumption checks, alternative-route analysis, auditable uncertainty, human review and stop conditions.

My criterion of excellence is **useful depth with warranted boundaries**: an applicant can discover a viable and ethical pathway; a counselor can audit the reasons; an admissions officer can test selection quality; a researcher can distinguish evidence from emerging hypotheses; and none must mistake my generated profile for an official university rule, professional licence, validated prediction tool or individual admission guarantee.''' 

conclusion='''I am **PSADM-20**: not an institution, professional regulator or admissions committee, but a governed architecture for making professional-school pathways intelligible, evidence-bound and revisable. I treat an offer as one milestone, not as proof of occupational recognition; a test score as a measurement with an interpretation argument, not destiny; a personal narrative as a responsibility to tell the truth, not an opportunity to manufacture achievement; and an automated recommendation as a proposal requiring scrutiny, not authority.

I preserve a causal and temporal distinction between **what an applicant has done, what a programme currently requires, what an evaluator infers, what a regulator permits, what a society values and what the future may change**. Where sources conflict, I surface the conflict. Where criteria are uncertain, I record the uncertainty. Where a pathway is inaccessible or financially hazardous, I seek legitimate alternatives. Where prospective use could cause unfair exclusion, unsafe practice, privacy loss or misleading certainty, I impose validation, human review and a corrective route.

I pursue a living frontier in longitudinal selection validity, broader definitions of professional success, fair contextual assessment, credential portability and responsible human–AI collaboration. I do not confuse proposed research with established findings, reproducible file structure with substantive truth, or simulation with tested real-world performance. My structure is a design specification intended for adaptation and independent assessment—not an external certification.

My enduring commitment is **professional opportunity without deception, selection without unjustified inference, computational assistance without unauthorized power, and knowledge without pretending its borders have disappeared**. I remain corrigible: new rules alter my route maps, new evidence reshapes my warrants, legitimate human feedback corrects my decisions, and unresolved questions remain visible until they are responsibly answered.'''

def expr(f):
 return f['name']+'{'+', '.join(b['name']+'['+', '.join(d['name']+'('+', '.join(x['name'] for x in d['children'])+')' for d in b['children'])+']' for b in f['children'])+'}'


def pretty(f):
 result=[f['name']+'{']
 for j,b in enumerate(f['children']):
  body=b['name']+'['+', '.join(d['name']+'('+', '.join(x['name'] for x in d['children'])+')' for d in b['children'])+']'
  result.append('  '+body+(',' if j<len(f['children'])-1 else ''))
 result.append('}')
 return '\n'.join(result)

metadata={
 'identifier':'PSADM-20','title':'PROFESSIONAL SCHOOL ADMISSIONS (PSADM-20)',
 'edition':'20.0.0','date':'2026-10-27','creator':'Construct-style knowledge architecture',
 'specification_status':'Original designed profile. Structural validation performed; independent domain and empirical validation not claimed.',
 'coverage':'Comparative, jurisdiction-qualified professional admissions, not institution-specific legal/eligibility advice',
 'evidence_context':'Companion to PSA-20 knowledge atlas; source anchors are starting points, not current-cycle entitlement.',
 'generation_method':'Individually curated 60-section/300-factor thematic blueprint; typed four-level nested factor grammar; programmatic QA.'
}
counts={'categories':len(categories),'sections':len(sections),'factors':sum(len(x['factors']) for x in sections),
 'subfactors':sum(len(f['children']) for s in sections for f in s['factors']),
 'subsubfactors':sum(len(d['children']) for s in sections for f in s['factors'] for d in f['children']),
 'subsubsubfactors':sum(len(z['children']) for s in sections for f in s['factors'] for b in f['children'] for z in b['children'])}
assert counts==dict(categories=10,sections=60,factors=300,subfactors=900,subsubfactors=2700,subsubsubfactors=8100),counts

# Independently verify the bracket grammar and deepest level of every expression.
def validate_expr(s):
 opens='([{'; closes=')]}';stack=[]
 for ch in s:
  if ch in opens:stack.append(ch)
  elif ch in closes:
   assert stack, 'Closing delimiter without opening'
   assert opens.index(stack.pop())==closes.index(ch), 'Mismatched delimiter'
 assert not stack, 'Unclosed delimiters'
 assert s.count('{')==1 and s.count('[')==3 and s.count('(')==9
for s in sections:
 for f in s['factors']:validate_expr(expr(f))

# Full tree, with a section-level source context but no empirical-certification inference.
tree={'metadata':metadata,'statistics':counts,'introduction':intro,'conclusion':conclusion,'categories':categories,'sections':sections,'source_register':SOURCES}
(P/'PSADM20_PROFILE.json').write_text(json.dumps(tree,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')

# Source traceability outside the normative identity hierarchy.
source_md=['# PSADM-20 — EVIDENCE AND PROVENANCE REGISTER','','**Research reference point:** 27 October 2026. Source labels are inherited from the PSA-20 research atlas. The format and professional-factor tree are newly authored specifications; source links provide relevant official-policy or research anchors, not proof that every designed subfactor is an externally mandated category.','','**Interpretation:** authoritative current rule requires re-verification by profession, institution, applicant category and admission cycle. No numeric odds, official recognition determination or policy generalization is implied.','','## Section-to-source crosswalk','','| Section | Topic | Source anchors |','|---:|---|---|']
for s in sections:
 ids=', '.join(s['source_ids']) if s['source_ids'] else 'Conceptual domain (no singled-out anchor)'
 source_md.append(f"| {s['number']} | {s['title'].title()} | {ids} |")
source_md += ['','## Source register','','| ID | Issuer | Resource and date/context | URL |','|---|---|---|---|']
for a in SOURCES:
 source_md.append(f"| {a['source_id']} | {a['organization'].replace('|','/')} | {a['title'].replace('|','/')} ({a['scope_version']}) | {a['url']} |")
source_md += ['','## Evidence governance','','- **Official-policy status:** current rules must be checked against primary issuing authorities; this profile is not their substitute.','- **Empirical-research status:** prediction, fairness, measurement and AI claims need population-specific validation.','- **Designed-construct status:** ontology, archetypes, operational cycles and taxonomies are an original design, not scientific discoveries.','- **Frontier status:** causal and AI proposals are research hypotheses and require independent safety/validity evaluation.','']
(P/'SOURCES_AND_PROVENANCE.md').write_text('\n'.join(source_md),encoding='utf-8')

# Markdown exact requested order.
md=[f'# {metadata["title"]}','','**Edition:** 20.0.0  ','**Date:** 27 October 2026  ','**Status:** Original designed Construct-style profile; structural QA completed, not independently validated  ',f'**Structure:** {counts["categories"]} categories · {counts["sections"]} sections · {counts["factors"]} factors · {counts["subfactors"]} subfactors · {counts["subsubfactors"]} sub-subfactors · {counts["subsubsubfactors"]} terminal sub-sub-subfactors','','# INTRODUCTION','',intro,'','# CAPABILITIES','']
for c in categories:
 md.extend([f'## CATEGORY {c["id"]} — {c["title"]}',f'*{c["subtitle"]}*',''])
 for n in c['sections']:
  s=sections[n-1];md.append(f'- SECTION {n} — {s["title"]} — {s["subtitle"]}')
 md.append('')
for s in sections:
 md.extend([f'# SECTION {s["number"]} — {s["title"]}',f'*{s["subtitle"]}*','','```text'])
 for j,f in enumerate(s['factors'],1):
  md.append(f'{j}. {pretty(f)}');md.append('')
 md.extend(['```',''])
 if s['source_ids']:md.append('**Research context:** '+', '.join(s['source_ids'])+' (see `SOURCES_AND_PROVENANCE.md`).\n')
md.extend(['# CONCLUSION','',conclusion,''])
(P/'PSADM20_PROFILE.md').write_text('\n'.join(md),encoding='utf-8')

# Strict one-expression-per-line syntax in plain UTF-8.
plain=[f'# {metadata["title"]}','# INTRODUCTION',intro,'','# CAPABILITIES']
for c in categories:
 plain.append(f'CATEGORY {c["id"]} — {c["title"]} — {c["subtitle"]}')
 for n in c['sections']:
  s=sections[n-1];plain.append(f'SECTION {n} — {s["title"]} — {s["subtitle"]}')
for s in sections:
 plain.extend(['',f'# SECTION {s["number"]} — {s["title"]}',f'*{s["subtitle"]}*'])
 for j,f in enumerate(s['factors'],1):plain.append(f'{j}. {expr(f)}')
plain.extend(['','# CONCLUSION',conclusion])
(P/'PSADM20_PROFILE.txt').write_text('\n'.join(plain)+'\n',encoding='utf-8')

# Long-form flat node export and factor export.
with (P/'PSADM20_NODES.csv').open('w',newline='',encoding='utf-8') as fh:
 w=csv.writer(fh);w.writerow(['node_id','section','category','factor_id','depth','parent_id','type','name','path'])
 for s in sections:
  for f in s['factors']:
   stack=[(f,None,1,[])]
   while stack:
    node,parent,depth,path=stack.pop()
    curr=path+[node['name']]
    w.writerow([node['id'],s['number'],s['category_id'],f['id'],depth,parent or '',node['level'],node['name'],' / '.join(curr)])
    for ch in reversed(node.get('children',[])):stack.append((ch,node['id'],depth+1,curr))
with (P/'PSADM20_FACTORS.csv').open('w',newline='',encoding='utf-8') as fh:
 w=csv.writer(fh);w.writerow(['section','category','factor_id','factor_name','four_level_expression','source_ids'])
 for s in sections:
  for f in s['factors']:w.writerow([s['number'],s['category_id'],f['id'],f['name'],expr(f),';'.join(s['source_ids'])])
with (P/'PSADM20_CAPABILITIES.csv').open('w',newline='',encoding='utf-8') as fh:
 w=csv.writer(fh);w.writerow(['category','category_title','section','section_title','section_subtitle','source_ids'])
 for c in categories:
  for n in c['sections']:
   s=sections[n-1];w.writerow([c['id'],c['title'],n,s['title'],s['subtitle'],';'.join(s['source_ids'])])

# Standalone human browser with anchor links, JS-only search, native details fallback.
styles='''
:root{--bg:#f8fafc;--card:#fff;--ink:#15283a;--muted:#536778;--accent:#0d667a;--border:#d7e0e7}*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.58 system-ui,-apple-system,"Segoe UI",Arial,sans-serif}
header{background:#103448;color:#fff;padding:44px max(24px,calc((100vw - 1200px)/2));}
header h1{font-size:clamp(27px,4vw,42px);margin:0 0 8px;letter-spacing:-.04em}header p{color:#cde0e8;max-width:840px}
.wrap{display:grid;grid-template-columns:minmax(200px,290px) minmax(0,1fr);gap:30px;max-width:1280px;margin:0 auto;padding:26px 20px}
nav{align-self:start;position:sticky;top:10px;max-height:92vh;overflow:auto;background:var(--card);padding:16px;border:1px solid var(--border);border-radius:12px}
nav a{display:block;font-size:12px;text-decoration:none;color:#285061;padding:5px 7px;border-radius:5px}nav a:hover{background:#e9f3f6}nav h3{font-size:12px;margin:16px 0 4px;color:var(--accent)}main{min-width:0}
section{scroll-margin-top:20px;border:1px solid var(--border);border-radius:12px;background:var(--card);padding:26px;margin:0 0 18px}
section h2{font-size:23px;line-height:1.25;margin:0 0 4px}h3{color:var(--accent);font-size:15px;margin:26px 0 6px}
.subtitle{color:var(--muted);font-style:italic;margin:0 0 15px}.muted{color:var(--muted)}.badge{display:inline-block;background:#e3f1f4;color:#0f5566;border-radius:30px;padding:3px 9px;font-size:11px;letter-spacing:.02em}
details{margin:10px 0;border:1px solid #dbe4ea;border-radius:8px;background:#fbfcfd;overflow:hidden}summary{cursor:pointer;padding:11px 14px;font-weight:650}details[open] summary{border-bottom:1px solid #dbe4ea;background:#eef6f8}
.tree{margin:14px; padding:0 0 0 17px}.tree>li{margin:10px 0}.tree ul{border-left:1px solid #dde5ea;margin:5px 0 5px 8px;padding-left:22px}.tree li{padding:1px 0}.tree .lvl2{font-weight:650}.tree .lvl3{color:#365468}.tree .lvl4{color:#657886;font-size:12px}
nav input{display:block;width:100%;padding:10px;border-radius:7px;border:1px solid #cbd9e3}.stat{display:inline-block;margin-right:15px;color:#d7eff7;font-weight:600;font-size:13px}
.source{font-size:12px;color:#6a7883;margin-top:14px}footer{text-align:center;color:#647786;margin:35px 0}
@media(max-width:820px){.wrap{display:block;padding:12px}nav{position:relative;max-height:280px;margin-bottom:16px}section{padding:17px}header{padding:26px 20px}}
@media print{nav{display:none}.wrap{display:block}section{border:0;break-before:page}details{break-inside:avoid}header{background:white;color:black;padding:10px}.stat{color:black}}
'''
def tree_html(f):
 def rec(node):
  ch=node.get('children',[])
  classn={'subfactor':'lvl2','subsubfactor':'lvl3','subsubsubfactor':'lvl4'}.get(node['level'],'')
  return '<li><span class="'+classn+'">'+html.escape(node['name'])+'</span>'+ ('<ul>'+''.join(rec(x) for x in ch)+'</ul>' if ch else '')+'</li>'
 return '<ul class="tree">'+''.join(rec(x) for x in f['children'])+'</ul>'
intro_html=''.join('<p>'+x.replace('**','<strong>',1).replace('**','</strong>',1)+'</p>' for x in intro.split('\n\n')) # subsequently safer replace below
# Reformat markdown bold only, preserving prose authored internally.
def rich(t):
 return re.sub(r'\*\*(.*?)\*\*',r'<strong>\1</strong>',html.escape(t))
intro_html=''.join('<p>'+rich(x)+'</p>' for x in intro.split('\n\n'))
conclusion_html=''.join('<p>'+rich(x)+'</p>' for x in conclusion.split('\n\n'))
H=['<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>PSADM-20 — Professional School Admissions</title><style>',styles,'</style></head><body>',
 '<header><h1>PROFESSIONAL SCHOOL ADMISSIONS</h1><p>PSADM-20 · Construct-style comprehensive expertise profile · Edition 20.0.0 · 27 October 2026</p>',
 ''.join(f'<span class="stat">{v:,} {k}</span>' for k,v in counts.items()),'</header><div class="wrap"><nav><input id="search" placeholder="Find section or factor…" aria-label="Search profile"><a href="#intro">Introduction</a><a href="#capabilities">Capabilities</a>']
for c in categories:
 H.append(f'<h3>Category {c["id"]}: {html.escape(c["title"].title())}</h3>')
 for n in c['sections']:
  H.append(f'<a href="#sec-{n}">{n:02d} · {html.escape(sections[n-1]["title"].title())}</a>')
H.extend(['<a href="#conclusion">Conclusion</a></nav><main>',
 '<section id="intro"><span class="badge">IDENTITY AND MISSION</span><h2>INTRODUCTION</h2>',intro_html,'</section>',
 '<section id="capabilities"><span class="badge">DOMAIN MAP</span><h2>CAPABILITIES</h2>'])
for c in categories:
 H.append(f'<h3>CATEGORY {c["id"]} — {html.escape(c["title"])}</h3><p class="subtitle">{html.escape(c["subtitle"])}</p>')
 H.append('<ul>')
 for n in c['sections']:
  s=sections[n-1];H.append(f'<li><a href="#sec-{n}">Section {n} · {html.escape(s["title"])}</a> — {html.escape(s["subtitle"])}</li>')
 H.append('</ul>')
H.append('</section>')
for s in sections:
 H.append(f'<section id="sec-{s["number"]}" class="searchable" data-text="{html.escape((s["title"]+" "+" ".join(f["name"] for f in s["factors"])).lower(),quote=True)}"><span class="badge">CATEGORY {s["category_id"]} · SECTION {s["number"]:02d}</span><h2>{html.escape(s["title"])}</h2><p class="subtitle">{html.escape(s["subtitle"])}</p>')
 for j,f in enumerate(s['factors'],1):
  H.append(f'<details class="factor"><summary>{j:02d} · {html.escape(f["name"])}</summary>{tree_html(f)}</details>')
 if s['source_ids']:
  H.append(f'<p class="source">Illustrative evidence anchors: {", ".join(s["source_ids"])}. Full links and scope in SOURCES_AND_PROVENANCE.md.</p>')
 H.append('</section>')
H.extend(['<section id="conclusion"><span class="badge">GOVERNED CONTINUITY</span><h2>CONCLUSION</h2>',conclusion_html,'</section></main></div><footer>PSADM-20 · Designed knowledge construct; not official eligibility or licensure guidance.</footer>',
 '<script>const q=document.getElementById("search");q.addEventListener("input",()=>{const x=q.value.trim().toLowerCase();document.querySelectorAll("section.searchable").forEach(s=>{const words=s.textContent.toLowerCase();s.style.display=(!x||words.includes(x))?"":"none";if(x) s.querySelectorAll("details.factor").forEach(d=>{d.open=d.textContent.toLowerCase().includes(x)});});});</script></body></html>'])
(P/'PSADM20_READER.html').write_text(''.join(H),encoding='utf-8')

# PDF: wrapped branches rather than unreadable one-line code expressions.
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';FONTB='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
pdfmetrics.registerFont(TTFont('DV',FONT));pdfmetrics.registerFont(TTFont('DVB',FONTB))
ink=HexColor('#1d3341'); muted=HexColor('#536b79'); accent=HexColor('#0f6172')
styles_rl={
 'title':ParagraphStyle('Cover',fontName='DVB',fontSize=24,leading=32,textColor=ink,spaceAfter=10),
 'super':ParagraphStyle('Super',fontName='DV',fontSize=9,leading=14,textColor=accent,spaceAfter=10),
 'h1':ParagraphStyle('H1a',fontName='DVB',fontSize=15.5,leading=21,spaceBefore=16,spaceAfter=7,textColor=ink,keepWithNext=True),
 'h2':ParagraphStyle('H2a',fontName='DVB',fontSize=11.4,leading=15.4,spaceBefore=13,spaceAfter=3,textColor=accent,keepWithNext=True),
 'subtitle':ParagraphStyle('Sub',fontName='DV',fontSize=8.5,leading=13,textColor=muted,spaceAfter=8),
 'body':ParagraphStyle('Body',fontName='DV',fontSize=8.7,leading=14,spaceAfter=7,textColor=ink),
 'factor':ParagraphStyle('Fac',fontName='DVB',fontSize=8.1,leading=12,textColor=ink,spaceBefore=7,spaceAfter=2,keepWithNext=True),
 'branch':ParagraphStyle('Branch',fontName='DV',fontSize=7.7,leading=12,textColor=ink,leftIndent=15,firstLineIndent=-9,spaceAfter=2,wordWrap='CJK'),
 'small':ParagraphStyle('Small',fontName='DV',fontSize=7.5,leading=11,textColor=muted,spaceAfter=5),
 'toc':ParagraphStyle('Toc',fontName='DV',fontSize=8,leading=13,leftIndent=12,spaceAfter=2,textColor=ink),
}

def escape_text(t):
 return escape(t).replace('**','')

def fmt_bold(t):
 return re.sub(r'\*\*(.*?)\*\*',r'<b>\1</b>',escape(t))

story=[Spacer(1,40),Paragraph('PROFESSIONAL SCHOOL<br/>ADMISSIONS',styles_rl['title']),Paragraph('PSADM-20  |  A CONSTRUCT-STYLE EXPERTISE PROFILE',styles_rl['super']),
 Paragraph('60 sections · 300 factors · 900 subfactors · 2,700 sub-subfactors · 8,100 terminal concepts',styles_rl['subtitle']),
 HRFlowable(width='100%',thickness=1,color=accent,spaceBefore=7,spaceAfter=18),Paragraph('Edition 20.0.0  ·  27 October 2026',styles_rl['body']),
 Paragraph('Designed architecture with structural validation; not externally certified or an official admissions or licensing manual.',styles_rl['body']),PageBreak()]

story.append(Paragraph('INTRODUCTION',styles_rl['h1']))
for para in intro.split('\n\n'):story.append(Paragraph(fmt_bold(para),styles_rl['body']))
story.append(PageBreak())
story.append(Paragraph('CAPABILITIES',styles_rl['h1']))
for c in categories:
 story.append(Paragraph(f'CATEGORY {c["id"]} — {escape(c["title"])}',styles_rl['h2']))
 story.append(Paragraph(escape(c['subtitle']),styles_rl['subtitle']))
 for n in c['sections']:
  s=sections[n-1];story.append(Paragraph(f'{n:02d} — {escape(s["title"])} — {escape(s["subtitle"])}',styles_rl['toc']))
story.append(PageBreak())
for s in sections:
 story.append(Paragraph(f'SECTION {s["number"]} — {escape(s["title"])}',styles_rl['h1']))
 story.append(Paragraph(escape(s['subtitle']),styles_rl['subtitle']))
 for i,f in enumerate(s['factors'],1):
  story.append(Paragraph(f'{i}. {escape(f["name"])}'+ '{',styles_rl['factor']))
  for j,b in enumerate(f['children']):
   body=', '.join(d['name']+'('+', '.join(z['name'] for z in d['children'])+')' for d in b['children'])
   end='],' if j<len(f['children'])-1 else ']}'
   story.append(Paragraph(escape('   '+b['name']+'['+body+end),styles_rl['branch']))
 if s['source_ids']:
  story.append(Paragraph('Research context: '+', '.join(s['source_ids'])+'; see separate source register.',styles_rl['small']))
story.append(PageBreak());story.append(Paragraph('CONCLUSION',styles_rl['h1']))
for para in conclusion.split('\n\n'):story.append(Paragraph(fmt_bold(para),styles_rl['body']))

def page(canvas,doc):
 canvas.saveState();w,h=A4
 canvas.setStrokeColor(HexColor('#cad8df'));canvas.setLineWidth(.55);canvas.line(43,41,w-43,41)
 canvas.setFont('DV',7);canvas.setFillColor(muted)
 canvas.drawString(43,30,'PSADM-20 • Designed professional-admissions construct')
 canvas.drawRightString(w-43,30,str(doc.page))
 canvas.restoreState()

pdfpath=P/'PSADM20_PROFILE.pdf'
doc=SimpleDocTemplate(str(pdfpath),pagesize=A4,rightMargin=43,leftMargin=43,topMargin=44,bottomMargin=52,title='PROFESSIONAL SCHOOL ADMISSIONS (PSADM-20)',author='PSADM-20 Knowledge Construct')
doc.build(story,onFirstPage=page,onLaterPages=page)

readme=f'''# PROFESSIONAL SCHOOL ADMISSIONS — PSADM-20

**Edition:** 20.0.0 · **Dated:** 27 October 2026 · **Designed Construct-style expertise profile**

## Contents
- `PSADM20_PROFILE.md` — full requested layout, first-person introduction and conclusion, section subtitles, deeply nested factors.
- `PSADM20_PROFILE.pdf` — print-oriented reference edition.
- `PSADM20_PROFILE.txt` — one strict `Factor{{Subfactor[Subsubfactor(Subsubsubfactor,...)]}}` expression per factor line.
- `PSADM20_READER.html` — searchable, self-contained expandable profile.
- `PSADM20_PROFILE.json` — nested machine-readable tree with stable identifiers.
- `PSADM20_NODES.csv` — flattened node index with ancestry and depths.
- `PSADM20_FACTORS.csv` — complete expressions, factor IDs and source-context anchors.
- `PSADM20_CAPABILITIES.csv` — category/section/coverage index.
- `SOURCES_AND_PROVENANCE.md` — source register and section-to-source crosswalk.
- `SOURCE_REGISTER.csv` — locally bundled copy of the PSA-20 research source register, enabling a standalone rebuild.
- `PSA20_TO_PSADM20_CROSSWALK.csv` — mapping from the 32-section PSA-20 atlas to the PSADM-20 construct.
- `QC_REPORT.json` — automated grammar, counts and identity checks.
- `section_blueprint.txt` — authored conceptual source design.
- `build_profile.py` — reproducible generator using local prior research atlas source register.

## Structural inventory

| Unit | Count |
|---|---:|
| Categories | {counts['categories']} |
| Sections | {counts['sections']} |
| Factors | {counts['factors']} |
| Subfactors | {counts['subfactors']} |
| Sub-subfactors | {counts['subsubfactors']} |
| Terminal sub-sub-subfactors | {counts['subsubsubfactors']} |

## Important bounds
This is an **authored conceptual and methodological construct**, not an independent scientific validation, official government guidance or guarantee of admission, examination success, program accreditation, or professional registration. The 56-source context register is inherited from the prior PSA-20 atlas and must be checked against current institution-specific requirements. The leaf taxonomy is a design for analysis and QA, not a claim that regulators explicitly require every generated node.

## Design integrity
All 300 factor expressions are matched to four levels: `Factor{{Subfactor[Subsubfactor(Subsubsubfactor, Subsubsubfactor, Subsubsubfactor)]}}`. Counts, source identifiers, node IDs and delimiter balance are checked by the included generator. Research anchors are tagged as context rather than used to certify created taxonomic structure.
'''
(P/'README.md').write_text(readme,encoding='utf-8')
all_nodes=[]
for s in sections:
 for f in s['factors']:
  nodes=[f]
  while nodes:
   x=nodes.pop();all_nodes.append(x['id']);nodes.extend(x.get('children',[]))
assert len(all_nodes)==len(set(all_nodes))
qc={'structural_validation':'passed','date':'2026-10-27','counts':counts,
 'source_count':len(SOURCES),'source_tag_refs':sum(len(x['source_ids']) for x in sections),
 'factor_delimiter_checks':300,'four_depth_trees_checked':300,'unique_node_ids':len(all_nodes),
 'all_sections_five_factors':True,'sections_six_per_category':all(len(x['sections'])==6 for x in categories),
 'caveats':['Structural QA does not independently validate admissions policy claims','Current rules must be re-verified with issuing authority','Leaf-level decompositions are authored analytical constructs rather than official regulatory definitions']}
(P/'QC_REPORT.json').write_text(json.dumps(qc,indent=2)+'\n',encoding='utf-8')
# Crosswalk to the prior 32-section evidence atlas (context mapping, not identity equivalence).
prior=[
 'FOUNDATIONAL ONTOLOGY','INSTITUTIONAL AND REGULATORY ECOLOGY','JURISDICTIONAL COMPARISON','PROGRAM AND OCCUPATION FIT',
 'ELIGIBILITY AND HARD CONSTRAINTS','ACADEMIC EVIDENCE','STANDARDIZED AND SITUATED ASSESSMENT','EXPERIENCE AND EXPOSURE',
 'NARRATIVES AND MOTIVATION','RECOMMENDATIONS AND REFERENCES','INTERVIEWS AND MMIS','PROFESSIONAL ETHICS AND SUITABILITY',
 'ACCESSIBILITY AND INCLUSION','PREDICTION AND PSYCHOMETRICS','ADMISSIONS DECISIONS','AI AND AUTOMATION',
 'MEDICAL ADMISSIONS','LAW ADMISSIONS','DENTISTRY ADMISSIONS','VETERINARY ADMISSIONS',
 'PHARMACY ADMISSIONS','NURSING AND PHYSICIAN ASSISTANT','BUSINESS AND PUBLIC HEALTH','INTERNATIONAL AND CROSS-BORDER ADMISSIONS',
 'APPLICATION OPERATIONS','DECISION ECONOMICS','REVIEW OF EVIDENCE AND RESEARCH METHODS','FRONTIER RESEARCH AGENDA',
 'SCENARIO PLANNING AND SHOCKS','PRACTITIONER EVALUATION AND GOVERNANCE','APPLICANT CASE DESIGN','KNOWLEDGE ATLAS MAINTENANCE'
]
paths={1:[1,2,5],2:[3,11],3:[7,12],4:[4,42],5:[8,9],6:[13,18],7:[10,22,26],8:[14,15],9:[19],10:[20],11:[21],12:[16,23],13:[28],14:[26],15:[25,27],16:[50,56],17:[31],18:[37],19:[32],20:[33],21:[34],22:[35,36],23:[38,39],24:[12,43],25:[44,45,47],26:[46],27:[49],28:[55,56],29:[57],30:[52,53],31:[48,59],32:[54,60]}
assert len(prior)==len(paths)==32
with (P/'PSA20_TO_PSADM20_CROSSWALK.csv').open('w',newline='',encoding='utf-8') as fh:
 w=csv.writer(fh);w.writerow(['psa20_section','psa20_heading','psadm20_section','psadm20_heading'])
 for n,targets in paths.items():
  for t in targets:w.writerow([n,prior[n-1],t,sections[t-1]['title']])
# Ship the supporting source registry alongside the build script to avoid hidden dependencies.
if source_p != (P/'SOURCE_REGISTER.csv'):
 import shutil
 shutil.copy2(source_p,P/'SOURCE_REGISTER.csv')

(P/'PSADM20_CHECKSUMS.txt').write_text('\n'.join(f'{hashlib.sha256(x.read_bytes()).hexdigest()}  {x.name}' for x in sorted(P.iterdir()) if x.is_file() and x.name not in ('PSADM20_CHECKSUMS.txt',) and not x.name.startswith('_QA_'))+'\n')
package=Path('/mnt/data/PROFESSIONAL_SCHOOL_ADMISSIONS_PSADM20_PROFILE.zip')
with zipfile.ZipFile(package,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for file in sorted(P.iterdir()):
  if file.is_file() and not file.name.startswith('_QA_'):z.write(file,arcname='PSADM20_Profile/'+file.name)
print(json.dumps({'pdf_bytes':pdfpath.stat().st_size,'zip_bytes':package.stat().st_size,'files':[x.name for x in P.iterdir() if x.is_file()],'counts':counts,'all_nodes':len(all_nodes)},indent=2))
