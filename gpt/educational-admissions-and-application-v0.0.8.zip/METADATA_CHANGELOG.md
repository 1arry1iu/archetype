# Skill Metadata and Manifest Change Log

## 0.0.8 — 27 October 2026

This release updates **manifest discovery metadata** and **YAML frontmatter for all 40 skills**. No substantive skill-body instructions, integration appendices, original references, bundled assets, plugin identity, sharing configuration, or default prompts were changed.

### Manifest

- Updated plugin description to reflect all 40 specialist and orchestration skills.
- Updated the listing's short and long descriptions for broader, accurately bounded educational coverage.
- Refreshed the keyword list to match implemented skills without implying guaranteed outcomes.
- Synchronized the version, description, listing metadata and keywords in `plugin.json` and `.codex-plugin/plugin.json`.
- Retained exact existing `name`, `author`, `displayName`, `developerName`, `brandColor`, `category`, `capabilities`, icon paths, and all three `defaultPrompt` strings in their existing order.

### All skill frontmatter

- Retained the exact existing `name` on each `skills/<skill>/SKILL.md`.
- Replaced each `description` with a specialist-specific invocation trigger and competence boundary; removed references to nonexistent skills where applicable.
- Added an optional, string-valued `metadata` map with `construct_id`, `domain_group`, `integration_appendix`, `plugin`, and `routing_role`.
- The metadata does **not** declare tool requirements or automatic cross-skill dependencies. The existing integration appendices remain authoritative for conditional delegation.
- Skill profile edition identifiers are stable Construct IDs, not independent claims of professional accreditation or verified external policy.

### Integrity and lifecycle

- Original bodies remain byte-for-byte identical beyond the closing YAML delimiter, including the integration appendix and its resources.
- All 40 revised YAML frontmatter blocks were parsed and checked for valid and unique names, correct Construct IDs, and a file size below 1 MiB.
- Plugin-wide QA details are recorded in the external `metadata-upgrade-qa.json` artifact accompanying this release.
