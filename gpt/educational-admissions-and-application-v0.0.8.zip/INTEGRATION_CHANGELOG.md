# Educational Admissions and Application — Integration Change Log

## 0.0.7 — 2026-10-27

- Added a standardized, tailored, five-section **Skill Integration Appendix** to all **40** `skills/*/SKILL.md` entrypoints.
- Inventoried verified references per skill with member-selection and provenance rules. No skill-local `assets/` were present; root branding is identified accurately as `assets/logo.png` and `assets/composer-icon.png`.
- Defined scoped, selective collaborator relationships and cross-skill input/output, provenance, escalation, handoff and return contracts. No hard dependency cycles or automatic loading rules were introduced.
- The previous integration appendices for `evaluation`, `judgement`, `priority`, `workflow` were moved **without modification** into `skills/<name>/references/legacy-integration-appendix.md` for provenance, while the original skill specifications before those appendices remain byte-identical.
- Kept all other original skill content, references, binary assets, interface metadata, default prompts, ownership and plugin identity unchanged. Only the two plugin manifest version strings advanced from 0.0.6 to 0.0.7.
- Plugin-level baseline: original release `pluginrel_6adfa862d9b4819190eb53ab3631ac45` / 0.0.6; changes intended for guarded overlay onto that release.

### Future-release checks

Re-inventory every `references/` and `assets/`; verify packaged paths, archive members, skill frontmatter, one appendix and section order; check all 40 skills remain below the 1 MiB limit; compare retained content hashes and current plugin release before publication. Distinguish packaged conceptual constructs from current institutional policies.
