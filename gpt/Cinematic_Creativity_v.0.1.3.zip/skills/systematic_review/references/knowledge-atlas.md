# SYSTEMATIC REVIEW — KNOWLEDGE ATLAS

As of 2026-10-17. **Methodological atlas; not a completed systematic review of methods research.**

## Sources
- **S01** PRISMA 2020 (2021 / current site) — https://www.prisma-statement.org/prisma-2020
- **S02** Cochrane Handbook for Systematic Reviews of Interventions (2024 v6.5; 2025 chapter updates) — https://www.cochrane.org/authors/handbooks-and-manuals/handbook/current
- **S03** Cochrane Chapter 4: Searching and selecting studies (2025) — https://www.cochrane.org/authors/handbooks-and-manuals/handbook/current/chapter-04
- **S04** Cochrane Chapter 10: Meta-analysis (2024 update) — https://www.cochrane.org/authors/handbooks-and-manuals/handbook/current/chapter-10
- **S05** JBI Manual for Evidence Synthesis (2024 edition / 2025 updates) — https://jbi-global.atlassian.net/wiki/spaces/MANUAL/pages/355827730/Table+of+Contents
- **S06** PRISMA-S (2021) — https://www.prisma-statement.org/prisma-search
- **S07** PRESS 2015 guideline (2015 / pub. 2016) — https://doi.org/10.1016/j.jclinepi.2016.01.021
- **S08** TARCiS statement (2024) — https://doi.org/10.1136/bmj-2023-078384
- **S09** RoB 2 (Current) — https://methods.cochrane.org/bias/resources/rob-2-revised-cochrane-risk-bias-tool-randomized-trials
- **S10** ROBINS-I (2026 v2 launch; check version) — https://methods.cochrane.org/bias/risk-bias-non-randomized-studies-interventions
- **S11** ROBINS-E (2024 tool; current site) — https://www.riskofbias.info/welcome/robins-e-tool
- **S12** ROB-ME (2023) — https://methods.cochrane.org/bias/resources/rob-me
- **S13** QUADAS-3 (2026) — https://doi.org/10.7326/ANNALS-25-02104
- **S14** AMSTAR 2 (2017 / current) — https://amstar.ca/Amstar-2.php
- **S15** ROBIS (2016) — https://doi.org/10.1016/j.jclinepi.2015.06.005
- **S16** GRADE evidence certainty (2024-2025 guidance) — https://www.cdc.gov/acip-grade-handbook/hcp/chapter-7-grade-criteria-determining-certainty-of-evidence/index.html
- **S17** GRADE-CERQual (Current guidance) — https://www.cerqual.org/overall-confidence-in-the-evidence/
- **S18** SWiM guideline (2020) — https://doi.org/10.1136/bmj.l6890
- **S19** PRISMA-LSR (2024) — https://www.prisma-statement.org/lsr
- **S20** PRISMA-COSMIN for outcome measurement instruments (2024) — https://www.prisma-statement.org/cosmin
- **S21** PRISMA extensions / work in development (Site checked 2026-10-17) — https://www.prisma-statement.org/extensions
- **S22** PROSPERO registry (Site checked 2026-10-17) — https://www.crd.york.ac.uk/PROSPERO/
- **S23** Laignelot et al.: LLMs for review tasks (2026) — https://doi.org/10.1016/j.jclinepi.2026.112221
- **S24** Shankar et al.: LLM data extraction (2026) — https://doi.org/10.1016/j.jbi.2026.105086
- **S25** QUADAS-3 piloting (2025) — https://doi.org/10.1016/j.jclinepi.2025.111983
- **S26** Cochrane Bias 2026 Spotlight (2026-09-21) — https://methods.cochrane.org/bias/news/spotlight-cochrane-bias-methods-groups-2026
- **S27** PRISMA-ScR (2018) — https://www.prisma-statement.org/scoping

## Review types
- **Intervention effectiveness** — Effect of an intervention vs comparator; Pairwise MA / structured SWiM; RoB 2; ROBINS-I; GRADE.
- **Diagnostic test accuracy** — Sensitivity/specificity and clinical utility; Bivariate / HSROC where appropriate; QUADAS-3; DTA certainty approach.
- **Prognosis / prediction** — Probability or risk over time; Pooled prognostic estimates / model validation; QUIPS / PROBAST as appropriate.
- **Etiology / exposure** — Effect or association of an exposure; Context-sensitive meta-analysis; ROBINS-E; GRADE adapted to causal question.
- **Prevalence / incidence** — How common, in whom and where; Proportion / rate synthesis if meaningful; Sampling and representativeness appraisal.
- **Qualitative evidence synthesis** — Experiences, meanings, barriers, mechanisms; Thematic / framework / meta-aggregation; JBI appraisal; GRADE-CERQual.
- **Mixed-methods synthesis** — How effect and experience fit together; Convergent or sequential integration; Separate appraisal + integrated inference.
- **Scoping review / evidence map** — What evidence exists and its boundaries; Categorical mapping, not pooled effects; Appraisal may not be needed for mapping.
- **Umbrella / overview of reviews** — What existing reviews collectively say; Overlap-aware overview; AMSTAR 2 / ROBIS; avoid double-counting.
- **Network meta-analysis** — Relative effects among >2 interventions; Network models + transitivity checks; RoB 2 / ROBINS-I; CINeMA/GRADE.
- **Individual participant data meta-analysis** — Heterogeneity and participant-level effects; One-stage / two-stage IPD; Study RoB plus missing IPD appraisal.
- **Living systematic review** — Time-sensitive changing body of evidence; Versioned repeated synthesis; Reassess bias/certainty on changes.
- **Rapid review** — Decision-limited but transparent synthesis; Fit-for-purpose; Document shortcuts and bias costs.
- **Realist / theory-driven review** — What works for whom in what contexts; Theory refinement / configurations; Relevance and rigor reasoning.
- **Systematic review of measurement instruments** — Which instruments measure reliably and validly; Properties by instrument; COSMIN / certainty principles.

## Workflow
- **G01 Need & novelty**: Define intended decision, evidence users, redundancy scan | artifact: Question charter; overlap map | pass: Explicit scope and what decision changes
- **G02 Question & estimand**: Specify populations, comparator, outcomes, timing, causal vs descriptive | artifact: Eligibility and estimand sheet | pass: Question, primary contrast, critical outcomes fixed
- **G03 Review family**: Select evidence synthesis family to match question | artifact: Design rationale | pass: Justification for review type and outputs
- **G04 Protocol lock**: Protocol, eligibility, outcomes, analysis, deviations process | artifact: Timestamped protocol + registration | pass: Public change log exists
- **G05 Search architecture**: Database, registry, gray, languages, citation, librarian | artifact: Source inventory + strategy translations | pass: PRESS-reviewed, source-complete plan
- **G06 Retrieval log**: Run exact search strings, save exports and counts | artifact: Search log, RIS/CSV, dates | pass: Query-platform-date-file lineage
- **G07 Selection calibration**: Pilot criteria, screen, resolve disagreements | artifact: Decision log, excluded full texts | pass: Pre-agreed rules; reason codes
- **G08 Study identity**: Merge multiple reports, registry IDs and outputs | artifact: Study-report map | pass: One study ID connected to all reports
- **G09 Data schema**: Design piloted extraction form; define units and outcomes | artifact: Codebook / extraction data | pass: Double check critical fields and versions
- **G10 Validity appraisal**: Select design-specific RoB, outcome/estimand specific | artifact: Judgment log + support quotes | pass: Two reviewers adjudicate domains
- **G11 Synthesis eligibility**: Assess clinical, methodological and statistical combinability | artifact: Synthesis-set ledger | pass: Written rationale for each group
- **G12 Quant/qual synthesis**: Preplanned effect models or transparent alternative | artifact: Code, forest/tables, narratives | pass: Checks of code and assumptions
- **G13 Missing evidence & robustness**: Bias due to missing results; sensitivity, subgroup, influence | artifact: Robustness matrix | pass: Primary results survive defensible perturbations or uncertainty stated
- **G14 Certainty & applicability**: Grade each pivotal finding, contextualize absolute effects | artifact: SoF / CERQual, context matrix | pass: Effect, certainty, context separate
- **G15 Transparent publication**: PRISMA checklist, exclusions, source and reproducibility bundle | artifact: Manuscript, flow, archive | pass: Auditable from claim to study to source
- **G16 Maintenance & governance**: Surveillance triggers, corrections, update/discontinuation policy | artifact: Versioned living log, owner and triggers | pass: Date of validity and next-check trigger

## Frontier radar
- **F01 LLM-aided screening** — Promising, variable; test: Benchmark domain-specific missed-eligible rate, confidence intervals, protected recall; failure: Silent exclusions in underrepresented study types
- **F02 LLM data extraction** — Promising, unstable for complex fields; test: Field-level exact-match and evidence span, independent dual audit; failure: Hallucinated numbers / wrong denominator
- **F03 LLM bias assessment** — Not independently reliable; test: Blind comparison with expert domain/estimand judgement; failure: Misclassified confounding / time-zero bias
- **F04 Living and continuously updated syntheses** — Established concept, operational challenge; test: Version audit, drift control, search triggers, change significance; failure: Stale versions and moving targets
- **F05 Study-to-report identity graphs** — High-priority research engineering; test: Link multiple articles, registries, CSRs, corrections by study ID; failure: Duplicate study counting
- **F06 Diagnostic-tool transition** — New published standard; test: Cross-walk QUADAS-2 to QUADAS-3; pre-specify version; failure: Uncontrolled mid-review rubric change
- **F07 Nonrandomized causal inference** — Rapidly maturing; test: Target trial / estimand, time zero, immortal-time control; failure: Confounding and time-related bias
- **F08 Structured missing-evidence assessment** — Established tool, adoption gap; test: Trial registry cross-check; result availability ledger; failure: Biased available evidence
- **F09 Equitable multilingual discovery** — Open problem; test: Non-English database coverage and language-stratified recall; failure: Geographic and linguistic exclusion
- **F10 Transportability & decision relevance** — Active methodological frontier; test: Target-population differences; decision thresholds and absolute effects; failure: Valid pooled estimate applied to wrong population
- **F11 Machine-readable provenance** — Engineering frontier; test: Citation → report → study → result → synthesis → claim lineage; failure: Irreproducible transformations
- **F12 Publication and retraction surveillance** — Operational frontier; test: Corrections, trial results/CSRs and search delta auditing; failure: Retractions or missing negative results mislead

## Integrity note
The full interpretive chapters and diagrams are in the DOCX/PDF edition; structured arrays and graph edges are in JSON and the XLSX workbook.