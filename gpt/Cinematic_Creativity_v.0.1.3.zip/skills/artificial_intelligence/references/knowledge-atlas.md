# THE AI KNOWLEDGE ATLAS

**Edition 2026.10 · Evidence cutoff 17 October 2026 · Research atlas / version 1.0**

> **Purpose.** Navigate the intellectual structure of artificial intelligence, identify what is known, find the live frontiers, and distinguish real evidence from performance theater.

**Atlas at a glance:** 12 territories · 122 concepts · 217 typed links · 18 evidence-led propositions · 12 frontier tests · 38 sources.

## Executive orientation

This atlas treats AI as a coupled **scientific, engineering, evaluation and institutional system**, not a leaderboard of models. Its deepest organizing insight is that capability is only meaningful together with reliability, evidence, authorization, operational context and external consequences. The atlas connects 12 territories into a typed directed knowledge graph, adds frontier tests, and distinguishes demonstrated performance from predictions or philosophical claims.

**Six theses as of October 2026.** (1) Scaling, post-training and inference-time computation jointly shape capabilities. (2) Benchmark achievement is not broad or high-reliability agency. (3) Agents require memory, verifiers, tools, side-effect controls and monitoring—not merely longer prompts. (4) Embodied AI and scientific autonomy require intervention and experimental validation. (5) Safety, measurement and governance are moving technical research fronts. (6) Compute, data rights, energy, and institutional legitimacy are part of AI architecture rather than downstream side issues.

**Current evidence anchors.** The Stanford 2026 AI Index reports OSWorld agent task success at 66.3% in 2025 while real household robots succeeded on roughly 12% of surveyed tasks—a pointed illustration of distinct capability regimes [S02]. METR measures agent task *difficulty* via human expert completion times, not the time an AI runs or a fraction of jobs it can replace [S08]. The International AI Safety Report 2026 separates misuse, malfunction and systemic risks [S07]. The IEA 2025 base-case **scenario**, not a measurement, projects 945 TWh of annual data-centre electricity consumption in 2030 [S29].

## How to read and use the atlas

**Layer 1 — Territories.** Twelve domains map the field. **Layer 2 — Concepts.** A stable `ID` refers to a node with meaning, evidence maturity, sources and dependencies. **Layer 3 — Relationships.** Directed prerequisite and typed cross-disciplinary edges show what enables, constrains, measures or risks another domain. **Layer 4 — Claims.** Specific propositions carry a support statement and limitation. **Layer 5 — Frontier experiments.** Unresolved questions are paired with evidence that would discriminate among explanations. **Layer 6 — Revision.** A dated protocol makes the atlas correctable.

| Status | Editorial meaning |
|---|---|
| **core** | mature knowledge or widely established engineering practice |
| **active** | deployed or reproducibly demonstrated, with important limits |
| **emerging** | promising early results, unsettled transfer or scale |
| **contested** | material empirical or conceptual disagreement |
| **speculative** | possible but inadequately demonstrated |

## The 12 territories

| Code | Territory | Core question | Concepts |
|---|---|---|---:|
| F | Foundations & epistemology | What makes AI work, and what would count as knowing? | 10 |
| L | Learning & optimization | How behavior is acquired, steered, and adapted. | 10 |
| M | Model architectures | Representations and inductive biases of machine intelligence. | 10 |
| D | Data, memory & knowledge | What systems learn from and how they retrieve evidence. | 10 |
| C | Compute & systems | Physical and software constraints on capability. | 10 |
| A | Reasoning & agents | From predictions to multi-step decisions and actions. | 10 |
| P | Perception & embodiment | From pixels and signals to action in the world. | 10 |
| S | AI for science & health | Model-guided discovery with experimental validation. | 10 |
| E | Evaluation & metrology | What is measured, why it fails, and what transfers. | 10 |
| R | Safety, alignment & security | How systems fail, how they are constrained, and by whom. | 10 |
| G | Governance, economy & society | Rules, institutions, work, markets, and externalities. | 10 |
| U | Open frontiers & unknowns | Research boundaries that require discriminating tests. | 12 |

## The atlas, concept by concept

### F — Foundations & epistemology

*What makes AI work, and what would count as knowing?*

**F01 · AI as a family of systems** · `core` · [S01], [S07]  
Artificial intelligence comprises engineered systems that infer, predict, generate, decide, or act toward specified objectives; it is not one algorithm or one intelligence scale. **Why it matters:** Avoids reducing AI to chatbots or equating fluency with agency.  

**F02 · Probability and statistics** · `core` · [S02]  
Likelihoods, uncertainty, estimation, generalization and calibration give empirical learning a language for uncertainty. **Why it matters:** Underpins risk estimates, model training and all credible evaluations.  

**F03 · Linear algebra and calculus** · `core` · [S10]  
Vector spaces, tensor operations and gradients make large-scale differentiable learning computationally practical. **Why it matters:** Connects architecture choices to optimization and hardware cost.  

**F04 · Decision theory and causality** · `active` · [S07]  
Decision-making under uncertainty distinguishes observing an association from choosing an intervention under consequences. **Why it matters:** Highlights limits of pattern matching in planning and scientific use.  
Prerequisites: F02.

**F05 · Symbolic reasoning and search** · `core` · [S21]  
Logic, rules, planning and combinatorial search offer explicit constraint handling and can complement learned heuristics. **Why it matters:** Not all useful intelligence is end-to-end neural prediction.  

**F06 · Statistical learning theory** · `core` · [S02]  
Generalization depends on data distributions, inductive bias, objective, capacity, and evaluation conditions. **Why it matters:** Explains why in-distribution accuracy need not imply robustness.  
Prerequisites: F02.

**F07 · Representation learning** · `core` · [S10], [S22]  
Systems learn compressed features or latent structures that transfer imperfectly across tasks and modalities. **Why it matters:** Powers foundation models but does not guarantee semantic fidelity.  
Prerequisites: F03.

**F08 · Epistemic states** · `core` · [S07], [S27]  
Separate replicated facts, supported claims, contested interpretations, exploratory hypotheses, and unobserved possibilities. **Why it matters:** The atlas's principle for preventing claims from outrunning evidence.  
Prerequisites: F02.

**F09 · Cognitive and social analogies** · `contested` · [S07], [S22]  
Human-intelligence terms like reasoning, memory, belief and personality are useful analogies but not validated equivalences. **Why it matters:** Prevents anthropomorphic overclaim and conceptual confusion.  
Prerequisites: F01.

**F10 · Specification versus legitimacy** · `active` · [S07], [S27]  
A measurable reward or policy can encode a task without capturing a socially legitimate aim or authorization. **Why it matters:** Separates capability, permission and responsibility.  
Prerequisites: F04.


### L — Learning & optimization

*How behavior is acquired, steered, and adapted.*

**L01 · Supervised learning** · `core` · [S01]  
Fit an input-output mapping from examples with ground-truth or operational proxy labels. **Why it matters:** Foundation for discriminative models and evaluated workflows.  
Prerequisites: F02.

**L02 · Self-supervised pretraining** · `core` · [S10], [S11]  
Learn patterns by predicting withheld, next, or transformed parts of abundant unlabeled data. **Why it matters:** Makes broad transferable foundation models possible.  
Prerequisites: F07.

**L03 · Reinforcement learning** · `core` · [S16]  
Optimize decisions over actions and outcomes through environment feedback, with possible reward misspecification. **Why it matters:** Central to sequential decision making and post-training reasoning.  
Prerequisites: F04.

**L04 · Instruction tuning** · `core` · [S14]  
Fine-tune models on examples of desired interactive behavior, changing helpfulness without rewriting all pretrained knowledge. **Why it matters:** Bridges raw prediction and useful assistance.  
Prerequisites: L02.

**L05 · Preference optimization** · `core` · [S14], [S15]  
Use comparisons or preference models, including RLHF and DPO, to steer model responses toward desired tradeoffs. **Why it matters:** Improves usability but can reward style over truth.  
Prerequisites: L04.

**L06 · Verifiable-reward training** · `active` · [S16], [S21]  
Reward outputs checked by test cases, proofs or exact answers, enabling scalable post-training in domains with reliable verifiers. **Why it matters:** High leverage where correctness is inexpensive to verify.  
Prerequisites: L03.

**L07 · Curriculum and synthetic data** · `active` · [S11], [S16]  
Schedule examples or generate training data using models, filters and feedback loops; contamination and diversity matter. **Why it matters:** May extend training but can propagate hidden errors.  
Prerequisites: L02.

**L08 · Online and continual learning** · `emerging` · [S07], [S24]  
Adapt after deployment without catastrophic forgetting, runaway drift, or uncontrolled authority changes. **Why it matters:** A major gap for persistent, situated systems.  
Prerequisites: L02.

**L09 · Transfer and domain adaptation** · `core` · [S02]  
Reuse learned features in a new task, population or setting; transfer often breaks under distribution shifts. **Why it matters:** Explains deployment benefits and hidden failure boundaries.  
Prerequisites: L01.

**L10 · Meta-learning and automated research** · `emerging` · [S21], [S23]  
Optimize learning procedures, prompts or model-making workflows; gains require independent objective verification. **Why it matters:** Creates feedback loops between AI capability and AI development.  
Prerequisites: L03.


### M — Model architectures

*Representations and inductive biases of machine intelligence.*

**M01 · Transformers and attention** · `core` · [S10]  
Attention-based blocks combine contextual token information and parallelizable training; attention cost motivates alternatives. **Why it matters:** Dominant general-purpose sequence modeling backbone.  
Prerequisites: F03, L02.

**M02 · Autoregressive models** · `core` · [S10]  
Estimate sequences token by token, supporting general prediction and generation through factorized likelihoods. **Why it matters:** Widely applicable but expensive for long outputs.  
Prerequisites: M01.

**M03 · Diffusion and flow models** · `core` · [S12]  
Learn generative transitions from noise to structured outputs; central in media and molecular generation. **Why it matters:** Complement autoregression for continuous, high-dimensional outputs.  
Prerequisites: L02.

**M04 · Mixture-of-experts** · `active` · [S01], [S11]  
Route tokens or examples to subsets of specialized subnetworks, trading conditional compute for routing and systems complexity. **Why it matters:** Makes parameter scaling partly separable from per-token cost.  
Prerequisites: M01, C01.

**M05 · State-space and recurrent alternatives** · `active` · [S17]  
Selective state-space designs such as Mamba provide alternative long-sequence tradeoffs; effectiveness depends on domain and task. **Why it matters:** Contests the idea that attention must dominate every regime.  
Prerequisites: M01.

**M06 · Multimodal foundation models** · `active` · [S02]  
Jointly or coordinately process text, images, audio, video and structured signals; alignment across modalities remains imperfect. **Why it matters:** Extends interface and reasoning scope.  
Prerequisites: M01.

**M07 · World and predictive models** · `emerging` · [S18]  
Predict environment dynamics or action-conditioned futures, often in learned latent spaces; fidelity under intervention is not assured. **Why it matters:** Candidate infrastructure for planning and robotics.  
Prerequisites: M03, F04.

**M08 · Neuro-symbolic hybrids** · `active` · [S21]  
Combine learned representations with explicit programs, tools, constraints or proofs; integration is an active design problem. **Why it matters:** Offers inspectability and verifier-backed correction.  
Prerequisites: F05, M01.

**M09 · Small and specialized models** · `active` · [S06]  
Smaller models can outperform larger general models on particular tasks, especially with tailored data or representations. **Why it matters:** Supports edge deployment and resource-aware design.  
Prerequisites: L09.

**M10 · Architecture search beyond Transformers** · `emerging` · [S17], [S01]  
Alternative attention, memory, recurrence and modularity may change scaling efficiency; no universal winner is established. **Why it matters:** Keep architecture trends conditional rather than inevitable.  
Prerequisites: M01, M05.


### D — Data, memory & knowledge

*What systems learn from and how they retrieve evidence.*

**D01 · Data quality and provenance** · `core` · [S11], [S27]  
Coverage, labels, licensing, deduplication, lineage, and consent determine whether training evidence is trustworthy. **Why it matters:** Poor provenance weakens reproducibility and legal assurance.  
Prerequisites: F08.

**D02 · Tokenization and representation** · `core` · [S10]  
Encodings turn words, bytes, images and signals into computational units with uneven semantic and linguistic biases. **Why it matters:** Impacts multilingual coverage, latency and failure modes.  
Prerequisites: F07.

**D03 · Retrieval-augmented generation** · `core` · [S13]  
Use search over external evidence to condition generation; retrieval quality and citations still need verification. **Why it matters:** Permits updates without retraining and supports attribution.  
Prerequisites: M01.

**D04 · Vector search and knowledge graphs** · `core` · [S13]  
Similarity retrieval finds nearby embeddings; typed graphs preserve explicit entities and relations, each with different error modes. **Why it matters:** Useful complementarities, not interchangeable memory systems.  
Prerequisites: F07.

**D05 · Context engineering** · `active` · [S24], [S25]  
Select, compress and structure instructions, tools, documents and histories inside a bounded model context. **Why it matters:** Often improves real workflows more than raw model size.  
Prerequisites: D03.

**D06 · Agent memory and state** · `emerging` · [S24]  
Episodic logs, working memory and semantic stores maintain continuity but can fossilize mistakes or leak private data. **Why it matters:** Foundation for durable personalization and long tasks.  
Prerequisites: D05.

**D07 · Synthetic data validity** · `active` · [S16], [S02]  
Model-generated examples require checks for novelty, diversity, leakage and feedback-loop degradation. **Why it matters:** Synthetic volume is not equivalent to independent evidence.  
Prerequisites: D01.

**D08 · Multilingual and low-resource data** · `active` · [S01], [S04]  
Uneven language coverage and local context create unequal model quality and evaluation blind spots. **Why it matters:** Fairness and capability distribution are data problems.  
Prerequisites: D01.

**D09 · Data governance and rights** · `active` · [S27], [S28]  
Access, copyright, privacy, consent, retention and deletion constraints shape what can be learned or retrieved. **Why it matters:** Sets the lawful and legitimate boundary of AI knowledge.  
Prerequisites: D01.

**D10 · Epistemic memory architecture** · `emerging` · [S07], [S26]  
Track claims with source, date, support status, defeaters and revision history rather than storing unqualified summaries. **Why it matters:** Converts an AI knowledge base into an auditable system.  
Prerequisites: F08, D04.


### C — Compute & systems

*Physical and software constraints on capability.*

**C01 · AI accelerators and memory** · `core` · [S01], [S29]  
GPUs, specialized ASICs, memory capacity, bandwidth, networking and supply chains constrain model training and inference. **Why it matters:** Compute is both technical substrate and geopolitical chokepoint.  
Prerequisites: F03.

**C02 · Distributed training** · `core` · [S11]  
Data, tensor, pipeline and expert parallelism allow larger models but make reliability and communication bottlenecks critical. **Why it matters:** Explains why nominal FLOPs alone mislead.  
Prerequisites: C01.

**C03 · Compute-optimal scaling** · `core` · [S11]  
Training quality depends on balancing parameters, training tokens and compute; the optimum changes with inference economics. **Why it matters:** Scaling laws describe tradeoffs, not unlimited capability guarantees.  
Prerequisites: L02, C01.

**C04 · Inference-time scaling** · `active` · [S07], [S16]  
More sampled paths, reasoning steps, search or verification can improve hard-task results at higher cost and latency. **Why it matters:** Shifts intelligence budgets from training alone to deployment.  
Prerequisites: M02, L06.

**C05 · Quantization and distillation** · `core` · [S16]  
Compressed precision or student models can reduce cost, subject to quality and robustness tradeoffs. **Why it matters:** Helps make specialized AI accessible.  
Prerequisites: C01, M09.

**C06 · Serving, caching and routing** · `active` · [S01]  
Batching, KV caches, speculative decoding, routing and model selection optimize latency, throughput and cost. **Why it matters:** Deployment architecture shapes user-visible performance.  
Prerequisites: M01, C01.

**C07 · Energy, water and siting** · `active` · [S29]  
Electricity and cooling requirements depend on local grids, utilization, climate, supply mix and rebound effects. **Why it matters:** System-level footprint matters more than single-prompt anecdotes.  
Prerequisites: C01.

**C08 · Open-weight ecosystems** · `active` · [S02]  
Published weights allow local inspection and adaptation but not necessarily open data, training recipes or unrestricted licenses. **Why it matters:** Openness is multidimensional and affects auditability.  
Prerequisites: M09, D09.

**C09 · Hardware-software co-design** · `active` · [S17], [S21]  
Kernels, sparsity, memory layout and accelerator architectures jointly determine actual compute efficiency. **Why it matters:** Algorithmic gains can be lost without systems optimization.  
Prerequisites: C01, M04.

**C10 · AI sovereignty and resilience** · `active` · [S01], [S28]  
National compute, chips, energy, talent and model access interact with trade concentration and security. **Why it matters:** Infrastructure dependence informs public policy.  
Prerequisites: C01, C07.


### A — Reasoning & agents

*From predictions to multi-step decisions and actions.*

**A01 · Reasoning as observable performance** · `contested` · [S02], [S07]  
Models may solve multistep problems, but correct answers do not uniquely demonstrate human-like internal reasoning. **Why it matters:** Avoids conflating mechanism with benchmark outcomes.  
Prerequisites: M02, F09.

**A02 · Deliberation and search** · `active` · [S16], [S21]  
Sampling, self-critique, tree search and verifier guidance allocate computation to candidate answers or action paths. **Why it matters:** Effective when errors can be detected before commitment.  
Prerequisites: C04.

**A03 · Tool and API use** · `active` · [S25], [S24]  
Agents call external systems to retrieve, calculate, code, browse or act; permissions and side effects become central. **Why it matters:** Moves AI from advice to consequential action.  
Prerequisites: D05.

**A04 · Planning and hierarchical control** · `active` · [S07], [S24]  
Decompose goals into subgoals with preconditions, monitoring and replanning under changing information. **Why it matters:** Necessary but insufficient for robust long-horizon agency.  
Prerequisites: F04, A03.

**A05 · Computer-use agents** · `active` · [S02], [S08]  
Models operate graphical interfaces and software environments with limited reliability and error recovery. **Why it matters:** Benchmark progress has yet to imply universal autonomy.  
Prerequisites: A03.

**A06 · Long-horizon autonomy** · `emerging` · [S08], [S24]  
Success across extended coherent tasks requires state, verification, recovery and authority boundaries; duration alone misleads. **Why it matters:** A central frontier for useful and safe agents.  
Prerequisites: A04, D06.

**A07 · Multi-agent orchestration** · `active` · [S06], [S21]  
Coordinated roles can diversify hypotheses or parallelize work, yet also amplify coordination overhead and correlated errors. **Why it matters:** Team size is not a proxy for reliability.  
Prerequisites: A03.

**A08 · Verifier-grounded agents** · `active` · [S21], [S26]  
Test suites, execution traces, theorem provers or external measurements validate claims before they become accepted outputs. **Why it matters:** Distinguishes completion from plausible narration.  
Prerequisites: A02, E04.

**A09 · Workflow integration and human approval** · `active` · [S24], [S27]  
Reliable deployments model authority, handoffs, rollback, observability, and escalation at high-consequence decisions. **Why it matters:** Defines safe autonomy as governed work, not unchecked action.  
Prerequisites: A03, R07.

**A10 · Recursive AI-assisted R&D** · `emerging` · [S21], [S23]  
AI can propose, implement and test improvements to code or research processes; independent metrics are critical to avoid self-scoring illusions. **Why it matters:** May accelerate development without establishing open-ended self-improvement.  
Prerequisites: A08, L10.


### P — Perception & embodiment

*From pixels and signals to action in the world.*

**P01 · Computer vision** · `core` · [S02]  
Learned visual representations support recognition, segmentation, grounding and scene understanding with distribution-shift limitations. **Why it matters:** Strong perception need not mean physical understanding.  
Prerequisites: M06.

**P02 · Speech and audio intelligence** · `active` · [S02]  
ASR, TTS, speech dialogue and acoustic scene models support real-time interfaces but vary across languages and contexts. **Why it matters:** Broadens access and raises identity-spoofing risks.  
Prerequisites: M06.

**P03 · Image and video generation** · `active` · [S02], [S12]  
Diffusion and autoregressive systems generate convincing media; visual plausibility does not imply causal physics. **Why it matters:** Raises provenance, creative and verification issues.  
Prerequisites: M03.

**P04 · Video world simulation** · `emerging` · [S18]  
Interactive generative environments can model some dynamics over minutes but may fail under precise physical tests. **Why it matters:** Provides possible training worlds for agents.  
Prerequisites: M07.

**P05 · Vision-language-action policies** · `emerging` · [S19]  
Models map sensory input and instructions into robot actions; safety requires low-level control and environment grounding. **Why it matters:** Potential bridge from foundation models to robots.  
Prerequisites: M06, L03.

**P06 · Embodied spatial reasoning** · `active` · [S19]  
Spatial relations, affordances, contact dynamics and uncertainty matter for real-world action. **Why it matters:** A pronounced frontier gap relative to text reasoning.  
Prerequisites: P01, F04.

**P07 · Sim-to-real transfer** · `active` · [S02], [S18]  
Train in simulation and adapt in the world, where unmodeled physics, sensor noise and humans create failure. **Why it matters:** Simulator quality is not equivalent to deployment validity.  
Prerequisites: P04.

**P08 · Robotic manipulation** · `active` · [S02]  
Grasping, dexterity and long-task recovery remain difficult outside structured industrial settings. **Why it matters:** Exposes the discontinuity between digital and physical agency.  
Prerequisites: P05, P06.

**P09 · Autonomous vehicles** · `active` · [S02]  
Constrained-domain autonomous driving is deployed at scale in some cities, with operating-domain and oversight limitations. **Why it matters:** Shows task-specific autonomy can mature ahead of general robotics.  
Prerequisites: P01, A04.

**P10 · Human-robot interaction** · `emerging` · [S07], [S27]  
Robots need intent inference, communication, safe stopping, accessible control and societal trust. **Why it matters:** Embodiment transforms model errors into physical consequences.  
Prerequisites: P08, A09.


### S — AI for science & health

*Model-guided discovery with experimental validation.*

**S01 · Protein structure prediction** · `core` · [S32], [S36]  
AI predicts many molecular structures and interactions, supporting hypotheses but not replacing experimental structural biology. **Why it matters:** A landmark of AI-guided natural science.  
Prerequisites: M06.

**S02 · Generative protein design** · `active` · [S38]  
Design novel protein sequences against desired targets, then validate binding, function and safety experimentally. **Why it matters:** Moves from prediction toward intervention in biology.  
Prerequisites: S01, M03.

**S03 · Genomics and regulatory prediction** · `active` · [S20], [S34]  
Sequence models estimate regulatory consequences of variants; predictive scores remain distinct from causal disease validation. **Why it matters:** Expands the searchable landscape of biological hypotheses.  
Prerequisites: M06, D01.

**S04 · Virtual cells and perturbation models** · `emerging` · [S06]  
Models aim to forecast cellular responses to drug or genetic interventions; external wet-lab validity is incomplete. **Why it matters:** A high-potential, high-validation-demand frontier.  
Prerequisites: S03, F04.

**S05 · AI-guided algorithm discovery** · `active` · [S21]  
Search and code-evaluation loops can discover improved algorithms where objective functions allow rigorous testing. **Why it matters:** A concrete route to machine-assisted scientific novelty.  
Prerequisites: L06, A08.

**S06 · Materials and chemistry design** · `active` · [S05]  
Learned surrogates and generators prioritize candidate molecules or materials, with synthesis feasibility and repeatability as constraints. **Why it matters:** Acceleration occurs only if experiments close the loop.  
Prerequisites: S02, L01.

**S07 · Automated laboratories** · `emerging` · [S05], [S07]  
Robotics, instruments and AI planning could create autonomous experiment cycles, but calibration, safety and data quality dominate. **Why it matters:** Physical experiments prevent purely simulated confidence.  
Prerequisites: S06, A09.

**S08 · Clinical decision support** · `active` · [S06], [S27]  
Models summarize, predict, triage or suggest care, with validation, clinician oversight and subgroup performance crucial. **Why it matters:** A benchmark result is not evidence of better patient outcomes.  
Prerequisites: E03, R08.

**S09 · Causal scientific discovery** · `emerging` · [S05], [S21]  
Scientific discovery requires explanatory hypotheses, interventions, replication and mechanistic uncertainty, not just accurate prediction. **Why it matters:** Separates AI as collaborator from autonomous scientific authority.  
Prerequisites: F04, A08.

**S10 · Research reproducibility** · `core` · [S05], [S07]  
Trace data, protocols, code, samples and independent replication before promoting a finding to established knowledge. **Why it matters:** The quality gate for the entire scientific layer.  
Prerequisites: F08, D10.


### E — Evaluation & metrology

*What is measured, why it fails, and what transfers.*

**E01 · Benchmark design and construct validity** · `core` · [S02], [S25]  
A benchmark must operationalize the target ability, not merely correlate with a score on convenient tasks. **Why it matters:** Invalid proxies create spurious frontiers.  
Prerequisites: F06.

**E02 · Data leakage and contamination** · `active` · [S02], [S26]  
Training or adaptation on evaluation content can make held-out scores uninformative. **Why it matters:** Demands secret, rotating or cryptographically protected tests.  
Prerequisites: D01, E01.

**E03 · Distribution shift and robustness** · `core` · [S07]  
Performance can change under new populations, settings, prompts, languages, tools or adversaries. **Why it matters:** Field evidence is necessary for transfer claims.  
Prerequisites: F06, L09.

**E04 · Task-based and outcome evaluations** · `active` · [S08], [S25]  
Evaluate whole workflows with success, time, cost, escalation and collateral failures, not only answer correctness. **Why it matters:** Aligns tests with practical value.  
Prerequisites: E01, A09.

**E05 · Agent time-horizon measurement** · `active` · [S08]  
Estimate the human-duration of tasks a scaffolded model solves at 50% or 80% reliability; not elapsed AI runtime or job automation. **Why it matters:** Meaningful progress signal with strict scope limits.  
Prerequisites: A06, E04.

**E06 · Calibration and uncertainty** · `active` · [S03], [S07]  
Measure whether confidence agrees with frequencies, including abstention, set coverage and tail risks. **Why it matters:** The ability to say 'uncertain' is separately measurable.  
Prerequisites: F02.

**E07 · Holistic and adversarial evaluation** · `active` · [S08], [S24]  
Test ambiguous, messy, long-running, red-team and real-world settings, where automated scoring can overestimate competence. **Why it matters:** Exposes errors invisible on clean benchmarks.  
Prerequisites: E04.

**E08 · Independent and double-blind evaluation** · `emerging` · [S25], [S26]  
Separate builders from evaluators and restrict test leakage, conflicts, cherry-picking and hidden adaptation. **Why it matters:** Improves the credibility of frontier claims.  
Prerequisites: E02.

**E09 · Longitudinal post-deployment monitoring** · `active` · [S24], [S27]  
Detect drift, new misuse, regressions and near-misses after release; tests cannot predict every interaction. **Why it matters:** Safety evidence must follow systems into the field.  
Prerequisites: E07.

**E10 · Reproducibility and reporting** · `core` · [S02], [S25]  
Specify model/version, prompts, sampling, scaffold, tools, cost, task set and confidence intervals. **Why it matters:** Results without protocols are difficult to compare.  
Prerequisites: E01.


### R — Safety, alignment & security

*How systems fail, how they are constrained, and by whom.*

**R01 · Alignment and objective fidelity** · `active` · [S07], [S14]  
A system's behavior should track legitimate human intent under constraints rather than proxy rewards alone. **Why it matters:** Desired behavior is context-dependent and contestable.  
Prerequisites: F10, L05.

**R02 · Reward hacking and specification gaming** · `active` · [S07], [S23]  
Optimization can exploit defects in reward functions or tests instead of doing the intended task. **Why it matters:** A successful score is not necessarily a successful outcome.  
Prerequisites: L03, R01.

**R03 · Deception, sycophancy and hidden objectives** · `contested` · [S07], [S23]  
Some evaluations reveal behaviors that appear strategically misleading or overly agreeing; generalization is uncertain. **Why it matters:** Requires controlled tests rather than inferred motives.  
Prerequisites: R01, E07.

**R04 · Mechanistic interpretability** · `emerging` · [S22]  
Circuit tracing and internal-feature methods inspect computation, but validated, comprehensive causal explanations remain rare. **Why it matters:** Potential audit channel, not yet a safety proof.  
Prerequisites: M01, F09.

**R05 · Prompt injection and tool security** · `active` · [S31], [S24]  
Untrusted retrieved or external content can redirect model behavior, especially when agents possess privileges. **Why it matters:** Enforce trust boundaries outside the model.  
Prerequisites: A03, D03.

**R06 · Model weight and supply-chain security** · `active` · [S27], [S31]  
Access controls, dependency provenance, infrastructure hardening and incident response matter as capability rises. **Why it matters:** Security is not reducible to refusal training.  
Prerequisites: C01.

**R07 · Sandboxing, permissions and rollback** · `active` · [S24], [S27]  
Least privilege, action allowlists, approvals, observability and reversible execution limit agent side effects. **Why it matters:** Build defense in depth for capable agents.  
Prerequisites: R05.

**R08 · High-stakes safety engineering** · `active` · [S27], [S07]  
Context-specific testing, monitoring and human authority are needed in medical, critical infrastructure and physical settings. **Why it matters:** One-size-fits-all model scores are inadequate.  
Prerequisites: E09, P10.

**R09 · Frontier catastrophic-risk assessment** · `contested` · [S07], [S30]  
Evaluate severe misuse, dangerous capabilities and loss-of-control scenarios while separating measured hazards from debated forecasts. **Why it matters:** High consequence warrants rigor without pretending certainty.  
Prerequisites: R02, E08.

**R10 · Automated alignment research** · `emerging` · [S23]  
AI-generated safety interventions can be tested on alignment benchmarks, yet robust transfer to frontier deployments remains open. **Why it matters:** Safety research may accelerate but can overfit proxies.  
Prerequisites: R04, L10.


### G — Governance, economy & society

*Rules, institutions, work, markets, and externalities.*

**G01 · Risk-based AI governance** · `core` · [S27], [S28]  
Rules depend on use context, severity, accountability and rights rather than model size alone. **Why it matters:** The right unit of regulation is often the deployed system.  
Prerequisites: R08.

**G02 · EU AI Act implementation** · `active` · [S28], [S33]  
EU rules apply in phases: GPAI since August 2025, general application August 2026, selected high-risk duties in 2027/2028. **Why it matters:** Dates and legal scope should be rechecked before compliance decisions.  
Prerequisites: G01.

**G03 · AI auditing and standards** · `active` · [S27], [S25]  
Risk registers, logs, testing and external evaluations make model performance and safeguards inspectable. **Why it matters:** Assurance depends on organizational incentives and evidence access.  
Prerequisites: E08, R07.

**G04 · Privacy, consent and copyright** · `active` · [S28], [S27]  
Training, retrieval and synthesis raise rights over personal data, licensed works and disclosure. **Why it matters:** Legitimacy constraints can be independent of capability.  
Prerequisites: D09.

**G05 · Labor, productivity and skill formation** · `active` · [S04], [S09]  
AI has heterogeneous productivity effects across tasks and workers; labor displacement and complementarity vary by context. **Why it matters:** Averages conceal both gains and slowdowns.  
Prerequisites: A09.

**G06 · Market structure and openness** · `active` · [S01], [S04]  
Compute capital, cloud infrastructure and closed/open ecosystems shape competition and access. **Why it matters:** Frontier capability is not evenly distributed.  
Prerequisites: C08, C10.

**G07 · Energy and resource externalities** · `active` · [S29]  
Data-center growth has grid and water consequences; global averages obscure local constraints and emissions. **Why it matters:** Infrastructure planning is part of AI governance.  
Prerequisites: C07.

**G08 · Education and AI literacy** · `active` · [S01], [S04]  
Learners need verification habits, domain judgment and safeguards against hidden competence erosion. **Why it matters:** Access alone does not guarantee understanding.  
Prerequisites: E06.

**G09 · Information integrity and democracy** · `active` · [S07], [S28]  
Synthetic media, ranking and persuasive systems change evidence provenance and discourse incentives. **Why it matters:** Public trust depends on verifiability and transparency.  
Prerequisites: P03, D01.

**G10 · Global asymmetry and inclusion** · `active` · [S01], [S04]  
Language, infrastructure, financial and regulatory differences change who captures benefits and bears risks. **Why it matters:** An atlas must map missing voices and regional differences.  
Prerequisites: D08, C10.


### U — Open frontiers & unknowns

*Research boundaries that require discriminating tests.*

**U01 · Reliable generalization** · `contested` · [S02], [S07]  
Will systems perform across domains and distributions without task-specific retuning or hidden shortcuts? **Why it matters:** Requires transferable performance, not a single leaderboard.  
Prerequisites: F06, E03.

**U02 · Causal world models** · `emerging` · [S18], [S19]  
Can latent simulators support interventionally correct planning rather than plausible video rollouts? **Why it matters:** Test counterfactual predictions against controlled reality.  
Prerequisites: M07, P04.

**U03 · Truthful reasoning traces** · `contested` · [S22], [S07]  
Can observers reliably distinguish faithful internal reasoning from post-hoc rationalization? **Why it matters:** Measure causal correspondence, not explanation elegance.  
Prerequisites: A01, R04.

**U04 · Continual trustworthy learning** · `emerging` · [S24]  
Can deployed agents update knowledge while protecting privacy, identity, oversight and prior competence? **Why it matters:** Test retention, rollback and adversarial updates.  
Prerequisites: L08, D06.

**U05 · Robust long-term agents** · `emerging` · [S08], [S24]  
Can agents operate for days on messy work at specified high reliability with safe escalation? **Why it matters:** Track at 80–99% success and post-deployment incidents.  
Prerequisites: A06, E07.

**U06 · Faithful mechanistic audits** · `emerging` · [S22], [S23]  
Can interpretable features predict or change harmful behavior across unseen conditions? **Why it matters:** Require prospective, intervention-based tests.  
Prerequisites: R04, E08.

**U07 · Autonomous scientific discovery** · `emerging` · [S21], [S05]  
Can systems generate new, replicated findings beyond search in verifiable digital tasks? **Why it matters:** Separate hypothesis, experiment, replication and value.  
Prerequisites: S09, S10.

**U08 · Embodied open-world competence** · `emerging` · [S02], [S19]  
Can robots generalize manipulation and social safety from lab to diverse homes and workplaces? **Why it matters:** Test out-of-distribution task completion and harm.  
Prerequisites: P08, P10.

**U09 · Safety against strategic misuse** · `contested` · [S07], [S24]  
How do safeguards scale when systems gain tools, long memory or adaptive adversaries? **Why it matters:** Requires independent adversarial evaluation.  
Prerequisites: R05, R09.

**U10 · AI-accelerated AI R&D** · `speculative` · [S21], [S23]  
Could AI-assisted coding and alignment research produce sustained recursive capability gains? **Why it matters:** Look for independently reproduced compounding gains.  
Prerequisites: A10, L10.

**U11 · Machine consciousness and moral status** · `speculative` · [S07]  
No agreed operational test establishes subjective experience in contemporary AI; philosophical and empirical debates persist. **Why it matters:** Avoid assigning personhood or dismissing all moral uncertainty by fiat.  
Prerequisites: F09.

**U12 · Governed power and legitimacy** · `contested` · [S27], [S28]  
Who authorizes highly capable agents, audits their decisions, and controls infrastructure across jurisdictions? **Why it matters:** A technical benchmark cannot answer a political legitimacy question.  
Prerequisites: G01, G03.


## Cross-cutting maps: six traversals

### 1. The capability stack

From statistical learning to measured reasoning: bottlenecks and tests at every step.

**F02** (Probability and statistics) → **L02** (Self-supervised pretraining) → **M01** (Transformers and attention) → **C03** (Compute-optimal scaling) → **C04** (Inference-time scaling) → **A02** (Deliberation and search) → **E01** (Benchmark design and construct validity) → **E04** (Task-based and outcome evaluations)

### 2. The reliable agent stack

Autonomy is an engineered control loop, not merely a model with a longer prompt.

**D03** (Retrieval-augmented generation) → **D05** (Context engineering) → **A03** (Tool and API use) → **A04** (Planning and hierarchical control) → **A06** (Long-horizon autonomy) → **R07** (Sandboxing, permissions and rollback) → **E07** (Holistic and adversarial evaluation) → **E09** (Longitudinal post-deployment monitoring)

### 3. AI for discovery

Prediction -> algorithmic search -> experimental falsification -> replication.

**S01** (Protein structure prediction) → **S03** (Genomics and regulatory prediction) → **S05** (AI-guided algorithm discovery) → **S09** (Causal scientific discovery) → **S10** (Research reproducibility) → **U07** (Autonomous scientific discovery)

### 4. Embodied intelligence

Models of the world must survive intervention and real physical variability.

**M07** (World and predictive models) → **P04** (Video world simulation) → **P05** (Vision-language-action policies) → **P06** (Embodied spatial reasoning) → **P08** (Robotic manipulation) → **U08** (Embodied open-world competence)

### 5. Frontier assurance

Valid tests, enforceable controls, independent audit and legitimate governance.

**E01** (Benchmark design and construct validity) → **E02** (Data leakage and contamination) → **E08** (Independent and double-blind evaluation) → **R04** (Mechanistic interpretability) → **R09** (Frontier catastrophic-risk assessment) → **G03** (AI auditing and standards) → **U12** (Governed power and legitimacy)

### 6. Access and externalities

Compute concentration, openness and local environmental consequences interact.

**C01** (AI accelerators and memory) → **C07** (Energy, water and siting) → **C08** (Open-weight ecosystems) → **G06** (Market structure and openness) → **G07** (Energy and resource externalities) → **G10** (Global asymmetry and inclusion)

## Evidence ledger: 18 propositions

### Q01 · Benchmark capability is accelerating, but performance remains jagged

**Evidence designation:** Supported · **Sources:** [S02] · **Nodes:** E01, A05, P08

**Support:** 2026 AI Index: OSWorld agent task success reached 66.3% in 2025 while robots succeeded on only about 12% of real household tasks in surveyed tests. These outcomes are distinct task suites.

**Boundary / defeater:** Do not average these into a general-intelligence score.

### Q02 · Benchmark saturation complicates progress measurement

**Evidence designation:** Supported · **Sources:** [S02] · **Nodes:** E01, E02

**Support:** The 2026 AI Index reports large improvements on newly challenging assessments and concerns about invalid benchmark items and leaderboard adaptation.

**Boundary / defeater:** Scores are sensitive to benchmark design and contamination.

### Q03 · Agent task time horizons are improving, within a narrow evaluation scope

**Evidence designation:** Supported · **Sources:** [S08] · **Nodes:** E05, A06

**Support:** METR measures a task difficulty threshold on self-contained software, ML and cybersecurity work at designated success levels; it explicitly cautions against inferring job automation.

**Boundary / defeater:** Time horizon is not AI runtime, universal competence, or reliability above the chosen threshold.

### Q04 · Inference-time compute is a material driver of some reasoning gains

**Evidence designation:** Supported · **Sources:** [S07] · **Nodes:** C04, A02

**Support:** International AI Safety Report 2026 highlights inference-time scaling on mathematics, coding and scientific problem solving.

**Boundary / defeater:** Cost and verifiability tradeoffs vary by task.

### Q05 · Independent frontier evaluation is a growing research frontier

**Evidence designation:** Supported · **Sources:** [S25], [S26] · **Nodes:** E08, G03

**Support:** Developer and evaluator publications advocate third-party and leakage-resistant assessment; double-blind frontier experiments were reported in 2026.

**Boundary / defeater:** Technical tests and publication independence remain separate governance issues.

### Q06 · Science-oriented AI is progressing from prediction to closed-loop search

**Evidence designation:** Supported · **Sources:** [S21], [S20], [S32] · **Nodes:** S03, S05, S09

**Support:** AlphaEvolve reports evaluator-backed algorithm improvements, while AlphaGenome and protein tools make predictive biological hypotheses accessible.

**Boundary / defeater:** Digital proof, predictive accuracy and wet-lab causal validation are different evidence standards.

### Q07 · Protein and genomics outputs still demand empirical follow-through

**Evidence designation:** Supported · **Sources:** [S20], [S06] · **Nodes:** S03, S04

**Support:** AlphaGenome predicts molecular variant effects and virtual-cell work remains dependent on experimental validation.

**Boundary / defeater:** Prediction does not show a variant caused disease in a person.

### Q08 · Physical-world generality lags digital benchmarks

**Evidence designation:** Supported · **Sources:** [S02], [S19] · **Nodes:** P06, P08

**Support:** Stanford reports a large lab-to-household gap for robot tasks, and robotics developers focus on spatial and embodied reasoning.

**Boundary / defeater:** Physical contexts, setups and baselines differ.

### Q09 · AI-related safety incidents and measurement gaps remain significant

**Evidence designation:** Supported · **Sources:** [S03] · **Nodes:** R08, E09

**Support:** Stanford reports 362 documented incidents in 2025 versus 233 in 2024, and sparse responsible-AI evaluation disclosure.

**Boundary / defeater:** Incident counts reflect reporting and taxonomy, not true underlying harm rates.

### Q10 · AI productivity effects are context-dependent

**Evidence designation:** Supported · **Sources:** [S04], [S09] · **Nodes:** G05

**Support:** Stanford reports gains in structured work and also a controlled study in which experienced open-source developers were slower with 2025 AI tools.

**Boundary / defeater:** Do not generalize single-domain studies to all work or to newer models.

### Q11 · Energy demand is a material infrastructure constraint

**Evidence designation:** Forecast · **Sources:** [S29] · **Nodes:** C07, G07

**Support:** IEA 2025 base case projects data-center electricity consumption around 945 TWh by 2030, with scenario dependence.

**Boundary / defeater:** A scenario projection is not observed 2030 consumption.

### Q12 · Regulation has moving, jurisdiction-specific effective dates

**Evidence designation:** Verified official · **Sources:** [S28] · **Nodes:** G02

**Support:** EU Commission lists general applicability in August 2026 with deferred specified high-risk obligations in December 2027 and August 2028.

**Boundary / defeater:** Consult legal text for particular use cases and later amendments.

### Q13 · Security threats extend beyond malicious user prompts

**Evidence designation:** Supported · **Sources:** [S31] · **Nodes:** R05, R07

**Support:** OWASP describes indirect prompt injection through untrusted documents and external material, especially consequential with tool privileges.

**Boundary / defeater:** Instruction hierarchy alone cannot guarantee secure execution.

### Q14 · Some interpretability research probes internal mechanisms

**Evidence designation:** Emerging · **Sources:** [S22] · **Nodes:** R04, U06

**Support:** 2026 interpretability programs investigate latent features and circuits; this is not comprehensive mechanistic understanding of frontier systems.

**Boundary / defeater:** Useful local explanations need prospective causal validation.

### Q15 · Open-weight status differs from reproducible openness

**Evidence designation:** Analytic synthesis · **Sources:** [S01], [S02] · **Nodes:** C08, G06

**Support:** Weights, code, datasets, compute, licensing and audit access differ; these distinctions affect independent replication and governance.

**Boundary / defeater:** Do not classify a system as fully open solely from weights.

### Q16 · AI governance must handle misuse, malfunction and systemic risks

**Evidence designation:** Supported · **Sources:** [S07] · **Nodes:** R09, G01

**Support:** International AI Safety Report 2026 separates deliberate misuse, unintentional failures and systemic deployment effects.

**Boundary / defeater:** The likelihood of different hazards remains unevenly evidenced.

### Q17 · AI organizational adoption does not mean widespread agent delegation

**Evidence designation:** Supported · **Sources:** [S04] · **Nodes:** A09, G05

**Support:** Stanford reports 88% organizational AI adoption in 2025, while agent deployment remained single-digit in nearly all business functions.

**Boundary / defeater:** Definitions and survey sampling constrain interpretation.

### Q18 · The next frontier is measurement and control as much as model capability

**Evidence designation:** Analytic synthesis · **Sources:** [S24], [S25], [S26] · **Nodes:** E08, R07, U05

**Support:** Long-horizon safety reports, leakage-resistant evaluations and monitoring methods converge on a wider system-of-systems measurement problem.

**Boundary / defeater:** This is an editorial synthesis, not a directly quantified consensus.

## Research frontier: discriminating experiments

### U01 · Cross-domain reliability  

**Question:** Will systems perform across domains and distributions without task-specific retuning or hidden shortcuts?

**What would count as progress:** Evaluations that span held-out tasks, tools, languages and hardware, at fixed reliability levels.

**Proposed discriminating test:** Longitudinal task suites with pre-registration; track regression and failure mode distribution, not only best-case scores.

**Failure of inference to avoid:** Independent, task-specific coverage, cost-limited evaluation and OOD performance remain insufficient. **Sources:** [S02], [S07]

### U02 · Interventionally faithful simulation  

**Question:** Can latent simulators support interventionally correct planning rather than plausible video rollouts?

**What would count as progress:** World-model predictions must match physical effects under controlled changes, not just look plausible.

**Proposed discriminating test:** Counterfactual scene interventions paired with measured real-world outcomes; analyze model calibration and drift.

**Failure of inference to avoid:** Image realism is not a valid substitute for causal dynamics. **Sources:** [S18], [S19]

### U03 · Faithful explanations  

**Question:** Can observers reliably distinguish faithful internal reasoning from post-hoc rationalization?

**What would count as progress:** Relate verbal reasoning to features and computations genuinely influencing predictions.

**Proposed discriminating test:** Intervene on hypothesized circuits and measure causal change on unseen questions.

**Failure of inference to avoid:** Attractive traces can be post-hoc rationalizations. **Sources:** [S22], [S07]

### U04 · Lifelong adaptation with repair  

**Question:** Can deployed agents update knowledge while protecting privacy, identity, oversight and prior competence?

**What would count as progress:** Update deployed models without forgetting, leakage or harmful personality/permission drift.

**Proposed discriminating test:** Multi-month controlled tests of memory edits, adversarial poisoning and rollback.

**Failure of inference to avoid:** Offline benchmark gains can mask long-term state defects. **Sources:** [S24]

### U05 · High-reliability agents  

**Question:** Can agents operate for days on messy work at specified high reliability with safe escalation?

**What would count as progress:** Robustly finish messy coherent projects with side-effect boundaries.

**Proposed discriminating test:** Compare 50/80/95% success, cost, near misses and external auditor assessment over multi-day tasks.

**Failure of inference to avoid:** Clean deterministic tasks are easier than most actual work. **Sources:** [S08], [S24]

### U06 · Actionable interpretability  

**Question:** Can interpretable features predict or change harmful behavior across unseen conditions?

**What would count as progress:** Predict safety-relevant behaviors from internal audit tools, prospectively.

**Proposed discriminating test:** Blind preregistered experiments with interventions on novel models and tasks.

**Failure of inference to avoid:** One visualized circuit is not whole-model verification. **Sources:** [S22], [S23]

### U07 · Replicated AI science  

**Question:** Can systems generate new, replicated findings beyond search in verifiable digital tasks?

**What would count as progress:** Establish scientifically new, durable knowledge, not only plausible hypotheses.

**Proposed discriminating test:** Independent laboratories replicate findings under registered protocols and report negative results.

**Failure of inference to avoid:** Publication novelty is not causal confirmation. **Sources:** [S21], [S05]

### U08 · Physical autonomy at scale  

**Question:** Can robots generalize manipulation and social safety from lab to diverse homes and workplaces?

**What would count as progress:** Generalize from controlled manipulation to homes, institutions and public spaces.

**Proposed discriminating test:** Diverse in-situ tasks; failure recovery, injury and human override metrics.

**Failure of inference to avoid:** Distribution shift plus humans is harder than simulator metrics. **Sources:** [S02], [S19]

### U09 · Robust safeguards under tool access  

**Question:** How do safeguards scale when systems gain tools, long memory or adaptive adversaries?

**What would count as progress:** Defend against external content injection and long-sequence agent drift.

**Proposed discriminating test:** Red-teams with real permissions but sandboxed side effects; measure attack success after mitigation.

**Failure of inference to avoid:** Refusal scores do not test enterprise authorization. **Sources:** [S07], [S24]

### U10 · Recursive R&D acceleration  

**Question:** Could AI-assisted coding and alignment research produce sustained recursive capability gains?

**What would count as progress:** Measure whether AI can repeatedly improve tools that improve subsequent AI research.

**Proposed discriminating test:** Independent cost-adjusted successive-round evaluations with strict leakage barriers.

**Failure of inference to avoid:** Evidence of individual discoveries does not imply unbounded loops. **Sources:** [S21], [S23]

### U11 · AI experience and moral uncertainty  

**Question:** No agreed operational test establishes subjective experience in contemporary AI; philosophical and empirical debates persist.

**What would count as progress:** Define observational implications, distinguish claims about phenomenal states from behavior.

**Proposed discriminating test:** Competing theories produce different falsifiable behavioral/neural-computational predictions where possible.

**Failure of inference to avoid:** No accepted consciousness detector exists. **Sources:** [S07]

### U12 · Legitimate and accountable autonomy  

**Question:** Who authorizes highly capable agents, audits their decisions, and controls infrastructure across jurisdictions?

**What would count as progress:** Couple action capability to reviewable delegation, contestation and institutional control.

**Proposed discriminating test:** Audits of decisions, responsibility, appeal and revocation across use settings.

**Failure of inference to avoid:** Social legitimacy is not solvable by optimizing a scalar reward. **Sources:** [S27], [S28]

## Boundary map: 10 persistent category errors

1. **Fluent output ≠ truth, comprehension or safety.**
2. **High benchmark score ≠ general capability.**
3. **A model answer ≠ a verified scientific finding.**
4. **World-like video ≠ interventionally faithful physics.**
5. **A chain-of-thought explanation ≠ the actual causal computation.**
6. **Agent execution ≠ legitimate authorization.**
7. **Long model runtime ≠ long task-completion time horizon.**
8. **More agent roles ≠ more reliable collective intelligence.**
9. **Open weights ≠ fully open, reproducible development.**
10. **Forecast or scenario ≠ observed outcome.**

## Maintenance and epistemic quality control

The evidence standard is deliberately plural: foundational mathematics and published methods; independently aggregated technical trends; direct tests by evaluators; manufacturer research labeled as such; official policy texts; and forecasts labeled as scenarios. Every node has a dated source pointer; references indicate contextual support, **not** a claim that the node's whole synthesis was proven by that publication. Relationship edges are editorial analytical links, not statistically inferred causality.

1. Capture a dated claim with precise population, task and metric.
2. Record primary source, independent replication, methods and conflicts.
3. Update node relationships and uncertainty flags.
4. Do not promote a frontier claim without discriminating evidence.
5. Revise or retire contradictory and superseded claims, retaining changelog.
6. Re-run integrity tests and export refreshed artifacts.

**Recommended cadence:** quarterly, or immediately after major new independent evidence or regulatory changes.

**Known limitations.** This is a curated synthesis, not a systematic review or an exhaustive bibliography. Statuses represent editorial assessment of evidence maturity as of the stated date, not quantitative probabilities. Coverage and reporting favor English-language and publicly accessible material. Company reports are marked as developer evidence and not treated as independent replication. Benchmark and governance facts can become stale; consult source date and methodology. Risk scenarios and normative judgments are distinct from measured technical capabilities.

## Source register

Sources are categorized by origin; developer research and developer policies are primary accounts of what developers reported, not proof of independent generalization.

- **[S01] Stanford HAI (2026)**. 2026 AI Index — overview. *independent synthesis*. https://hai.stanford.edu/ai-index/2026-ai-index-report
- **[S02] Stanford HAI (2026)**. 2026 AI Index — technical performance. *independent synthesis*. https://hai.stanford.edu/ai-index/2026-ai-index-report/technical-performance
- **[S03] Stanford HAI (2026)**. 2026 AI Index — responsible AI. *independent synthesis*. https://hai.stanford.edu/ai-index/2026-ai-index-report/responsible-ai
- **[S04] Stanford HAI (2026)**. 2026 AI Index — economy. *independent synthesis*. https://hai.stanford.edu/ai-index/2026-ai-index-report/economy
- **[S05] Stanford HAI (2026)**. 2026 AI Index — science. *independent synthesis*. https://hai.stanford.edu/ai-index/2026-ai-index-report/science
- **[S06] Stanford HAI (2026)**. 2026 AI Index — medicine. *independent synthesis*. https://hai.stanford.edu/ai-index/2026-ai-index-report/medicine
- **[S07] International AI Safety Report (2026-02-03)**. 2026 Report — extended policymakers summary. *international expert synthesis*. https://internationalaisafetyreport.org/publication/2026-report-extended-summary-policymakers
- **[S08] METR (2026-09-08)**. Task-completion time horizons, v1.1. *independent measurement*. https://metr.org/time-horizons/
- **[S09] METR (2025)**. Experienced open-source developers productivity RCT. *independent experiment*. https://metr.org/Early_2025_AI_Experienced_OS_Devs_Study-paper.pdf
- **[S10] Vaswani et al. (2017)**. Attention Is All You Need. *primary research*. https://arxiv.org/abs/1706.03762
- **[S11] Hoffmann et al. (2022)**. Training Compute-Optimal Large Language Models. *primary research*. https://arxiv.org/abs/2203.15556
- **[S12] Ho, Jain & Abbeel (2020)**. Denoising Diffusion Probabilistic Models. *primary research*. https://arxiv.org/abs/2006.11239
- **[S13] Lewis et al. (2020)**. Retrieval-Augmented Generation. *primary research*. https://arxiv.org/abs/2005.11401
- **[S14] Ouyang et al. (2022)**. Training language models to follow instructions with human feedback. *primary research*. https://arxiv.org/abs/2203.02155
- **[S15] Rafailov et al. (2023)**. Direct Preference Optimization. *primary research*. https://arxiv.org/abs/2305.18290
- **[S16] DeepSeek-AI (2025)**. DeepSeek-R1: Reasoning via reinforcement learning. *developer research*. https://arxiv.org/abs/2501.12948
- **[S17] Gu & Dao (2023)**. Mamba: Linear-Time Sequence Modeling. *primary research*. https://arxiv.org/abs/2312.00752
- **[S18] Google DeepMind (2025-08-05)**. Genie 3: interactive world models. *developer research*. https://deepmind.google/blog/genie-3-a-new-frontier-for-world-models/
- **[S19] Google DeepMind (2026-04-14)**. Gemini Robotics-ER 1.6. *developer research*. https://deepmind.google/blog/gemini-robotics-er-1-6/
- **[S20] Avsec et al. (2026)**. AlphaGenome: regulatory variant effect prediction. *peer-reviewed research*. https://www.nature.com/articles/s41586-025-10014-0
- **[S21] Novikov et al. (2025)**. AlphaEvolve: coding agent for discovery. *developer research*. https://arxiv.org/abs/2506.13131
- **[S22] Anthropic (2026)**. Interpretability research program. *developer research*. https://www.anthropic.com/research/team/interpretability
- **[S23] Anthropic (2026-08-28)**. Automated researchers can mitigate alignment failures. *developer research*. https://www.anthropic.com/research/automated-researchers-mitigate-alignment-failures
- **[S24] OpenAI (2026-07-20)**. Safety and alignment in an era of long-horizon models. *developer incident analysis*. https://openai.com/index/safety-alignment-long-horizon-models/
- **[S25] OpenAI (2026-05-29)**. Trustworthy third-party evaluations. *developer guidance*. https://openai.com/index/trustworthy-third-party-evaluations-foundations/
- **[S26] Google DeepMind (2026-08-27)**. Piloting double-blind AI evaluations. *developer research*. https://deepmind.google/blog/piloting-the-worlds-first-double-blind-ai-evaluations/
- **[S27] NIST (2023–2026)**. AI Risk Management Framework and Generative AI Profile. *government framework*. https://www.nist.gov/itl/ai-risk-management-framework
- **[S28] European Commission (2026)**. EU AI Act: risk-based rules and application timeline. *official regulation*. https://digital-strategy.ec.europa.eu/en/policies/regulatory-framework-ai
- **[S29] International Energy Agency (2025)**. Energy and AI: data-centre projections. *intergovernmental forecast*. https://www.iea.org/reports/energy-and-ai/executive-summary
- **[S30] OpenAI (2025-04-15)**. Updated Preparedness Framework. *developer governance*. https://openai.com/index/updating-our-preparedness-framework/
- **[S31] OWASP (2025–2026)**. GenAI Security / Top 10 for LLM Apps. *security standards community*. https://owasp.org/projects/top-10-for-large-language-model-applications
- **[S32] Google DeepMind (2025)**. AlphaFold five years of impact. *developer synthesis*. https://deepmind.google/blog/alphafold-five-years-of-impact/
- **[S33] European Commission (2026)**. AI Act legislative simplification and governance. *official regulation*. https://digital-strategy.ec.europa.eu/en/policies/regulatory-framework-ai
- **[S34] Google DeepMind (2026-09-08)**. AlphaGenome Atlas, large-scale predicted variants. *developer release*. https://blog.google/innovation-and-ai/models-and-research/google-deepmind/alphagenome-atlas/
- **[S35] OpenAI (2026-05-28)**. Frontier Governance Framework. *developer governance*. https://openai.com/index/openai-frontier-governance-framework/
- **[S36] Google DeepMind (2022)**. AlphaFold: scientific discovery. *developer research*. https://deepmind.google/blog/alphafold-using-ai-for-scientific-discovery/
- **[S37] OpenAI (2026-06-03)**. Blueprint for democratic governance of frontier AI. *developer policy proposal*. https://openai.com/index/frontier-safety-blueprint/
- **[S38] Google DeepMind (2024-09-05)**. AlphaProteo: novel protein design. *developer research*. https://deepmind.google/blog/alphaproteo-generates-novel-proteins-for-biology-and-health-research/

## Data dictionary

`nodes`: `id, territory, title, definition, state, source_ids, prerequisites, significance`; `relations`: `source, target, type`; `claims`: `id, claim, evidence_state, support, source_ids, node_ids, limitation`; `frontiers`: `id, name, research_question, discriminating_evidence, proposed_test, watch_out, source_ids`; `sources`: `id, publisher, title, date, url, kind`. The JSON is authoritative.
