# THE CREATIVITY ATLAS
**As of:** 17 OCT 2026 | **Edition:** 1.0 | **Status:** curated research synthesis

> A creativity claim should specify **whose novelty**, **which value**, **for whom**, **at what level**, **under what constraints**, **with what evidence** and **with what consequences**.

## Orientation

Creativity is the situated emergence, evaluation and development of sufficiently new and fitting possibilities. It takes place across mental processes, people, artifacts, collaborations, cultures, technical tools and institutions. Creativity is not synonymous with innovation (implementation), divergent thinking (a potential measure), genius (a rare scale of impact), nor ethical benefit (a separate question). [S01, S02, S03, S04]

### Twelve territories

## Foundations — What makes an idea creative, for whom, and why?

**Central thesis.** Creativity is a context-sensitive judgment about novelty and fit, not a synonym for genius, ideational fluency, or commercial success.

**Concepts:** Originality, Usefulness / fit, Surprise, Context and audience, Four-C scale, Creation vs. innovation.

**Mechanisms.** Distinct loci of judgment: personally novel learning (mini-c), everyday contribution (little-c), professional contribution (Pro-c), historically eminent work (Big-C). An original but unusable output may fail a task-specific creativity criterion.

**Core tension.** Novelty and appropriateness can pull in different directions; whose appropriateness counts is a cultural and political question.

**Practice.** Specify the reference class, intended beneficiary and success criteria before scoring creative work.

**Unresolved frontier.** Non-market value, accessibility, sustainable impact and downstream effects challenge narrow novelty × usefulness scoring.

**Supporting sources:** S01, S04, S02, S21.

## Creative process — What happens between a messy question and a valued outcome?

**Central thesis.** A creative process cycles among framing, exploration, combination, appraisal, experimentation and revision; it is rarely a linear funnel.

**Concepts:** Problem finding, Reframing, Divergent search, Convergent appraisal, Incubation, Prototyping & iteration.

**Mechanisms.** Generative exploration expands candidate spaces; selective evaluation and experiments impose real-world constraints. Incubation may sometimes help but depends on task and cognitive load.

**Core tension.** Premature selection causes fixation; endless divergence prevents delivery.

**Practice.** Alternate broad search and rigorous selection; make an external artifact early; use a short low-demand break if stuck.

**Unresolved frontier.** Adaptive sequencing: when should a team generate, refine, rest, test or ask an AI system?

**Supporting sources:** S06, S24, S25, S20.

## Cognitive mechanisms — Which general mental processes construct new possibilities?

**Central thesis.** Associative retrieval and analogies work alongside executive search, memory control, abstraction and persistent refinement.

**Concepts:** Semantic associations, Analogy transfer, Episodic recombination, Cognitive flexibility, Cognitive persistence, Fixation & release.

**Mechanisms.** Two routes to originality can coexist: switching among categories and searching one category deeply. Remote associations need relevant prior knowledge and selection.

**Core tension.** Breadth without expertise can be shallow; expertise without boundary crossing can become rigid.

**Practice.** Search three remote domains for structural analogies, then probe the strongest analogy for mechanism and disanalogy.

**Unresolved frontier.** Separating creative-specific ability from domain-general memory and control in ecologically valid tasks.

**Supporting sources:** S06, S08, S20, S05.

## Neuroscience — What brain systems support creative thinking?

**Central thesis.** Large-scale evidence increasingly favors interacting general-purpose networks, not a dedicated “creativity center” or a simple right-brain theory.

**Concepts:** Default-mode systems, Executive control, Salience switching, Semantic knowledge, Episodic retrieval, Dynamic network coupling.

**Mechanisms.** Default-mode and control systems participate in self-generated ideas and selection; semantic and episodic retrieval supply content. A 2026 ALE synthesis found extensive overlap with domain-general cognitive cornerstones.

**Core tension.** Brain-activity overlap is not a uniquely identifying neural mechanism, and localization does not establish causal sufficiency.

**Practice.** Use neuroclaims as explanatory hypotheses; never infer a person’s creative capacity from a cartoon hemisphere or single brain region.

**Unresolved frontier.** Time-resolved, causal, naturalistic multimodal studies across domains and populations.

**Supporting sources:** S07, S08, S09, S10.

## Person & development — How do skills, opportunities and identity evolve?

**Central thesis.** Creative performance emerges from developing expertise, adaptive habits, confidence and opportunity; traits are not destiny.

**Concepts:** Domain expertise, Openness & curiosity, Creative self-efficacy, Deliberate practice, Developmental pathways, Constraints & access.

**Mechanisms.** Expertise provides useful primitives and criteria; intrinsic interest can sustain deeper search. Creative self-belief is not interchangeable with observed creative performance.

**Core tension.** Gifted-person narratives hide learning, infrastructure and unequal access.

**Practice.** Build a portfolio of small artifacts, invite calibrated feedback and track capabilities rather than declaring a fixed creative type.

**Unresolved frontier.** Longitudinal and culturally inclusive pathways from childhood play through skilled and late-life creation.

**Supporting sources:** S02, S04, S18, S11.

## Motivation & emotion — What sustains exploration through uncertainty?

**Central thesis.** Intrinsic motivation, autonomy and engagement often support creative work, but affect effects are conditional rather than a recipe for cheerful inspiration.

**Concepts:** Intrinsic motivation, Autonomy, Persistence under ambiguity, Affect & activation, Attention allocation, Recovery & play.

**Mechanisms.** Motivation shapes which problems receive time and which alternatives are pursued. Positive and negative activating states can influence flexibility and persistence differently.

**Core tension.** External incentives can help if informational or enabling; coercive or controlling incentives can narrow ownership and risk-taking.

**Practice.** Protect uninterrupted maker time, choose self-endorsed questions and treat mood manipulation claims cautiously.

**Unresolved frontier.** When does AI productivity assistance displace ownership and long-run intrinsic drive?

**Supporting sources:** S02, S06, S26, S24.

## Teams & collaboration — How can many minds create better than one?

**Central thesis.** Collective creativity depends on information distribution, coordination and judging—not simply placing more people in a brainstorming room.

**Concepts:** Independent ideation, Psychological safety, Cognitive diversity, Production blocking, Idea synthesis, Selection governance.

**Mechanisms.** Silent parallel ideation avoids turn-taking losses; diverse task-relevant perspectives may broaden search if integration and fair airtime follow.

**Core tension.** Diversity without coordination brings conflict; harmony without dissent narrows possibilities.

**Practice.** Write independently first; cluster without erasing minority ideas; debate criteria; test a portfolio rather than crown one winner immediately.

**Unresolved frontier.** Human–AI teams where agents can amplify both group throughput and shared cognitive anchors.

**Supporting sources:** S23, S29, S34, S12.

## Culture & systems — How do institutions decide which novelty matters?

**Central thesis.** Creativity is also an ecology of traditions, gatekeepers, resources, incentives, audiences and historical timing.

**Concepts:** Domain conventions, Field gatekeepers, Cultural valuation, Power and access, Institutions & incentives, Diffusion & recognition.

**Mechanisms.** The systems model links person, cultural domain and field of evaluators. Measures calibrated in one culture can distort comparisons in another.

**Core tension.** Historical recognition can reflect power and distribution channels rather than intrinsic idea merit.

**Practice.** Map stakeholders and gatekeepers, audit whose criteria are missing, and recruit evaluators from affected communities.

**Unresolved frontier.** Cross-cultural measurement invariance; equitable recognition of situated, collective and Indigenous creative practice.

**Supporting sources:** S03, S21, S22, S29.

## Measurement & science — How do we know a creative result is real?

**Central thesis.** No single creativity score measures potential, process, product, impact and population diversity at once.

**Concepts:** Consensual assessment, Alternate Uses Task, Originality & quality, Inter-rater agreement, Ecological validity, Longitudinal impact.

**Mechanisms.** Triangulate artifact quality, feasibility, process trace and downstream effects. Automated novelty scoring can be useful, but scorer bias, prompt sensitivity and construct drift matter.

**Core tension.** Reliable proxies can become targets for gaming and lose their link to meaningful creativity.

**Practice.** Predefine context and comparison set; blind-score with several human judges; measure both quality and variety; audit AI scoring.

**Unresolved frontier.** Human–AI evaluator calibration across languages, modalities and genuinely open-ended outcomes.

**Supporting sources:** S17, S18, S19, S33.

## Design & innovation — How does creative thought become useful change?

**Central thesis.** Creativity precedes but does not guarantee innovation; translation needs prototypes, testing, adoption and responsible stewardship.

**Concepts:** Design constraints, Experimentation, Rapid prototyping, User co-creation, Scaling & adoption, Implementation fidelity.

**Mechanisms.** Constraints create a search grammar; prototypes reveal unanticipated frictions. Value emerges through use, not only aesthetic judgment.

**Core tension.** Premature market metrics exclude exploratory breakthroughs; ignoring adoption renders a clever idea inert.

**Practice.** Prototype the risky assumption first; track solution quality separately from uptake and external effects.

**Unresolved frontier.** Design for long-horizon public goods, accessibility, environment and complex adaptive systems.

**Supporting sources:** S02, S03, S25, S34.

## Human–AI co-creativity — Where does generative AI help, homogenize or weaken learning?

**Central thesis.** AI support often raises individual output quality in bounded tasks, yet shared suggestions can compress population-level diversity and create dependence.

**Concepts:** AI ideation support, Anchoring & homogenization, Human editorial agency, Model diversity, Skill atrophy risk, Hybrid evaluation.

**Mechanisms.** AI can provide low-friction examples and alternative frames; common model priors may supply the same anchors to many users. Task breadth and assistance intensity moderate outcomes.

**Core tension.** Immediate performance may improve while collective novelty, intrinsic motivation or independent ability decline.

**Practice.** Write human-first; solicit divergent and contradictory AI outputs; record source of key ideas; finish with blind human evaluation and an AI-free transfer test.

**Unresolved frontier.** Longitudinal causal tests of AI augmentation, originality, attribution, cultural plurality and genuine independent skill transfer.

**Supporting sources:** S12, S13, S14, S15, S16, S17, S26, S31, S35.

## Ethics & futures — When does imaginative novelty help or harm?

**Central thesis.** Novelty and effectiveness are insufficient as moral tests; creative systems need impact, rights, consent, sustainability and accountability.

**Concepts:** Beneficence vs. harm, Attribution & consent, Plural futures, Environmental footprint, Distribution of gains, Governance & reversibility.

**Mechanisms.** Novel tactics can also be harmful. High-impact artifacts require evaluation of affected people, failure modes, power and unintended consequences.

**Core tension.** The same capacity to invent effective methods can serve beneficial, exploitative or destructive ends.

**Practice.** Add an ethics gate before diffusion: affected parties, foreseeable misuse, contestability, credit, provenance and rollback.

**Unresolved frontier.** Governance of AI-mediated cultural production, creative labor, misinformation and concentration of the imagination commons.

**Supporting sources:** S28, S21, S12, S30.

## Comparing the principal models

| Model | What it explains | Where it should not be overread | Source |
|---|---|---|---|
| Novelty × fit | Criteria for products; necessary but context-bound | Do not equate novelty with quality | S01 |
| Componential | Expertise + creative processes + motivation + social environment | Not a deterministic equation | S02 |
| Systems | Person ↔ domain ↔ field / gatekeepers | Recognition is not identical to merit | S03 |
| Four C | mini-c / little-c / Pro-c / Big-C developmental scales | Not four fixed personality kinds | S04 |
| Three kinds | Combine / explore / transform conceptual space | Conceptual taxonomy, not a ranking of persons | S05 |
| Dual pathway | Flexibility OR persistent depth can produce originality | No universal instruction to always brainstorm widely | S06 |
| Network dynamics | Interacting self-generated cognition, memory and control | Correlational imaging ≠ proof of a unique creativity network | S08 |
| Sociotechnical augmentation | AI helps some individual outputs, may narrow collective diversity | Highly task-, model- and exposure-dependent | S12 |

## Evidence ledger

The editorial evidence state is a *qualitative navigation aid*, not a numerical certainty score; read every claim's caveat. [See methodology.]

**C01 · Supported** — Creativity assessments usually consider originality alongside appropriateness for a context.
  - Boundary: Definitions differ across domains; ethical value is a distinct judgment.
  - Sources: S01, S02

**C02 · Framework** — Creativity operates at personal, everyday, professional and eminent scales.
  - Boundary: Four-C is a conceptual model, not a developmental law.
  - Sources: S04

**C03 · Supported** — Domain expertise, relevant creative skills, motivation and environment all shape performance.
  - Boundary: Relative contributions depend on task and context.
  - Sources: S02

**C04 · Framework** — Field gatekeepers and cultural domains influence recognition of creativity.
  - Boundary: The model explains legitimacy processes, not just idea quality.
  - Sources: S03

**C05 · Supported** — Original ideas may arise through flexible category switching or persistent search.
  - Boundary: Effects depend on task and operational measures.
  - Sources: S06

**C06 · Supported** — Divergent and convergent task scores can be positively associated.
  - Boundary: Association does not establish one unified cognitive factor.
  - Sources: S20

**C07 · Supported** — Creative thinking recruits interacting default-mode and control systems.
  - Boundary: Imaging measures covariation; interpretations are task-dependent.
  - Sources: S07, S09, S10

**C08 · Supported** — A 2026 ALE synthesis of 787 experiments found overlap with general semantic, episodic and executive mechanisms.
  - Boundary: Meta-analytic overlap does not prove complete equivalence or causality.
  - Sources: S08

**C09 · Supported** — Creativity training yields positive average effects, smaller after bias adjustment.
  - Boundary: 2024 analysis: 169 studies; adjusted estimates ~0.29–0.32 SD; substantial quality limitations.
  - Sources: S11

**C10 · Supported** — Creative self-belief is a poor substitute for divergent-thinking performance.
  - Boundary: Measures tap different constructs; effects vary by instrument.
  - Sources: S18

**C11 · Interpretive** — No one short divergent-thinking task captures real-world creative success.
  - Boundary: Based on construct and ecological-validity limitations across measurement studies.
  - Sources: S18, S19, S33

**C12 · Supported** — Novelty scoring should be distinguished from fluency, elaboration and feasibility.
  - Boundary: Automated scoring may confuse response length, frequency and semantic distance.
  - Sources: S18, S19

**C13 · Supported** — In-person interactive brainstorming often loses idea output relative to pooled individual work.
  - Boundary: Specific comparison; later synthesis quality needs separate testing.
  - Sources: S23, S34

**C14 · Supported** — More generated ideas do not guarantee better final selection.
  - Boundary: One experiment showed selections were not significantly better than chance.
  - Sources: S34

**C15 · Supported** — Deep-level cultural diversity in teams may aid innovation more reliably than surface-level differences.
  - Boundary: Observational synthesis; mediation and boundary conditions remain open.
  - Sources: S29

**C16 · Supported** — Creativity assessment is sensitive to culture, framing and evaluator norms.
  - Boundary: Country-level East/West averages should not be essentialized.
  - Sources: S21, S22

**C17 · Supported** — A meta-analysis finds task framing moderates observed cross-cultural score gaps.
  - Boundary: Measurement invariance remains an active concern.
  - Sources: S22

**C18 · Mixed** — Mind wandering does not uniformly enhance creative performance.
  - Boundary: 2024 experiments found conditional effects by working memory and cognitive load.
  - Sources: S24

**C19 · Emerging** — Sequential prompts for divergent/convergent subprocesses can improve solutions in study tasks.
  - Boundary: 2026 educational task setting; transfer unknown.
  - Sources: S25

**C20 · Supported** — GenAI ideas increased rated creativity of short stories in a randomized experiment.
  - Boundary: Benefit strongest for some lower-baseline writers; short-story setting.
  - Sources: S12

**C21 · Supported** — AI-assisted stories were more similar across writers in that same study.
  - Boundary: Population-level diversity not the same as average individual quality.
  - Sources: S12

**C22 · Emerging** — A 2025 meta-analysis preprint estimates average AI-assisted human creativity gains.
  - Boundary: 28 studies, 8,214 participants, g ≈ 0.27; preprint and heterogeneous tasks.
  - Sources: S13

**C23 · Supported** — AI assistance can significantly narrow diversity across creative outputs.
  - Boundary: Consistent in some writing settings; effect size not universally portable.
  - Sources: S12, S14

**C24 · Emerging** — Some 2026 evidence suggests AI creative dependence may persist after AI removal.
  - Boundary: Longitudinal signal in one research programme, not a general law.
  - Sources: S15

**C25 · Emerging** — The creative benefit of fine-tuned AI prompts can depend on task breadth.
  - Boundary: 2026 experiments: broader tasks benefited in flexibility; narrow tasks did not.
  - Sources: S16

**C26 · Emerging** — AI may contribute as one member of an expert evaluation panel on constrained tasks.
  - Boundary: 2026 study reports comparable reliability; means and dispersion still differ.
  - Sources: S17

**C27 · Emerging** — GenAI collaboration can improve performance while reducing intrinsic motivation.
  - Boundary: Four 2025 online experimental studies in professional-style settings.
  - Sources: S26

**C28 · Emerging** — A single 2025 scientific-discovery setup showed limitations of GPT-4 in anomaly-led discovery.
  - Boundary: Cannot justify universal claims that no AI can discover science.
  - Sources: S27

**C29 · Supported** — AI systems for long-horizon autonomous scientific discovery remain an active research problem.
  - Boundary: 2025 perspective identifies evaluation, tooling and integration gaps.
  - Sources: S30

**C30 · Emerging** — Increasing AI involvement need not monotonically improve original writing.
  - Boundary: 2026 Chinese-writing experiment found limited brainstorming beneficial; full co-writing reduced originality.
  - Sources: S31

**C31 · Supported** — Novel and effective ideas can nevertheless be morally harmful.
  - Boundary: Malevolent creativity research separates novelty from beneficence.
  - Sources: S28

**C32 · Framework** — Creative outcomes depend on translation, adoption and the field that judges them.
  - Boundary: Systems and componential views; innovation is implementation, not ideation alone.
  - Sources: S02, S03

**C33 · Framework** — Combinational, exploratory and transformational processes are distinct ways to organize creative search.
  - Boundary: Taxonomy by Boden; not mutually exclusive mechanisms.
  - Sources: S05

**C34 · Supported** — AI creativity assistance depends on task stage and expertise, not just whether a tool is available.
  - Boundary: Two design experiments find gains at ideation for novice and expert designers, but implementation tradeoffs for experts.
  - Sources: S35

**C35 · Interpretive** — AI evaluation requires checks for reliability, calibration and cultural representativeness.
  - Boundary: A design principle inferred from evaluator studies and cultural research.
  - Sources: S17, S21

**C36 · Interpretive** — Novelty-generating capacity should be governed by consequences, consent and distribution.
  - Boundary: Ethical design judgment; not a psychometric finding.
  - Sources: S28, S21

## Creative operating modes

These are **design heuristics**, not psychometric personality types or diagnostic labels.

- **Cartographer** — Define the problem space. Draw boundaries, criteria, affected audiences.
- **Scout** — Collect unusual stimuli. Sample beyond near neighbors and dominant examples.
- **Connector** — Transfer structure. Match relationships rather than superficial likeness.
- **Reframer** — Change the question. Invert constraints and reveal a hidden assumption.
- **Diverger** — Widen the option set. Delay verdicts; seek genuinely distinct families.
- **Incubator** — Release fixation. Use task-appropriate breaks, not magical waiting.
- **Critic** — Apply discriminating tests. Separate novelty, value, risk and feasibility.
- **Maker** — Externalize and iterate. Build the cheapest informative prototype.
- **Conductor** — Coordinate a group. Independent input first, transparent synthesis later.
- **Auditor** — Challenge evidence. Blind ratings, controls, provenance, disconfirmation.
- **Orchestrator** — Direct human–AI work. Use AI for variation without surrendering authorship.
- **Guardian** — Protect long-term value. Check externalities, rights, fairness and reversibility.

## Twelve-step applied protocol

1. **Frame:** Write a challenge as a testable question. Record users, constraints and what success would change.
2. **Sample:** Collect 12 stimuli spanning close, adjacent and far domains. Mark source and context.
3. **Generate:** Write 12 genuinely distinct ideas individually before anyone sees model or team suggestions.
4. **Reframe:** Invert a constraint; find a hidden assumption; state a more interesting problem.
5. **Cross-pollinate:** Translate 3 structural analogies; write why each analogy might fail.
6. **Rest or persist:** If fixated, use a low-demand break. If promising, persist deeply through mechanisms.
7. **Judge:** Blind-score novelty, stakeholder value, feasibility, uncertainty and harm separately.
8. **Prototype:** Build the smallest artifact that could disconfirm a crucial assumption.
9. **Collaborate:** Pool independent ideas; preserve minority clusters; synthesize without premature ranking.
10. **Use AI deliberately:** Human-first baseline, then adversarial AI variation, then AI-free refinement/transfer test.
11. **Measure:** Track artifact quality, concept-category diversity, judged value and real uptake.
12. **Govern & learn:** Credit sources, assess harms, seek affected-person feedback, version results and repeat.

## A research agenda: frontier questions

### R1 · AI augmentation vs. independent skill
**Question:** Can people transfer ability to AI-free tasks after long exposure?
**Discriminating test:** Randomize assistance intensity; measure delayed unassisted artifacts.
**Scope:** Longitudinal; high priority · Starting point: [S15].

### R2 · Individual gains vs. commons diversity
**Question:** How does widespread model use affect novelty distribution across societies?
**Discriminating test:** Multi-site, multilingual outputs; diversity growth curves and originality panels.
**Scope:** Population-level; high priority · Starting point: [S12].

### R3 · Neural necessary mechanisms
**Question:** Which memory/control interventions causally change real creative products?
**Discriminating test:** Preregister causal perturbation and naturalistic multimodal work.
**Scope:** Mechanistic; high priority · Starting point: [S08].

### R4 · Validity beyond word tasks
**Question:** Do laboratory creativity scores predict real-world impact across modalities?
**Discriminating test:** Prospective cohorts with blinded artifact panels and later adoption.
**Scope:** Methodological; high priority · Starting point: [S19].

### R5 · Culture-fair evaluation
**Question:** Can scoring criteria transfer across languages and systems of value?
**Discriminating test:** Measurement-invariance and stakeholder-based judgments.
**Scope:** Justice; high priority · Starting point: [S22].

### R6 · Adaptive stage-specific AI
**Question:** At what creative stage does an AI suggestion help, distract or fixate?
**Discriminating test:** Randomize timing and whether AI leads, follows or critiques.
**Scope:** Design; near term · Starting point: [S16].

### R7 · Human–AI evaluation bias
**Question:** When should an AI judge join, not replace, domain experts?
**Discriminating test:** Panel composition and calibration experiments.
**Scope:** Governance; near term · Starting point: [S17].

### R8 · Adaptive exploration strategy
**Question:** When does deep persistence outperform far association?
**Discriminating test:** Causal manipulations of structure, time and constraints.
**Scope:** Mechanistic; near term · Starting point: [S06].

### R9 · Institutional gatekeeping
**Question:** Who gets credit for creative work with collective and AI contributions?
**Discriminating test:** Natural experiments in juries, awards, procurement, platforms.
**Scope:** Social; medium term · Starting point: [S03].

### R10 · Creativity, ethics and long-run value
**Question:** How can one test benefits and harms that appear years after adoption?
**Discriminating test:** Participatory impact review, monitoring and reversible launch gates.
**Scope:** Normative; ongoing · Starting point: [S28].

## Measurement stack

| Layer | Example observation | Failure to avoid |
|---|---|---|
| Potential | Alternative Uses / semantic variety | Mistaking fluency for creative products |
| Process | Traces of framing, exploration, iteration | Treating any one process as universally optimal |
| Artifact | Blind human panels rate novelty and appropriateness separately | Halo effects, evaluator bias |
| Implementation | Real adoption, utility, robustness, cost | Confusing adoption with intrinsic quality |
| Collective | Diversity growth across independent outputs | Averaging away homogenization |
| Ethics | Harms, rights, distribution, environment | Equating usefulness with moral good |

## Attribution and governance

A collaboration log should record human prompts, AI version, generated suggestions, reused references, independent development, cultural stakeholders, edits, evaluation protocol, and revision or removal decisions. Attribution, consent, safeguards and who bears externalities are not reducible to one creativity score.

## Reading rules, uncertainty and limitations

- Research scan current through 2026-10-17; not a systematic review of every subfield.
- Sources are selected anchors and recent signals, not a complete corpus or formal study-quality audit.
- Evidence-state labels are editorial judgments, not calibrated probabilities or GRADE levels.
- The network layout and cross-domain edges are interpretive; they are not inferred causal graphs.
- Persona/mode labels are design heuristics, not empirically validated psychological types.
- Claims tied to new AI systems may change rapidly; model version and task matter.
- Culture categories are broad and heterogeneous, and culture-fair evaluation is not solved.

The **cross-domain edges** in the graph are an editorial interpretation, **not** empirical causal estimates. Prioritize seminal frameworks, reviews/meta-analyses, randomization, large samples and peer-reviewed 2024–2026 research. Mark preprints explicitly.

## Reference library

- **[S01]** Runco & Jaeger (2012). *The Standard Definition of Creativity*. Creativity Research Journal. https://doi.org/10.1080/10400419.2012.650092 (framework).
- **[S02]** Amabile (2012). *Componential Theory of Creativity*. Harvard Business School Working Paper 12-096. https://www.hbs.edu/ris/Publication%20Files/12-096.pdf (framework).
- **[S03]** Csikszentmihalyi (2014). *The Systems Model of Creativity and Its Applications*. The Wiley Handbook of Genius. https://doi.org/10.1002/9781118367377.ch25 (framework).
- **[S04]** Kaufman & Beghetto (2009). *Beyond Big and Little: The Four C Model of Creativity*. Review of General Psychology. https://doi.org/10.1037/a0013688 (framework).
- **[S05]** Boden (2009). *Computer Models of Creativity*. AI Magazine. https://doi.org/10.1609/aimag.v30i3.2254 (framework).
- **[S06]** Nijstad et al. (2010). *The dual pathway to creativity model: Creative ideation as a function of flexibility and persistence*. European Review of Social Psychology. https://doi.org/10.1080/10463281003765323 (theory).
- **[S07]** Beaty et al. (2016). *Creative Cognition and Brain Network Dynamics*. Trends in Cognitive Sciences. https://pmc.ncbi.nlm.nih.gov/articles/PMC4724474/ (review).
- **[S08]** Chan, Lambon Ralph & Robinson (2026). *The neural basis of creative thought: An ALE meta-analysis of 787 experiments*. Cortex. https://doi.org/10.1016/j.cortex.2026.06.022 (meta-analysis).
- **[S09]** Cubillos-Pinilla et al. (2025). *Neural foundations of creativity: A voxel-based meta-analysis across linguistic, musical, and visual domains*. Neuroscience & Biobehavioral Reviews. https://doi.org/10.1016/j.neubiorev.2025.106354 (meta-analysis).
- **[S10]** Luchini, Volle & Beaty (2025). *The role of the default mode network in creativity*. Current Opinion in Behavioral Sciences. https://doi.org/10.1016/j.cobeha.2025.101551 (review).
- **[S11]** Sio & Lortie-Forgues (2024). *The impact of creativity training on creative performance: A meta-analytic review and critical evaluation of 5 decades*. Psychological Bulletin. https://doi.org/10.1037/bul0000432 (meta-analysis).
- **[S12]** Doshi & Hauser (2024). *Generative AI enhances individual creativity but reduces the collective diversity of novel content*. Science Advances. https://doi.org/10.1126/sciadv.adn5290 (randomized experiment).
- **[S13]** Holzner, Maier & Feuerriegel (2025). *Generative AI and Creativity: A Systematic Literature Review and Meta-Analysis*. arXiv preprint. https://arxiv.org/abs/2505.17241 (preprint meta-analysis).
- **[S14]** Moon, Green & Kushlev (2025). *Homogenizing effect of LLMs on creative diversity: Human and ChatGPT writing*. Computers in Human Behavior: Artificial Humans. https://doi.org/10.1016/j.chbah.2025.100207 (preregistered experiments).
- **[S15]** Zhou et al. (2026). *Creative scar without generative AI: Individual creativity fails to sustain while homogeneity keeps climbing*. Technology in Society. https://doi.org/10.1016/j.techsoc.2025.103087 (natural and lab experiments).
- **[S16]** Sorin & Pagani (2026). *The role of task breadth and cognitive flexibility in generative AI-supported creative idea generation*. Technovation. https://doi.org/10.1016/j.technovation.2026.103540 (randomized experiments).
- **[S17]** Addis et al. (2026). *Evaluating creative work with artificial intelligence: Evidence from constrained innovation tasks*. Technovation. https://doi.org/10.1016/j.technovation.2026.103571 (evaluation study).
- **[S18]** Wahbeh et al. (2024). *Creative self-belief responses versus manual and automated alternate use task scoring*. Journal of Creativity. https://doi.org/10.1016/j.yjoc.2024.100088 (measurement study).
- **[S19]** Scherbakova et al. (2025). *Reversing the alternate uses task*. Thinking Skills and Creativity. https://doi.org/10.1016/j.tsc.2025.101915 (measurement study).
- **[S20]** Authors, Thinking & Reasoning (2025). *Divergent thinking is linked with convergent thinking; implications for models of creativity*. Thinking & Reasoning. https://doi.org/10.1080/13546783.2025.2485059 (correlational study).
- **[S21]** Authors, Frontiers in Psychology (2019). *How Does Culture Shape Creativity? A Mini-Review*. Frontiers in Psychology. https://doi.org/10.3389/fpsyg.2019.01219 (review).
- **[S22]** Barth & Stadtmann (2024). *Creativity in the West and the East: A Meta-Analysis of Cross-Cultural Differences*. Creativity Research Journal. https://doi.org/10.1080/10400419.2024.2369442 (meta-analysis).
- **[S23]** Stroebe, Nijstad & Rietzschel (2010). *Beyond productivity loss in brainstorming groups: The evolution of a question*. Advances in Experimental Social Psychology. https://doi.org/10.1016/S0065-2601(10)43004-X (review).
- **[S24]** Authors, Thinking Skills and Creativity (2024). *Mind wandering and the incubation effect: Working memory capacity and cognitive load*. Thinking Skills and Creativity. https://doi.org/10.1016/j.tsc.2024.101499 (experimental studies).
- **[S25]** Authors, Learning and Instruction (2026). *Sequential thinking prompts for creative problem solving*. Learning and Instruction. https://doi.org/10.1016/j.learninstruc.2025.102247 (intervention study).
- **[S26]** Wu et al. (2025). *Human-generative AI collaboration enhances task performance but undermines human intrinsic motivation*. Scientific Reports. https://doi.org/10.1038/s41598-025-98385-2 (four experiments).
- **[S27]** Ding & Li (2025). *Generative AI lacks the human creativity to achieve scientific discovery from scratch*. Scientific Reports. https://doi.org/10.1038/s41598-025-93794-9 (single-task model comparison).
- **[S28]** Perchtold-Stefan, Rietzschel & Baas (2025). *Generating, evaluating, endorsing, and implementing malevolent creativity*. Frontiers in Psychology. https://doi.org/10.3389/fpsyg.2025.1695259 (perspective).
- **[S29]** Wang et al. (2019). *Team Creativity/Innovation in Culturally Diverse Teams: A Meta-Analysis*. Journal article / Lingnan University record. https://scholars.ln.edu.hk/en/publications/team-creativityinnovation-in-culturally-diverse-teams-a-meta-anal/ (meta-analysis).
- **[S30]** Reddy & Shojaee (2025). *Towards Scientific Discovery with Generative AI: Progress, Opportunities, and Challenges*. AAAI 2025. https://doi.org/10.1609/aaai.v39i27.35084 (perspective).
- **[S31]** Authors, Thinking Skills and Creativity (2026). *Symbiosis or stagnation? Impact of AI on creativity in L1 Chinese writing*. Thinking Skills and Creativity. https://doi.org/10.1016/j.tsc.2025.102096 (mixed-methods experiment).
- **[S32]** Authors, Philosophy & Phenomenological Research (2024). *Integrational creativity: from combining and blending to transforming and resonating*. Inquiry. https://doi.org/10.1080/0020174X.2024.2389992 (conceptual).
- **[S33]** Benedek et al. (2013). *Assessment of Divergent Thinking by the Subjective Top-Scoring Method*. Frontiers in Psychology. https://pmc.ncbi.nlm.nih.gov/articles/PMC4001084/ (psychometrics).
- **[S34]** Rietzschel, Nijstad & Stroebe (2006). *Productivity is not enough: Interactive and nominal brainstorming groups on generation and selection*. Journal of Experimental Social Psychology. https://doi.org/10.1016/j.jesp.2005.04.005 (experiment).
- **[S35]** Hou et al. (2025). *The Double-Edged Roles of Generative AI in the Creative Process: Experiments on Design Work*. Information Systems Research. https://doi.org/10.1287/isre.2024.0937 (two design experiments).
