# THE FILMMAKING ATLAS
**A systems map of cinema — 2026 edition**  
**As of:** 2026-10-17 · **Edition:** 1.0 · **Scope:** creative, technical, economic, ethical and frontier filmmaking.

> **Thesis.** A film is not a pipeline that converts a script into pixels. It is a negotiated system of meaning, bodies, attention, time, sound, resources, permissions, data, and public encounter. The best filmmaking decision preserves creative intent while making its technical, human, legal and economic consequences visible.

**Important:** This atlas is an independently synthesized learning and decision map, not a canonical standard. Interpretive craft principles are framed as hypotheses to test; technical standards are attributed; 2026 research is explicitly provisional. Professional safety and legal advice, union contracts, and recipient delivery requirements override generic guidance.

## 1. How to use the atlas
1. **Orient** with 16 domains and nine lifecycle gates. Do not mistake phases for a one-way sequence: film work loops backward constantly.
2. **Explore** a node through its principle, practical move, predictable trap and verifiable artifact.
3. **Trace** typed relationships in `knowledge_edges.csv`; they connect decisions across departmental borders.
4. **Challenge** frontier claims through a source trail, uncertainty statement, discriminating test and adoption trigger.
5. **Choose** a learning route; read it in sequence, then make the associated artifacts on a real scene or short film.

### The seven simultaneous lenses
- **Art:** What should this moment make a viewer infer or feel?
- **Craft:** What form, technique and rehearsal will create that effect?
- **Systems:** Which upstream constraints and downstream handoffs are affected?
- **Evidence:** How do we test the claim against real footage, audiences or outputs?
- **Care:** Whose consent, safety, labor and representation is implicated?
- **Economics:** What is the opportunity cost, failure cost, and option value?
- **Future:** Is this stable practice, an adopted standard, a hypothesis or speculation?

### Epistemic key
- **Core craft:** A maintained analytical synthesis of well-established practice; not empirical proof that one aesthetic theory is universal.
- **Standard:** An official specification or industry source establishes published vocabulary or requirements; verify latest version and applicability per job.
- **Observed signal:** A dated report shows a change in one environment; do not generalize automatically.
- **Research frontier:** An early study or prototype may indicate promise; extrapolation and broad adoption remain unproven.
- **Editorial hypothesis:** An atlas recommendation is an explicit, testable practice suggestion rather than a universal law.

## 2. The film lifecycle: nine gates and feedback loops
### 1. Discover
**Focus:** Audience, premise, research, rights.  
**Evidence:** Logline • thematic tension • initial rights screen.  
**Gate:** A film worth developing and a plausible ethical basis.

### 2. Develop
**Focus:** Story iterations, financing logic, talent strategy.  
**Evidence:** Script/outline • director statement • finance scenarios.  
**Gate:** Narrative, rights and budget assumptions survive challenge.

### 3. Previsualize
**Focus:** Design, tests, storyboard, sound, VP decisions.  
**Evidence:** Visual/sound grammar • method tests • plan A/B.  
**Gate:** Creative intent can be executed under constraints.

### 4. Prepare
**Focus:** Breakdown, schedule, permissions, technical specs.  
**Evidence:** Production book • safety plans • data/color specs.  
**Gate:** Crew, assets, money and safeguards are ready.

### 5. Capture / create
**Focus:** Perform, photograph, record, animate, simulate.  
**Evidence:** Dailies • metadata • sound reports • media checksums.  
**Gate:** Footage/performance is usable, traceable, and safe.

### 6. Assemble
**Focus:** Edit, VFX turnover, sound editorial.  
**Evidence:** Versions • selects • scene structure • change log.  
**Gate:** Narrative and performance work at full-film scale.

### 7. Finish
**Focus:** Grade, mix, VFX finals, accessibility, QC.  
**Evidence:** Locked master • stems • multi-format trims.  
**Gate:** Intent survives technical and audience test.

### 8. Release
**Focus:** Sales, festivals, cinema, streaming, engagement.  
**Evidence:** Rights grid • package approvals • campaign.  
**Gate:** Film can reach its intended people lawfully and accurately.

### 9. Learn / preserve
**Focus:** Metrics, archive, talent and rights stewardship.  
**Evidence:** Retrospective • preserved masters • metadata.  
**Gate:** Discoveries and cultural record remain available.

**Cross-cutting loops:** script ↔ budget; actors ↔ blocking ↔ lens; production design ↔ light ↔ color; footage ↔ edit ↔ pickup; VFX ↔ locked timing ↔ grade; marketing ↔ audience promise; consent ↔ reuse over time. Every loop needs a named decision owner and a versioned artifact.

## 3. The full knowledge atlas
### Story & meaning · 9 nodes
*The why of the film.*
<a id="k001"></a>
#### K001 — Premise and thematic question
**Stage:** Develop · **Epistemic stance:** interpretive craft practice.
**Principle:** The premise is a pressure vessel; theme is a question dramatized rather than a slogan.
**Do:** Express an observable conflict and a falsifiable thematic tension in one sentence.
**Failure mode:** Confusing an issue with a dramatic situation.
**Proof of work:** Logline + thematic question.

<a id="k002"></a>
#### K002 — Character desire and need
**Stage:** Develop · **Epistemic stance:** interpretive craft practice.
**Principle:** Desire drives visible action; need names an often-unrecognized change in orientation.
**Do:** Define objective, obstacle, strategy, stakes and self-deception for each central role.
**Failure mode:** A biography with no playable behavior.
**Proof of work:** Character contradiction sheet.

<a id="k003"></a>
#### K003 — Causality and plot
**Stage:** Write · **Epistemic stance:** interpretive craft practice.
**Principle:** A consequential choice should alter the next field of possible choices.
**Do:** Audit scenes for a choice, cost, new information and changed conditions.
**Failure mode:** Events linked only by coincidence.
**Proof of work:** Beat-to-consequence map.

<a id="k004"></a>
#### K004 — Scene design
**Stage:** Write · **Epistemic stance:** interpretive craft practice.
**Principle:** A scene is a change of state under pressure, not merely a container for dialogue.
**Do:** Specify entrance state, tactical turn, and exit state.
**Failure mode:** Scenes that restate known information.
**Proof of work:** Scene intention cards.

<a id="k005"></a>
#### K005 — Structure and rhythm
**Stage:** Write · **Epistemic stance:** interpretive craft practice.
**Principle:** Acts, sequences and alternative structures are hypotheses about attention, not compulsory formulas.
**Do:** Chart escalation, release, reversal and duration; test with readers.
**Failure mode:** Formula outranking the specific story.
**Proof of work:** Sequence pressure chart.

<a id="k006"></a>
#### K006 — Dialogue and subtext
**Stage:** Write · **Epistemic stance:** interpretive craft practice.
**Principle:** What is withheld, performed or evaded can matter more than literal speech.
**Do:** Write conflicting objectives beneath spoken lines and read aloud with actors.
**Failure mode:** Exposition masquerading as conversation.
**Proof of work:** Dialogue/subtext pass.

<a id="k007"></a>
#### K007 — Genre and promise
**Stage:** Develop · **Epistemic stance:** interpretive craft practice.
**Principle:** Genre establishes an audience contract while leaving room for subversion.
**Do:** Identify expectations to satisfy, transform and deliberately refuse.
**Failure mode:** Borrowing surface icons without emotional logic.
**Proof of work:** Genre contract memo.

<a id="k008"></a>
#### K008 — Point of view and empathy
**Stage:** Develop · **Epistemic stance:** interpretive craft practice.
**Principle:** Camera, access to information and sound decide whose experience becomes intelligible.
**Do:** Map who knows what when; include ethical effects of identification.
**Failure mode:** Mistaking proximity for endorsement.
**Proof of work:** Knowledge/POV matrix.

<a id="k009"></a>
#### K009 — Research and lived specificity
**Stage:** Develop · **Epistemic stance:** interpretive craft practice.
**Principle:** Specific detail earns credibility when it changes behavior and causality.
**Do:** Interview, verify, pay experts and test potentially stereotyped assumptions.
**Failure mode:** Extractive research treated as atmosphere.
**Proof of work:** Research evidence log.

### Direction & performance · 8 nodes
*Human behavior on screen.*
<a id="k010"></a>
#### K010 — Directorial intention
**Stage:** Prep · **Epistemic stance:** interpretive craft practice.
**Principle:** Direction turns a story's abstract intent into observable behavioral and audiovisual choices.
**Do:** Define what the audience should perceive, infer and feel in each sequence.
**Failure mode:** Aesthetic references without dramatic purpose.
**Proof of work:** Directing intention bible.

<a id="k011"></a>
#### K011 — Casting and chemistry
**Stage:** Prep · **Epistemic stance:** interpretive craft practice.
**Principle:** Casting is a hypothesis about relationships, not just individual talent.
**Do:** Test listening, playability, power dynamics and accessibility of process.
**Failure mode:** Choosing only resemblance to an imagined face.
**Proof of work:** Casting rationale.

<a id="k012"></a>
#### K012 — Rehearsal design
**Stage:** Prep · **Epistemic stance:** interpretive craft practice.
**Principle:** Rehearsal is an experiment in objectives, actions and discoveries, not a demand for fixed readings.
**Do:** Explore alternatives, track discoveries and protect actors' agency.
**Failure mode:** Rehearsal that exhausts spontaneity.
**Proof of work:** Rehearsal discoveries ledger.

<a id="k013"></a>
#### K013 — Blocking and power
**Stage:** Shoot · **Epistemic stance:** interpretive craft practice.
**Principle:** Where bodies move changes status, attention, intimacy and the meaning of space.
**Do:** Block for intention first, then camera logistics and continuity.
**Failure mode:** Pretty movement without motivation.
**Proof of work:** Floor plan + blocking notes.

<a id="k014"></a>
#### K014 — Directing actors
**Stage:** Shoot · **Epistemic stance:** interpretive craft practice.
**Principle:** Playable verbs and circumstances usually outperform emotion labels.
**Do:** Offer action-oriented adjustments, protect trust and create room for surprise.
**Failure mode:** Asking actors to produce an emotion on command.
**Proof of work:** Performance notes per take.

<a id="k015"></a>
#### K015 — Coverage as interpretation
**Stage:** Prep · **Epistemic stance:** interpretive craft practice.
**Principle:** Coverage is a set of future editorial possibilities with a cost in time and performance energy.
**Do:** Design a primary viewpoint and only the alternatives needed for uncertainty.
**Failure mode:** Indiscriminate master-medium-close-up accumulation.
**Proof of work:** Motivated coverage plan.

<a id="k016"></a>
#### K016 — Tone across departments
**Stage:** Prep · **Epistemic stance:** interpretive craft practice.
**Principle:** Tone emerges from controlled alignment of acting, lenses, sound, design and editing.
**Do:** Agree on an emotional grammar and exceptions with department heads.
**Failure mode:** Moodboard agreement masking incompatible assumptions.
**Proof of work:** Tone grammar sheet.

<a id="k017"></a>
#### K017 — Performance continuity
**Stage:** Shoot · **Epistemic stance:** interpretive craft practice.
**Principle:** Emotional continuity concerns the character's changing inner state, not just props.
**Do:** Track performance turns and which take contains the defining discovery.
**Failure mode:** Matching hand position while losing arc.
**Proof of work:** Script supervisor emotional ledger.

### Visual language · 9 nodes
*Point of view in space.*
<a id="k018"></a>
#### K018 — Composition and attention
**Stage:** Prep · **Epistemic stance:** interpretive craft practice.
**Principle:** Frames distribute power and direct the eye through scale, contrast, movement and negative space.
**Do:** Choose where viewers look first and what they notice later.
**Failure mode:** Symmetry mistaken for meaning.
**Proof of work:** Frame-intent board.

<a id="k019"></a>
#### K019 — Shot scale and intimacy
**Stage:** Prep · **Epistemic stance:** interpretive craft practice.
**Principle:** Distance affects access to faces, bodies, social space and context.
**Do:** Make a shot-size progression reflect a relationship change.
**Failure mode:** Arbitrary close-ups that deflate emphasis.
**Proof of work:** Shot-size ladder.
**Related sources:** [S03](#s03).

<a id="k020"></a>
#### K020 — Lens and perspective
**Stage:** Prep · **Epistemic stance:** interpretive craft practice.
**Principle:** Perspective is governed by camera position; focal length changes angle of view from that position.
**Do:** Test distance, field of view and spatial compression separately.
**Failure mode:** Attributing perspective change to focal length alone.
**Proof of work:** Lens-distance test sheet.
**Related sources:** [S03](#s03).

<a id="k021"></a>
#### K021 — Camera movement
**Stage:** Prep · **Epistemic stance:** interpretive craft practice.
**Principle:** A move can reveal information, imitate attention or embody a shift in power.
**Do:** Define why each move starts and where it settles.
**Failure mode:** Movement deployed as production value only.
**Proof of work:** Move motivation list.
**Related sources:** [S03](#s03).

<a id="k022"></a>
#### K022 — Screen direction and geography
**Stage:** Shoot · **Epistemic stance:** interpretive craft practice.
**Principle:** Viewers construct a mental map from eyelines, axes, entrances and spatial cues.
**Do:** Design establish/reorient exceptions to the 180-degree convention.
**Failure mode:** Rigidly obeying rules without assessing clarity.
**Proof of work:** Spatial continuity chart.

<a id="k023"></a>
#### K023 — Aspect ratio and format
**Stage:** Prep · **Epistemic stance:** interpretive craft practice.
**Principle:** Frame shape is both expressive constraint and downstream delivery choice.
**Do:** Compare composition and distribution requirements before lock.
**Failure mode:** Cropping late without protecting key action.
**Proof of work:** Format decision memo.

<a id="k024"></a>
#### K024 — Visual motifs
**Stage:** Develop · **Epistemic stance:** interpretive craft practice.
**Principle:** A motif becomes meaning-bearing by evolving with context, not by repeating unchanged.
**Do:** Track a visual element's changed associations through the film.
**Failure mode:** Decorative repetition without development.
**Proof of work:** Motif evolution map.

<a id="k025"></a>
#### K025 — Subjective and objective camera
**Stage:** Prep · **Epistemic stance:** interpretive craft practice.
**Principle:** The camera may observe, participate, judge or inhabit perception.
**Do:** Name its ethical and dramatic relationship to each character.
**Failure mode:** Inconsistent viewpoint mistaken for freedom.
**Proof of work:** Camera ontology statement.

<a id="k026"></a>
#### K026 — Visual literacy and references
**Stage:** Prep · **Epistemic stance:** interpretive craft practice.
**Principle:** References communicate better when annotated with mechanism, not prestige.
**Do:** Describe framing, contrast, movement and dramaturgical effect independently.
**Failure mode:** Copying famous imagery without context.
**Proof of work:** Annotated visual reference matrix.

### Cinematography & light · 9 nodes
*Photographic choices.*
<a id="k027"></a>
#### K027 — Exposure and scene latitude
**Stage:** Prep · **Epistemic stance:** interpretive craft practice.
**Principle:** Exposure trades highlight retention, shadow detail, noise and intended texture.
**Do:** Test real faces, materials and practical lights in the planned color pipeline.
**Failure mode:** Treating monitor appearance as source truth.
**Proof of work:** Exposure tests and target.

<a id="k028"></a>
#### K028 — Lighting motivation
**Stage:** Prep · **Epistemic stance:** interpretive craft practice.
**Principle:** Direction, size, falloff and color of light shape texture and perceived causality.
**Do:** Design a motivated base and articulate when stylization overrides realism.
**Failure mode:** Multiplying fixtures without a readable lighting idea.
**Proof of work:** Lighting concept plot.
**Related sources:** [S20](#s20).

<a id="k029"></a>
#### K029 — Camera sensor and format
**Stage:** Prep · **Epistemic stance:** interpretive craft practice.
**Principle:** Sensor, readout, dynamic range and codecs constrain motion and finishing, not just resolution.
**Do:** Test rolling shutter, low light, high contrast and skin before selection.
**Failure mode:** Buying pixels instead of solving a scene.
**Proof of work:** Camera comparison report.

<a id="k030"></a>
#### K030 — Depth of field
**Stage:** Prep · **Epistemic stance:** interpretive craft practice.
**Principle:** Focus is an attention policy with operational cost.
**Do:** Test subject distance, aperture, format and camera movement together.
**Failure mode:** Shallow focus that makes performance unusable.
**Proof of work:** Focus strategy.

<a id="k031"></a>
#### K031 — Color contrast and palette
**Stage:** Prep · **Epistemic stance:** interpretive craft practice.
**Principle:** Warm/cool, hue separation and luminance structure guide attention across scenes.
**Do:** Build palette from story beats, locations, wardrobe and monitoring.
**Failure mode:** Palette chosen independently of skin and material.
**Proof of work:** Palette arc.

<a id="k032"></a>
#### K032 — Shutter and motion rendition
**Stage:** Shoot · **Epistemic stance:** interpretive craft practice.
**Principle:** Exposure time relative to frame interval changes motion blur; readout can deform motion.
**Do:** Test action, flicker and frame rates with practical fixtures.
**Failure mode:** Assuming 180 degrees solves LED or mains-frequency flicker.
**Proof of work:** Motion/flicker test.

<a id="k033"></a>
#### K033 — Camera movement systems
**Stage:** Shoot · **Epistemic stance:** interpretive craft practice.
**Principle:** Dolly, handheld, stabilized and remote rigs transmit different bodily meanings and risks.
**Do:** Match physical apparatus to emotional motive, time and safe rigging.
**Failure mode:** Gear choice driving staging.
**Proof of work:** Rig and movement risk plan.

<a id="k034"></a>
#### K034 — Data and image integrity
**Stage:** Shoot · **Epistemic stance:** interpretive craft practice.
**Principle:** Camera originals are irreplaceable evidence for picture and sound sync.
**Do:** Verify metadata, checksums, camera reports, card handling and restore.
**Failure mode:** A copy mistaken for a verified backup.
**Proof of work:** Verified media handoff.

<a id="k035"></a>
#### K035 — Monitoring and look transforms
**Stage:** Shoot · **Epistemic stance:** interpretive craft practice.
**Principle:** Creative monitoring is not the same as irreversible capture or mastering.
**Do:** Agree on show LUT, display calibration, viewing conditions and transform versions.
**Failure mode:** Baking a look accidentally or double-transforming.
**Proof of work:** Show look + monitor log.
**Related sources:** [S04](#s04), [S25](#s25).

### World & production design · 7 nodes
*Constructed reality.*
<a id="k036"></a>
#### K036 — World rules and geography
**Stage:** Develop · **Epistemic stance:** interpretive craft practice.
**Principle:** Every world needs intelligible material, social and spatial rules, whether realistic or fantastic.
**Do:** Define constraints that affect action and camera possibilities.
**Failure mode:** Spectacle with no coherent lived system.
**Proof of work:** World rules bible.

<a id="k037"></a>
#### K037 — Production design narrative
**Stage:** Prep · **Epistemic stance:** interpretive craft practice.
**Principle:** Sets tell stories through use, wear, absence and change.
**Do:** Build biography into materials and let action leave consequences.
**Failure mode:** Decorative objects without character history.
**Proof of work:** Design research boards.

<a id="k038"></a>
#### K038 — Locations and control
**Stage:** Prep · **Epistemic stance:** interpretive craft practice.
**Principle:** The right location balances meaning, access, weather, sound, power and legal use.
**Do:** Score location for visual value, restrictions and sound contamination.
**Failure mode:** A stunning place that cannot be filmed safely.
**Proof of work:** Scouting feasibility matrix.

<a id="k039"></a>
#### K039 — Costume and character arc
**Stage:** Prep · **Epistemic stance:** interpretive craft practice.
**Principle:** Clothes carry status, habit, environment and change over time.
**Do:** Map wardrobe states against story chronology and shooting schedule.
**Failure mode:** Costume choices detached from blocking and grade.
**Proof of work:** Wardrobe continuity bible.

<a id="k040"></a>
#### K040 — Makeup, hair and prosthetics
**Stage:** Prep · **Epistemic stance:** interpretive craft practice.
**Principle:** Skin, hair and prosthetics must survive close photography, continuity and physical comfort.
**Do:** Conduct camera tests and schedule application/removal safely.
**Failure mode:** Designs that fail under the final lighting.
**Proof of work:** Look and safety tests.

<a id="k041"></a>
#### K041 — Props and practical effects
**Stage:** Prep · **Epistemic stance:** interpretive craft practice.
**Principle:** Props are interfaces actors use; reliability, duplication and legality matter.
**Do:** Specify hero, stunt, continuity and breakaway versions where necessary.
**Failure mode:** One irreplaceable prop serving incompatible takes.
**Proof of work:** Prop breakdown.

<a id="k042"></a>
#### K042 — Architecture of production scale
**Stage:** Prep · **Epistemic stance:** interpretive craft practice.
**Principle:** Scale can come from selective detail, offscreen space and controlled reveal.
**Do:** Allocate design resources to story-bearing surfaces and interactions.
**Failure mode:** Wide spectacle consuming funds without screen value.
**Proof of work:** Production value allocation.

### Sound & music · 9 nodes
*Emotional acoustics.*
<a id="k043"></a>
#### K043 — Sound point of audition
**Stage:** Develop · **Epistemic stance:** interpretive craft practice.
**Principle:** Sound can occupy objective space or align with a character's subjective perception.
**Do:** Decide whose hearing governs each sequence and when to break it.
**Failure mode:** Sound serving only as image illustration.
**Proof of work:** Sound POV map.

<a id="k044"></a>
#### K044 — Production dialogue
**Stage:** Shoot · **Epistemic stance:** interpretive craft practice.
**Principle:** Clean intelligible dialogue buys flexibility in performance and cutting.
**Do:** Scout noise, place microphones, monitor, record room tone and log problems.
**Failure mode:** Assuming noise reduction will rescue everything.
**Proof of work:** Sound report and wild lines.

<a id="k045"></a>
#### K045 — Ambience and spatial worlds
**Stage:** Post · **Epistemic stance:** interpretive craft practice.
**Principle:** Background beds establish geography, continuity, time and absence.
**Do:** Build layered ambience that evolves with story beats.
**Failure mode:** A generic ambience loop flattening location identity.
**Proof of work:** Environment sound palette.

<a id="k046"></a>
#### K046 — Foley and material storytelling
**Stage:** Post · **Epistemic stance:** interpretive craft practice.
**Principle:** Tactile micro-sounds alter the perceived weight, intimacy and authenticity of actions.
**Do:** Prioritize narrative-significant contacts and material specificity.
**Failure mode:** Overproducing incidental noise.
**Proof of work:** Foley cue plan.

<a id="k047"></a>
#### K047 — Dialogue editing and ADR
**Stage:** Post · **Epistemic stance:** interpretive craft practice.
**Principle:** Editing should preserve intention and timbre while fixing continuity and intelligibility.
**Do:** Use handles, alternate takes, room matching and actor-involved ADR when needed.
**Failure mode:** Technically clean dialogue losing performance humanity.
**Proof of work:** Dialogue premix.
**Related sources:** [S21](#s21).

<a id="k048"></a>
#### K048 — Music as counterpoint
**Stage:** Develop · **Epistemic stance:** interpretive craft practice.
**Principle:** Score can align with or resist an image; both choices influence interpretation.
**Do:** Spot moments where music informs, misdirects or should be absent.
**Failure mode:** Temp tracks dictating final composition.
**Proof of work:** Music spotting notes.

<a id="k049"></a>
#### K049 — Dynamic range and silence
**Stage:** Post · **Epistemic stance:** interpretive craft practice.
**Principle:** Silence and loudness are relational: each works through contrast and playback context.
**Do:** Audition theatrical and near-field versions on calibrated systems.
**Failure mode:** Loudness normalization mistaken for creative mixing.
**Proof of work:** Versioned mix references.
**Related sources:** [S10](#s10).

<a id="k050"></a>
#### K050 — Spatial / immersive sound
**Stage:** Post · **Epistemic stance:** interpretive craft practice.
**Principle:** Channels and objects create positional expectations for sound playback.
**Do:** Test translations between theatrical immersive, stereo and mobile playback.
**Failure mode:** Assuming object-based sound guarantees clarity everywhere.
**Proof of work:** Downmix audition report.

<a id="k051"></a>
#### K051 — Sound editorial to mix
**Stage:** Post · **Epistemic stance:** interpretive craft practice.
**Principle:** Routing, naming and change lists make the creative soundtrack revisable.
**Do:** Standardize session handoff, conform and stem ownership.
**Failure mode:** Premixes without traceability of revisions.
**Proof of work:** Dialogue/music/effects stem plan.

### Editing & time · 8 nodes
*Meaning through juxtaposition.*
<a id="k052"></a>
#### K052 — Editorial hypothesis
**Stage:** Post · **Epistemic stance:** interpretive craft practice.
**Principle:** Every cut asserts a relationship in time, space, cause or emotion.
**Do:** State what a transition should let the viewer infer.
**Failure mode:** Cutting only because a take ends.
**Proof of work:** Cut intention notes.

<a id="k053"></a>
#### K053 — Performance-led selects
**Stage:** Post · **Epistemic stance:** interpretive craft practice.
**Principle:** The truthful or surprising behavior may outweigh technical perfection.
**Do:** Mark listening, reaction and relational beats, not only lines delivered.
**Failure mode:** Choosing prettiest coverage over emotional action.
**Proof of work:** Selects with intention metadata.

<a id="k054"></a>
#### K054 — Temporal architecture
**Stage:** Post · **Epistemic stance:** interpretive craft practice.
**Principle:** Duration creates felt rhythm; repetition, elision and anticipation shape its meaning.
**Do:** Experiment with scene duration at story level, not just shot pace.
**Failure mode:** Mistaking more cuts for energy.
**Proof of work:** Rhythm maps.

<a id="k055"></a>
#### K055 — Continuity and discontinuity
**Stage:** Post · **Epistemic stance:** interpretive craft practice.
**Principle:** Continuity protects cognition; discontinuity can produce valuable friction.
**Do:** Choose where disorientation is meaningful and recoverable.
**Failure mode:** Accidental ambiguity in a critical fact.
**Proof of work:** Continuity exceptions list.

<a id="k056"></a>
#### K056 — Transitions and montage
**Stage:** Post · **Epistemic stance:** interpretive craft practice.
**Principle:** Adjacent images can create concepts neither contains alone.
**Do:** Test graphic, sonic, conceptual and causal bridges with target viewers.
**Failure mode:** Clever cuts without downstream meaning.
**Proof of work:** Montage grammar.

<a id="k057"></a>
#### K057 — Information release
**Stage:** Post · **Epistemic stance:** interpretive craft practice.
**Principle:** Suspense and surprise depend on timing of audience knowledge versus character knowledge.
**Do:** Chart revelations, false beliefs and reversals.
**Failure mode:** Reveals that rely on withheld basics.
**Proof of work:** Audience knowledge timeline.

<a id="k058"></a>
#### K058 — Picture lock and change control
**Stage:** Post · **Epistemic stance:** interpretive craft practice.
**Principle:** Lock is a contract between editorial, sound, color, VFX and delivery.
**Do:** Define lock scope, change request owners and reconform tests.
**Failure mode:** Silent version drift between departments.
**Proof of work:** Signed picture-lock manifest.

<a id="k059"></a>
#### K059 — Test screenings
**Stage:** Post · **Epistemic stance:** interpretive craft practice.
**Principle:** Viewers can report confusion or boredom but rarely prescribe the only solution.
**Do:** Ask open behavioral questions, segment audiences and observe actual reactions.
**Failure mode:** Treating preferences as representative truth.
**Proof of work:** Test findings with confidence notes.

### Animation, VFX & virtual · 9 nodes
*Designed and simulated images.*
<a id="k060"></a>
#### K060 — VFX as a story choice
**Stage:** Prep · **Epistemic stance:** interpretive craft practice.
**Principle:** Effects should solve storytelling needs while retaining actor and camera authorship.
**Do:** Decide practical, digital or hybrid methods by shot risk and perceptual value.
**Failure mode:** VFX as a late rescue budget.
**Proof of work:** VFX method breakdown.

<a id="k061"></a>
#### K061 — Previsualization and techvis
**Stage:** Prep · **Epistemic stance:** interpretive craft practice.
**Principle:** Previs tests dramatic staging; techvis verifies camera, set and rig feasibility.
**Do:** Separate communicative mockup from engineering measurement.
**Failure mode:** Treating approximate previs as physical truth.
**Proof of work:** Previs/techvis assumptions log.

<a id="k062"></a>
#### K062 — Plate capture and lens metadata
**Stage:** Shoot · **Epistemic stance:** interpretive craft practice.
**Principle:** CG integration relies on physically compatible footage and metadata.
**Do:** Capture lens grids, HDRI, witness cameras and tracking reference as needed.
**Failure mode:** Unrecorded lens distortion discovered in post.
**Proof of work:** VFX shoot data package.

<a id="k063"></a>
#### K063 — Compositing and integration
**Stage:** Post · **Epistemic stance:** interpretive craft practice.
**Principle:** Convincing integration depends on light, depth, grain, motion, occlusion and lens behavior.
**Do:** Match scene-referred values before final viewing transforms.
**Failure mode:** Pixel matching in mismatched color spaces.
**Proof of work:** Shot integration review.

<a id="k064"></a>
#### K064 — Animation principles
**Stage:** Produce · **Epistemic stance:** interpretive craft practice.
**Principle:** Readable pose, timing, arcs and anticipation translate intent through movement.
**Do:** Use reference without assuming realism is always the target.
**Failure mode:** Technically smooth but unreadable action.
**Proof of work:** Animation blocking pass.
**Related sources:** [S21](#s21).

<a id="k065"></a>
#### K065 — Character and creature systems
**Stage:** Produce · **Epistemic stance:** interpretive craft practice.
**Principle:** Rigging and performance design determine what can be expressed.
**Do:** Test facial range, contact and actor interaction early.
**Failure mode:** Asset detail outrunning animation usability.
**Proof of work:** Rig expression tests.

<a id="k066"></a>
#### K066 — In-camera virtual production
**Stage:** Shoot · **Epistemic stance:** interpretive craft practice.
**Principle:** LED volumes couple live camera tracking, render, color, sync and practical light.
**Do:** Test moiré, frustum, parallax, latency, genlock and display-camera interaction.
**Failure mode:** Believing LED panels replace location preparation.
**Proof of work:** Volume acceptance test.
**Related sources:** [S20](#s20), [S25](#s25).

<a id="k067"></a>
#### K067 — Real-time engines and simulation
**Stage:** Prep · **Epistemic stance:** interpretive craft practice.
**Principle:** Interactive previews accelerate iteration but introduce pipeline/version complexity.
**Do:** Freeze asset versions for camera decisions and cache reproducible outputs.
**Failure mode:** Preview mismatch with final render.
**Proof of work:** Engine asset manifest.

<a id="k068"></a>
#### K068 — Volumetric and neural reconstruction
**Stage:** Frontier · **Epistemic stance:** emerging research / adoption.
**Principle:** NeRFs and Gaussian splats enable view synthesis; relighting, editability and artifacts remain task-specific.
**Do:** Benchmark camera motion, occlusion, lighting change and rights of captured subjects.
**Failure mode:** Demo quality generalized to every production.
**Proof of work:** Controlled spatial reconstruction test.
**Related sources:** [S18](#s18).

### Producing & planning · 8 nodes
*Enable the impossible.*
<a id="k069"></a>
#### K069 — Creative producing
**Stage:** Develop · **Epistemic stance:** interpretive craft practice.
**Principle:** Producing is design of conditions under which a film can exist without losing its purpose.
**Do:** Write creative priorities and non-negotiables before budgeting.
**Failure mode:** Solving schedule by erasing the premise.
**Proof of work:** Creative constraints charter.

<a id="k070"></a>
#### K070 — Packaging and greenlight
**Stage:** Develop · **Epistemic stance:** interpretive craft practice.
**Principle:** A package aligns project, market, rights, talent, finance and schedule assumptions.
**Do:** Stress-test dependencies and create a decision log for greenlight.
**Failure mode:** Prestige attachments as substitute for feasibility.
**Proof of work:** Greenlight memo.

<a id="k071"></a>
#### K071 — Script breakdown
**Stage:** Prep · **Epistemic stance:** interpretive craft practice.
**Principle:** Scenes imply people, places, time, equipment, rights and hazards.
**Do:** Tag each requirement, exception and special risk before schedule build.
**Failure mode:** Underbudgeted invisible requirements.
**Proof of work:** Departmental breakdown.

<a id="k072"></a>
#### K072 — Scheduling and critical path
**Stage:** Prep · **Epistemic stance:** interpretive craft practice.
**Principle:** Sequence shoots by resources, location, cast and constraints while protecting performance conditions.
**Do:** Track critical path, contingency and turnaround rules.
**Failure mode:** Optimizing daily pages at expense of cumulative fatigue.
**Proof of work:** Stripboard + critical path.

<a id="k073"></a>
#### K073 — Budget and cost reports
**Stage:** Prep · **Epistemic stance:** interpretive craft practice.
**Principle:** Budget is a forecast, not the truth; cost reporting updates uncertainty.
**Do:** Separate committed, actual and estimate-to-complete; show risk reserve.
**Failure mode:** Mistaking underreported spend for savings.
**Proof of work:** Cost-to-complete report.

<a id="k074"></a>
#### K074 — Communication architecture
**Stage:** Prep · **Epistemic stance:** interpretive craft practice.
**Principle:** Information should reach the right decision-maker before it becomes irreversible.
**Do:** Define owners, version authority, channels and approval clocks.
**Failure mode:** Meetings where nobody can decide.
**Proof of work:** RACI + decision-rights map.
**Related sources:** [S01](#s01).

<a id="k075"></a>
#### K075 — Contingency and resilience
**Stage:** Prep · **Epistemic stance:** interpretive craft practice.
**Principle:** Reserves should cover plausible operational disruptions, not creative indecision without limit.
**Do:** Rehearse bad weather, absence, data loss and location cancellation.
**Failure mode:** Plans with no fallbacks.
**Proof of work:** Contingency triggers book.

<a id="k076"></a>
#### K076 — Creative change management
**Stage:** Produce · **Epistemic stance:** interpretive craft practice.
**Principle:** A change has ripple costs across art, performance, schedule, VFX and delivery.
**Do:** Attach impact and approval to proposed story or technical changes.
**Failure mode:** Departments using incompatible current versions.
**Proof of work:** Change impact ledger.

### On-set execution · 8 nodes
*Work performed safely.*
<a id="k077"></a>
#### K077 — Daily call and readiness
**Stage:** Shoot · **Epistemic stance:** interpretive craft practice.
**Principle:** An executable day begins with unambiguous people, equipment, transport, timing and safety information.
**Do:** Verify calls, access, rest, weather and emergency plans in advance.
**Failure mode:** Information arriving after departments commit.
**Proof of work:** Call sheet + readiness checklist.

<a id="k078"></a>
#### K078 — Set command and decision rights
**Stage:** Shoot · **Epistemic stance:** interpretive craft practice.
**Principle:** Directors, ADs, safety leads and department heads share an operational interface.
**Do:** Make stop-work authority explicit and independent of creative rank.
**Failure mode:** Ambiguity around who may stop unsafe work.
**Proof of work:** Chain-of-command card.

<a id="k079"></a>
#### K079 — Continuity supervision
**Stage:** Shoot · **Epistemic stance:** interpretive craft practice.
**Principle:** Continuity joins dramatic state, props, wardrobe, camera and time.
**Do:** Record takes with objective and emotional notes.
**Failure mode:** Assuming a continuity photo captures all context.
**Proof of work:** Lined script + continuity records.

<a id="k080"></a>
#### K080 — Coverage under scarcity
**Stage:** Shoot · **Epistemic stance:** interpretive craft practice.
**Principle:** Scarcity makes the order of shots a creative decision.
**Do:** Shoot irreplaceable performances or complex stunts with informed priority.
**Failure mode:** Leaving essential eyelines until exhaustion.
**Proof of work:** Priority coverage matrix.

<a id="k081"></a>
#### K081 — Weather, light and environmental control
**Stage:** Shoot · **Epistemic stance:** interpretive craft practice.
**Principle:** Conditions evolve during a day and create continuity, safety and cost risks.
**Do:** Monitor forecasts and define an alternative scene sequence.
**Failure mode:** Hoping conditions remain constant.
**Proof of work:** Day risk board.

<a id="k082"></a>
#### K082 — Stunts and practical hazard controls
**Stage:** Shoot · **Epistemic stance:** interpretive craft practice.
**Principle:** Choreography, rigging, vehicles, water, pyrotechnics and heights require specialized competent supervision.
**Do:** Require risk assessment, rehearsals, permits and stop conditions.
**Failure mode:** Normalizing near misses for a take.
**Proof of work:** Signed safety method statement.

<a id="k083"></a>
#### K083 — Unit data workflow
**Stage:** Shoot · **Epistemic stance:** interpretive craft practice.
**Principle:** On-set data practices protect both evidence and the postproduction schedule.
**Do:** Make verified copies, reconcile reports, encrypt transport and test restoration.
**Failure mode:** Leaving cards uncleared because no recovery drill exists.
**Proof of work:** Media verification receipt.

<a id="k084"></a>
#### K084 — Wrap and post handoff
**Stage:** Shoot · **Epistemic stance:** interpretive craft practice.
**Principle:** A shoot day is complete when creative, technical and incident records reach their next owners.
**Do:** Reconcile slates, sound, notes, VFX markers and media inventories.
**Failure mode:** Retrospective fixes based on memory.
**Proof of work:** Daily end-of-day handoff.

### Post & image pipeline · 10 nodes
*Preserve editorial intent.*
<a id="k085"></a>
#### K085 — Media identity and metadata
**Stage:** Post · **Epistemic stance:** interpretive craft practice.
**Principle:** Unique identity is the bridge between raw footage, proxies, cut references, VFX and archive.
**Do:** Preserve reel, source timecode, filename and stable asset identifiers.
**Failure mode:** Renaming files as if identity were cosmetic.
**Proof of work:** Canonical asset registry.
**Related sources:** [S02](#s02), [S22](#s22).

<a id="k086"></a>
#### K086 — Checksums, backup and restore
**Stage:** Shoot · **Epistemic stance:** interpretive craft practice.
**Principle:** Multiple copies only become trustworthy through verification and tested recovery.
**Do:** Use checksums, independent storage and restores matched to impact.
**Failure mode:** Confusing 3-2-1 slogan with tested disaster recovery.
**Proof of work:** Verified backup/restore log.

<a id="k087"></a>
#### K087 — Timecode and synchronization
**Stage:** Shoot · **Epistemic stance:** interpretive craft practice.
**Principle:** Picture, external audio and multicamera must share understandable time conventions.
**Do:** Test jam sync, drift and frame-rate labels; retain sync reference.
**Failure mode:** Treating nominal 24 and 23.976 as interchangeable.
**Proof of work:** Sync test and reports.

<a id="k088"></a>
#### K088 — Color management (ACES)
**Stage:** Post · **Epistemic stance:** interpretive craft practice.
**Principle:** Scene-referred transforms and standardized handoffs help preserve image intent across tools and displays.
**Do:** Record camera input, working and output transforms plus show look versions.
**Failure mode:** Double transforms, wrong display or mismatched versions.
**Proof of work:** Color pipeline specification.
**Related sources:** [S04](#s04), [S05](#s05).

<a id="k089"></a>
#### K089 — Editorial interchange (OTIO)
**Stage:** Post · **Epistemic stance:** interpretive craft practice.
**Principle:** OTIO describes timeline structure and references media but does not contain the media itself.
**Do:** Test round trips for cuts, transitions, retimes and custom metadata.
**Failure mode:** Assuming interchange guarantees perfect effect fidelity.
**Proof of work:** Editorial interchange round-trip report.
**Related sources:** [S06](#s06).

<a id="k090"></a>
#### K090 — VFX plates and color handoff
**Stage:** Post · **Epistemic stance:** interpretive craft practice.
**Principle:** Rendered pixels, camera originals and artist views must share coordinate and color conventions.
**Do:** Freeze color, resolution, overscan, grain and naming requirements per show.
**Failure mode:** Burned display look hidden inside plate.
**Proof of work:** VFX delivery specification.

<a id="k091"></a>
#### K091 — Conform, grade and finishing
**Stage:** Post · **Epistemic stance:** interpretive craft practice.
**Principle:** A conform must reproduce creative editorial decisions at mastering quality.
**Do:** Compare offline reference to online frame by frame at transitions and retimes.
**Failure mode:** Assuming XML import equals final picture.
**Proof of work:** Conform QC checklist.

<a id="k092"></a>
#### K092 — HDR and SDR trims
**Stage:** Post · **Epistemic stance:** interpretive craft practice.
**Principle:** Distinct displays expose different highlight, shadow and color compromises.
**Do:** Master on defined reference monitors, inspect both trims and document transfer function.
**Failure mode:** Automatic downconversion accepted without creative QC.
**Proof of work:** Approved multi-display masters.
**Related sources:** [S04](#s04), [S08](#s08), [S09](#s09).

<a id="k093"></a>
#### K093 — Accessibility deliverables
**Stage:** Release · **Epistemic stance:** interpretive craft practice.
**Principle:** Captions, subtitles, audio description and multilingual versions are creative access paths.
**Do:** Scope them in budget and evaluate linguistic/artistic quality.
**Failure mode:** Accessibility retrofitted after distribution deadlines.
**Proof of work:** Accessible master asset list.

<a id="k094"></a>
#### K094 — DCP, IMF and platform packages
**Stage:** Release · **Epistemic stance:** interpretive craft practice.
**Principle:** Delivery is a family of versioned packages constrained by exhibitor or platform specifications.
**Do:** Test codecs, channel maps, naming, encryption, subtitles and checksums against recipient specs.
**Failure mode:** One master assumed universally deliverable.
**Proof of work:** Delivery acceptance report.
**Related sources:** [S07](#s07).

### Distribution & audience · 8 nodes
*Work meets the world.*
<a id="k095"></a>
#### K095 — Audience and positioning
**Stage:** Release · **Epistemic stance:** interpretive craft practice.
**Principle:** A film needs a distinct promise expressed to an identifiable audience without reducing it to a demographic stereotype.
**Do:** Test positioning and art on real viewers.
**Failure mode:** One universal campaign message.
**Proof of work:** Positioning statement.

<a id="k096"></a>
#### K096 — Festival route design
**Stage:** Release · **Epistemic stance:** interpretive craft practice.
**Principle:** Festivals offer different discovery, premiere and rights trade-offs rather than an automatic ladder.
**Do:** Map fees, deadlines, premiere rules, travel and strategic value.
**Failure mode:** Endless submissions with no objectives.
**Proof of work:** Festival decision matrix.

<a id="k097"></a>
#### K097 — Sales agents and distributors
**Stage:** Release · **Epistemic stance:** interpretive craft practice.
**Principle:** Terms transfer specific rights, territories, windows, expenses and control.
**Do:** Model downside clauses and reporting audit rights before signing.
**Failure mode:** Headline minimum guarantee obscuring deductions.
**Proof of work:** Deal waterfall review.

<a id="k098"></a>
#### K098 — Theatrical exhibition
**Stage:** Release · **Epistemic stance:** interpretive craft practice.
**Principle:** Cinema exhibition depends on projection, sound, DCP/KDM and local programming economics.
**Do:** Verify actual DCI version/spec, theatrical sound and screening tests.
**Failure mode:** Assuming online approval predicts projection behavior.
**Proof of work:** Cinema QC record.
**Related sources:** [S07](#s07).

<a id="k099"></a>
#### K099 — Streaming and broadcast
**Stage:** Release · **Epistemic stance:** interpretive craft practice.
**Principle:** Platforms impose differing QC, security, aspect, captions and loudness requirements.
**Do:** Maintain a specification matrix by outlet and territory.
**Failure mode:** Treating any platform as a single format.
**Proof of work:** Outlet delivery matrix.
**Related sources:** [S10](#s10).

<a id="k100"></a>
#### K100 — Trailers, posters and paratext
**Stage:** Release · **Epistemic stance:** interpretive craft practice.
**Principle:** Marketing edits tell a second story whose truthfulness matters.
**Do:** Test whether materials make the correct promise and reveal too much.
**Failure mode:** Great campaign for the wrong movie.
**Proof of work:** Campaign asset kit.

<a id="k101"></a>
#### K101 — Community and impact release
**Stage:** Release · **Epistemic stance:** interpretive craft practice.
**Principle:** A focused community may be a better distribution partner than broad unqualified reach.
**Do:** Build partnerships with consent and measurable outcomes.
**Failure mode:** Treating communities as free promotional labor.
**Proof of work:** Partnership and impact plan.

<a id="k102"></a>
#### K102 — Measurement and learning
**Stage:** Release · **Epistemic stance:** interpretive craft practice.
**Principle:** Views, admissions, completion, revenue and social mentions describe different outcomes.
**Do:** Segment metrics by window and trace spend against meaningful goals.
**Failure mode:** Vanity metrics substituted for impact or profitability.
**Proof of work:** Release retrospective.
**Related sources:** [S19](#s19).

### Finance & business · 8 nodes
*Sustainable project economics.*
<a id="k103"></a>
#### K103 — Financing architecture
**Stage:** Develop · **Epistemic stance:** interpretive craft practice.
**Principle:** Grants, equity, debt, pre-sales and incentives carry different recoupment and control costs.
**Do:** Map terms, milestones and cash timing across scenarios.
**Failure mode:** Financing headline mistaken for spendable cash.
**Proof of work:** Financing stack sheet.

<a id="k104"></a>
#### K104 — Chain of title
**Stage:** Develop · **Epistemic stance:** interpretive craft practice.
**Principle:** Rights ownership and permissions determine whether a project is financeable and distributable.
**Do:** Audit underlying works, life rights where relevant, music and contributor agreements.
**Failure mode:** Unclear ownership deferred to delivery.
**Proof of work:** Chain-of-title binder.

<a id="k105"></a>
#### K105 — Waterfall and recoupment
**Stage:** Develop · **Epistemic stance:** interpretive craft practice.
**Principle:** Gross receipts are not cash to investors; terms govern deductions and order of payment.
**Do:** Model priority, reserves, distribution fees and contingencies numerically.
**Failure mode:** ROI claims from box office headline alone.
**Proof of work:** Recoupment waterfall model.

<a id="k106"></a>
#### K106 — Cash flow and working capital
**Stage:** Prep · **Epistemic stance:** interpretive craft practice.
**Principle:** Production obligations precede revenues; timing can kill a solvent-looking project.
**Do:** Forecast cash weekly and define financing gaps.
**Failure mode:** Balanced budget with a negative bank balance.
**Proof of work:** Cash-flow calendar.

<a id="k107"></a>
#### K107 — Rights windows and territories
**Stage:** Release · **Epistemic stance:** interpretive craft practice.
**Principle:** Exclusive licenses partition exploitation rights by territory, medium, duration and language.
**Do:** Maintain a rights matrix and conflict checks.
**Failure mode:** Selling overlapping rights unintentionally.
**Proof of work:** Rights availability grid.

<a id="k108"></a>
#### K108 — Audience economics
**Stage:** Develop · **Epistemic stance:** interpretive craft practice.
**Principle:** Acquisition and retention costs change by genre, scale, territory and release model.
**Do:** Construct scenario-based demand assumptions and sensitivity tests.
**Failure mode:** Treating industry averages as a sales forecast.
**Proof of work:** Scenario P&L.
**Related sources:** [S19](#s19).

<a id="k109"></a>
#### K109 — Incentives and compliance
**Stage:** Prep · **Epistemic stance:** interpretive craft practice.
**Principle:** Rebates and tax credits depend on eligible spend, local rules and audit evidence.
**Do:** Validate timing, caps, labor conditions and documentary requirements with specialists.
**Failure mode:** Booking an incentive before eligibility is confirmed.
**Proof of work:** Incentive eligibility memo.

<a id="k110"></a>
#### K110 — Long-tail catalog strategy
**Stage:** Release · **Epistemic stance:** interpretive craft practice.
**Principle:** Rights management, preservation and discoverability can outlast launch weekend.
**Do:** Budget for masters, metadata, licenses and rights renewals.
**Failure mode:** No exploitation path after initial window.
**Proof of work:** Library exploitation plan.

### Rights, safety & ethics · 10 nodes
*Care and accountability.*
<a id="k111"></a>
#### K111 — Informed consent and power
**Stage:** Develop · **Epistemic stance:** interpretive craft practice.
**Principle:** Formal permission is not always meaningful consent when power or information is unequal.
**Do:** Make purposes and later reuse understandable; provide escalation pathways.
**Failure mode:** Treating a release form as a complete ethical process.
**Proof of work:** Consent and escalation protocol.

<a id="k112"></a>
#### K112 — Performer likeness and replicas
**Stage:** Prep · **Epistemic stance:** interpretive craft practice.
**Principle:** Digital replicas create distinct authorization, compensation and privacy concerns.
**Do:** Check union contract, jurisdiction, retention/security and use-by-use consent.
**Failure mode:** Assuming permission for filming grants model-training rights.
**Proof of work:** Replica rights register.
**Related sources:** [S12](#s12), [S13](#s13).

<a id="k113"></a>
#### K113 — Child and vulnerable participants
**Stage:** Prep · **Epistemic stance:** interpretive craft practice.
**Principle:** Participants may need age-specific care, guardianship, safeguarding and extra withdrawal boundaries.
**Do:** Engage qualified advisors and establish independent protection roles.
**Failure mode:** Consent extracted under situational pressure.
**Proof of work:** Safeguarding plan.

<a id="k114"></a>
#### K114 — Physical production safety
**Stage:** Shoot · **Epistemic stance:** interpretive craft practice.
**Principle:** A shot has no artistic claim that overrides preventable injury.
**Do:** Train crews, assess hazards and support unconditional stop work.
**Failure mode:** Unsafe shortcuts rewarded through schedule pressure.
**Proof of work:** Dynamic risk register.

<a id="k115"></a>
#### K115 — Psychological and intimacy safety
**Stage:** Shoot · **Epistemic stance:** interpretive craft practice.
**Principle:** Vulnerability should be choreographed with clear boundaries and professionally supervised where appropriate.
**Do:** Agree nudity, intimacy and distress protocols before cameras roll.
**Failure mode:** Improvised escalation on set.
**Proof of work:** Intimacy and support plan.

<a id="k116"></a>
#### K116 — Copyright, fair use and licensing
**Stage:** Develop · **Epistemic stance:** interpretive craft practice.
**Principle:** Rights analysis is fact-specific and differs across jurisdictions and exploitation channels.
**Do:** Track source assets, licenses, moral rights and legal review of exceptions.
**Failure mode:** Assuming online availability grants reuse rights.
**Proof of work:** Rights clearance log.
**Related sources:** [S13](#s13).

<a id="k117"></a>
#### K117 — Synthetic media disclosure and provenance
**Stage:** Post · **Epistemic stance:** interpretive craft practice.
**Principle:** Origin metadata can help audit media lineage, but provenance does not establish underlying truth.
**Do:** Record generation/edits and apply disclosure where required or ethically material.
**Failure mode:** Treating watermarks as sufficient proof.
**Proof of work:** Provenance manifest.
**Related sources:** [S11](#s11).

<a id="k118"></a>
#### K118 — Labor and fair production
**Stage:** Prep · **Epistemic stance:** interpretive craft practice.
**Principle:** Creative quality depends on humane working hours, bargaining, accessible hiring and respectful conditions.
**Do:** Check binding agreements and negotiate transparently with contributors.
**Failure mode:** Efficiency measured in unpaid labor.
**Proof of work:** Labor and access charter.

<a id="k119"></a>
#### K119 — Environmental impact
**Stage:** Prep · **Epistemic stance:** interpretive craft practice.
**Principle:** Energy, travel, materials and waste should be treated as design variables not late offsets.
**Do:** Compare lower-carbon location, grid/battery and logistics options.
**Failure mode:** Sustainability claims with no baseline.
**Proof of work:** Carbon plan with measured assumptions.
**Related sources:** [S14](#s14), [S15](#s15).

<a id="k120"></a>
#### K120 — Cultural representation and accountability
**Stage:** Develop · **Epistemic stance:** interpretive craft practice.
**Principle:** Authenticity requires participation, critique and control rather than token consultation.
**Do:** Budget lived-experience collaborators and document decision rights.
**Failure mode:** One advisor asked to represent an entire community.
**Proof of work:** Representation review plan.

### Documentary & hybrid · 7 nodes
*Truth claims and encounter.*
<a id="k121"></a>
#### K121 — Documentary truth contract
**Stage:** Develop · **Epistemic stance:** interpretive craft practice.
**Principle:** The nonfiction film makes claims about reality through choices of access, sequence and omission.
**Do:** State whether scenes are observed, reconstructed, archival or speculative.
**Failure mode:** Stylized reconstructions misread as actuality.
**Proof of work:** Nonfiction ethics statement.

<a id="k122"></a>
#### K122 — Observation and intervention
**Stage:** Shoot · **Epistemic stance:** interpretive craft practice.
**Principle:** Camera presence alters situations; pretending neutrality can conceal the filmmaker's causal role.
**Do:** Record interventions and negotiate boundaries with subjects.
**Failure mode:** Staging presented as spontaneous observation.
**Proof of work:** Field intervention log.

<a id="k123"></a>
#### K123 — Interview architecture
**Stage:** Prep · **Epistemic stance:** interpretive craft practice.
**Principle:** Interviews are encounters shaped by questions, listening, trauma, language and power.
**Do:** Ask non-leading questions and preserve context around strong quotations.
**Failure mode:** Selecting sound bites that invert meaning.
**Proof of work:** Interview context index.

<a id="k124"></a>
#### K124 — Archival evidence
**Stage:** Post · **Epistemic stance:** interpretive craft practice.
**Principle:** Archives need provenance, dates, permissions and separation of contemporaneous from retrospective claims.
**Do:** Create a claim-to-footage trace for contested facts.
**Failure mode:** Found footage trusted solely because it looks old.
**Proof of work:** Archival provenance log.

<a id="k125"></a>
#### K125 — Documentary narrative ethics
**Stage:** Post · **Epistemic stance:** interpretive craft practice.
**Principle:** Narrative structure is necessary but may create misleading cause or chronology.
**Do:** Test whether compression changes the meaning of evidence.
**Failure mode:** Manufactured causality from unrelated events.
**Proof of work:** Timeline and claim integrity review.

<a id="k126"></a>
#### K126 — Participatory and co-created cinema
**Stage:** Develop · **Epistemic stance:** interpretive craft practice.
**Principle:** Subjects can hold authorship and review power without requiring editorial veto.
**Do:** Negotiate reciprocal benefits, review points and credited labor.
**Failure mode:** Consultation after irreversible decisions.
**Proof of work:** Collaboration agreement.

<a id="k127"></a>
#### K127 — Experimental and essay film
**Stage:** Develop · **Epistemic stance:** interpretive craft practice.
**Principle:** Association, duration, material and ambiguity can replace conventional plot as organizing logics.
**Do:** Define the experiential proposition and test whether form enacts it.
**Failure mode:** Formal novelty without perceptual consequence.
**Proof of work:** Formal experiment dossier.

### Frontier systems · 10 nodes
*What is changing now.*
<a id="k128"></a>
#### K128 — Human–AI creative orchestration
**Stage:** Frontier · **Epistemic stance:** emerging research / adoption.
**Principle:** Multi-model creative assistants may coordinate research, storyboards, metadata and iterations; authorship remains a human and contractual question.
**Do:** Compare human control, provenance and error rates against a manual baseline.
**Failure mode:** Vendor demos accepted as proof of repeatability.
**Proof of work:** AI task-boundary charter.
**Related sources:** [S12](#s12), [S16](#s16), [S17](#s17).

<a id="k129"></a>
#### K129 — Long-horizon video coherence
**Stage:** Frontier · **Epistemic stance:** emerging research / adoption.
**Principle:** AI video can produce compelling clips yet coherent multi-shot identity, physics and editability remain active research problems.
**Do:** Benchmark returning characters, object state, contact motion and scene revisions.
**Failure mode:** One successful clip projected to a feature pipeline.
**Proof of work:** Cross-shot consistency benchmark.
**Related sources:** [S16](#s16), [S17](#s17), [S23](#s23), [S24](#s24).

<a id="k130"></a>
#### K130 — Scene and world-state models
**Stage:** Frontier · **Epistemic stance:** emerging research / adoption.
**Principle:** Explicit character, wardrobe, location and prop state can bridge creative plans and generation systems.
**Do:** Maintain a machine-readable continuity bible and test edits downstream.
**Failure mode:** Memory database mistaken for narrative understanding.
**Proof of work:** Structured scene-state schema.
**Related sources:** [S16](#s16), [S02](#s02).

<a id="k131"></a>
#### K131 — Standardized creative vocabulary
**Stage:** Frontier · **Epistemic stance:** emerging research / adoption.
**Principle:** Shared labels with creative intent can make human-to-tool directions less ambiguous.
**Do:** Test consistent interpretation of lens, shot, angle and movement across systems.
**Failure mode:** Treating taxonomy as universal aesthetics.
**Proof of work:** Creative intent vocabulary map.
**Related sources:** [S03](#s03).

<a id="k132"></a>
#### K132 — Composable cloud workflows
**Stage:** Frontier · **Epistemic stance:** emerging research / adoption.
**Principle:** Standardized identities and event-driven tasks promise fewer manual file handoffs.
**Do:** Pilot one reversible workflow using stable asset IDs and zero-trust access.
**Failure mode:** Complex automation without observable handoffs.
**Proof of work:** Interoperability pilot and rollback.
**Related sources:** [S01](#s01), [S02](#s02).

<a id="k133"></a>
#### K133 — Provenance and content credentials
**Stage:** Frontier · **Epistemic stance:** emerging research / adoption.
**Principle:** Signed assertions improve traceability if capture, editing and distribution systems preserve them.
**Do:** Verify manifest integrity after edits, transcodes and platform delivery.
**Failure mode:** Confusing absence of credentials with evidence of fraud.
**Proof of work:** Chain-of-provenance test.
**Related sources:** [S11](#s11).

<a id="k134"></a>
#### K134 — Neural scene representations
**Stage:** Frontier · **Epistemic stance:** emerging research / adoption.
**Principle:** Gaussian splatting and related methods can speed spatial capture, but robust relighting and occlusion remain conditional.
**Do:** Compare against tracked geometry across controlled lighting and camera paths.
**Failure mode:** Novel render style equated with production readiness.
**Proof of work:** Geometry/relighting A–B test.
**Related sources:** [S18](#s18).

<a id="k135"></a>
#### K135 — HDR and emissive cinema
**Stage:** Frontier · **Epistemic stance:** emerging research / adoption.
**Principle:** Expanded exhibition dynamic range changes both mastering and creative expectations, not simply brightness.
**Do:** Author a venue-aware HDR/SDR comparison and monitor updated DCI requirements.
**Failure mode:** Single grade assumed equivalent in every auditorium.
**Proof of work:** Multi-venue mastering study.
**Related sources:** [S08](#s08).

<a id="k136"></a>
#### K136 — Automation of reconform and metadata
**Stage:** Frontier · **Epistemic stance:** emerging research / adoption.
**Principle:** Timeline interchange and semantic metadata can reduce repetitive repair work across departments.
**Do:** Run round-trip and version-diff tests on a complex sequence.
**Failure mode:** Automation saves time but silently changes intent.
**Proof of work:** Measured reconform benchmark.
**Related sources:** [S06](#s06).

<a id="k137"></a>
#### K137 — Resilient sustainable production
**Stage:** Frontier · **Epistemic stance:** emerging research / adoption.
**Principle:** Cleaner temporary power, measurable carbon and rights-aware remote collaboration can reshape production design.
**Do:** Compare total costs, uptime, acoustic quality and emissions for alternatives.
**Failure mode:** Branding sustainability without a measured system boundary.
**Proof of work:** Sustainable production trial.
**Related sources:** [S14](#s14), [S15](#s15).

## 4. Cross-domain causal topology
The edge file captures explicit, authored relationships. A link states a **design implication** or dependency, not measured causal proof unless independently established. A graph is useful only when edge types and failure conditions are legible.
- **Premise and thematic question** —*constrains→* **Directorial intention**: Dramatic question informs expressive choices.
- **Premise and thematic question** —*informs→* **Audience and positioning**: A film promise reflects its dramatic center.
- **Character desire and need** —*informs→* **Directing actors**: Actionable objectives become playable direction.
- **Causality and plot** —*decomposes_into→* **Scene design**: Plot consequences become scene turns.
- **Scene design** —*enables→* **Script breakdown**: Dramatic action implies production requirements.
- **Structure and rhythm** —*tested_by→* **Temporal architecture**: Structural pressure is evaluated through duration.
- **Point of view and empathy** —*constrains→* **Subjective and objective camera**: Camera stance governs alignment.
- **Point of view and empathy** —*constrains→* **Sound point of audition**: Knowledge access extends beyond images.
- **Research and lived specificity** —*requires→* **Cultural representation and accountability**: Lived context must include review and agency.
- **Directorial intention** —*constrains→* **Coverage as interpretation**: Coverage serves dramatic hypothesis.
- **Casting and chemistry** —*informs→* **Rehearsal design**: Ensemble dynamics shape rehearsal.
- **Rehearsal design** —*informs→* **Blocking and power**: Behavioral discoveries determine positions.
- **Blocking and power** —*enables→* **Camera movement**: Movement is motivated by actor geography.
- **Tone across departments** —*constrains→* **Lighting motivation**: Lighting decisions uphold tone.
- **Tone across departments** —*constrains→* **Music as counterpoint**: Score may support or complicate tone.
- **Coverage as interpretation** —*enables→* **Editorial hypothesis**: Coverage defines editorial degrees of freedom.
- **Performance continuity** —*supports→* **Performance-led selects**: Emotional state notes inform take choice.
- **Composition and attention** —*informs→* **Lighting motivation**: Luminance contrast guides gaze.
- **Shot scale and intimacy** —*informs→* **Coverage as interpretation**: Shot distance is an expressive constraint.
- **Lens and perspective** —*requires→* **Plate capture and lens metadata**: Camera geometry needed for effects.
- **Camera movement** —*interacts_with→* **Screen direction and geography**: Motion can clarify or disrupt spatial inference.
- **Aspect ratio and format** —*constrains→* **DCP, IMF and platform packages**: Creative shape must survive delivery.
- **Visual motifs** —*informs→* **Production design narrative**: Objects and surfaces carry recurring meanings.
- **Exposure and scene latitude** —*requires→* **Color management (ACES)**: Scene-referred workflow protects exposure intent.
- **Color contrast and palette** —*co_design→* **Costume and character arc**: Wardrobe colors interact with grading.
- **Color contrast and palette** —*co_design→* **HDR and SDR trims**: Color decisions require target-display approval.
- **Shutter and motion rendition** —*constrains→* **In-camera virtual production**: Sync and LED interaction require tests.
- **Camera sensor and format** —*constrains→* **Data and image integrity**: Recording format affects handling.
- **Data and image integrity** —*requires→* **Checksums, backup and restore**: Media must be copied and validated.
- **Monitoring and look transforms** —*requires→* **Color management (ACES)**: On-set views require traceable transforms.
- **Locations and control** —*constrains→* **Production dialogue**: Noise and access determine recordability.
- **Locations and control** —*constrains→* **Daily call and readiness**: Location restrictions affect daily feasibility.
- **Costume and character arc** —*requires→* **Continuity supervision**: State tracking protects chronology.
- **Props and practical effects** —*requires→* **Stunts and practical hazard controls**: Physical effects need specialist safeguards.
- **Sound point of audition** —*co_design→* **Editorial hypothesis**: Point of audition can motivate cuts.
- **Production dialogue** —*enables→* **Dialogue editing and ADR**: Good recordings preserve options.
- **Dialogue editing and ADR** —*precedes→* **Sound editorial to mix**: Clean edits feed final mix.
- **Ambience and spatial worlds** —*interacts_with→* **Continuity and discontinuity**: Acoustic bridges can hide or expose cuts.
- **Music as counterpoint** —*informs→* **Information release**: Music can change reveal timing.
- **Dynamic range and silence** —*constrains→* **Streaming and broadcast**: Delivery environment changes mix strategy.
- **Spatial / immersive sound** —*requires→* **Theatrical exhibition**: Exhibition format must be tested.
- **Editorial hypothesis** —*stabilizes→* **Picture lock and change control**: Locked timing anchors dependent departments.
- **Performance-led selects** —*tested_by→* **Test screenings**: Audience reaction probes editorial hypotheses.
- **Picture lock and change control** —*enables→* **VFX plates and color handoff**: Shot ranges and handles become stable.
- **Picture lock and change control** —*enables→* **Sound editorial to mix**: Final timing allows mixes to converge.
- **Picture lock and change control** —*enables→* **Conform, grade and finishing**: Conform reconstructs the approved edit.
- **Previsualization and techvis** —*enables→* **In-camera virtual production**: Geometry assumptions must be tested.
- **Plate capture and lens metadata** —*requires→* **Compositing and integration**: Matching lens and lighting information aid integration.
- **Compositing and integration** —*requires→* **VFX plates and color handoff**: Color and naming conventions prevent mistakes.
- **Animation principles** —*informs→* **Character and creature systems**: Control design follows expressive movement.
- **Real-time engines and simulation** —*enables→* **In-camera virtual production**: Real-time scene drives on-set displays.
- **Volumetric and neural reconstruction** —*related_to→* **Neural scene representations**: Both depend on captured spatial appearance.
- **Creative producing** —*constrains→* **Budget and cost reports**: Creative priorities decide resource allocation.
- **Packaging and greenlight** —*requires→* **Chain of title**: Finance and sale need rights clarity.
- **Script breakdown** —*enables→* **Scheduling and critical path**: Requirements constrain feasible day order.
- **Scheduling and critical path** —*constrains→* **Coverage under scarcity**: Finite time changes priority shots.
- **Budget and cost reports** —*requires→* **Cash flow and working capital**: Costs must align with timing.
- **Communication architecture** —*enables→* **Creative change management**: Approval responsibility makes changes traceable.
- **Contingency and resilience** —*informs→* **Weather, light and environmental control**: Plan alternate schedules.
- **Daily call and readiness** —*requires→* **Set command and decision rights**: Who approves and stops work must be explicit.
- **Set command and decision rights** —*requires→* **Physical production safety**: Safety authority must be operational.
- **Stunts and practical hazard controls** —*implements→* **Physical production safety**: Specialist mitigation implements risk policy.
- **Unit data workflow** —*enables→* **Media identity and metadata**: Reliable identifiers connect set to post.
- **Wrap and post handoff** —*requires→* **Timecode and synchronization**: Daily sync exceptions travel with media.
- **Media identity and metadata** —*enables→* **Editorial interchange (OTIO)**: Timeline references rely on stable media identities.
- **Color management (ACES)** —*enables→* **Conform, grade and finishing**: Consistent transforms support grading.
- **HDR and SDR trims** —*requires→* **Theatrical exhibition**: Display-specific QC for cinema.
- **Accessibility deliverables** —*required_by→* **Streaming and broadcast**: Accessible versions accompany masters.
- **DCP, IMF and platform packages** —*enables→* **Theatrical exhibition**: Packaging determines cinema compatibility.
- **Audience and positioning** —*informs→* **Trailers, posters and paratext**: Campaign expresses promise.
- **Festival route design** —*interacts_with→* **Sales agents and distributors**: Premiere/rights trade-offs affect deals.
- **Sales agents and distributors** —*requires→* **Rights windows and territories**: Rights grants must be non-conflicting.
- **Measurement and learning** —*informs→* **Audience economics**: Actual outcomes update assumptions.
- **Financing architecture** —*constrains→* **Waterfall and recoupment**: Financing terms determine repayment.
- **Chain of title** —*requires→* **Copyright, fair use and licensing**: Cleared underlying rights are foundational.
- **Informed consent and power** —*constrains→* **Documentary truth contract**: Nonfiction relationships determine what can be shown.
- **Interview architecture** —*requires→* **Documentary narrative ethics**: Quote contexts must survive edit.
- **Archival evidence** —*supports→* **Documentary narrative ethics**: Evidence lineage checks reconstructions.
- **Observation and intervention** —*informs→* **Documentary truth contract**: Camera causality qualifies truth claims.
- **Environmental impact** —*informs→* **Resilient sustainable production**: Measured footprint guides redesign.
- **Synthetic media disclosure and provenance** —*implements→* **Provenance and content credentials**: Signed manifests operationalize records.
- **Performer likeness and replicas** —*constrains→* **Human–AI creative orchestration**: Human rights govern tool use.
- **Creative change management** —*informs→* **Automation of reconform and metadata**: Diffs and dependencies need change control.
- **Media identity and metadata** —*enables→* **Composable cloud workflows**: Stable identifiers allow automation.
- **Scene and world-state models** —*hypothesized_enabler→* **Long-horizon video coherence**: Explicit state might reduce drift; needs testing.
- **Standardized creative vocabulary** —*enables→* **Human–AI creative orchestration**: Structured prompts preserve intent more precisely.
- **Provenance and content credentials** —*does_not_replace→* **Copyright, fair use and licensing**: Lineage is not a license.
- **Long-horizon video coherence** —*tested_by→* **Editorial hypothesis**: Produced clips still need human editorial criteria.
- **Neural scene representations** —*investigated_for→* **In-camera virtual production**: Neural appearance fields may assist VP with limits.
- **HDR and emissive cinema** —*extends→* **HDR and SDR trims**: Extended dynamic range increases trim complexity.
- **Dialogue and subtext** —*informs→* **Directing actors**: Subtext is acted as a strategy, not pronounced.
- **Genre and promise** —*informs→* **Audience and positioning**: Audience expectations affect release promise.
- **Visual literacy and references** —*enables→* **Tone across departments**: Annotated references align intentions.
- **Depth of field** —*constrains→* **Performance-led selects**: Focus reliability changes usable emotional takes.
- **Camera movement systems** —*requires→* **Stunts and practical hazard controls**: Heavy and moving rigs require safe engineering.
- **World rules and geography** —*informs→* **Production design narrative**: Design encodes the rules of a fictional world.
- **Makeup, hair and prosthetics** —*requires→* **Monitoring and look transforms**: Close photographic makeup tests need correct viewing transforms.
- **Architecture of production scale** —*constrains→* **Budget and cost reports**: Scale illusions must fit actual allocations.
- **Foley and material storytelling** —*co_design→* **Ambience and spatial worlds**: Material contacts interact with environment sound.
- **Transitions and montage** —*informs→* **Information release**: Juxtaposition controls how an audience deduces a reveal.
- **VFX as a story choice** —*informs→* **Creative producing**: Technique selection changes funding and craft tradeoffs.
- **Community and impact release** —*tested_by→* **Measurement and learning**: Community outcomes require defined metrics.
- **Incentives and compliance** —*informs→* **Financing architecture**: Actual eligibility affects financing cash and timing.
- **Long-tail catalog strategy** —*requires→* **Rights windows and territories**: Library life depends on trackable residual rights.
- **Child and vulnerable participants** —*requires→* **Informed consent and power**: Additional protection sharpens consent process.
- **Psychological and intimacy safety** —*constrains→* **Rehearsal design**: Rehearsals must honor agreed boundaries.
- **Labor and fair production** —*constrains→* **Scheduling and critical path**: Crew fatigue and turnaround determine schedule limits.
- **Participatory and co-created cinema** —*extends→* **Documentary truth contract**: Coauthors shape the nonfiction claim and power.
- **Experimental and essay film** —*reframes→* **Visual motifs**: Experiential structure can substitute for plot causality.

## 5. The 2026 frontier observatory
A frontier item is a **conditional decision brief**, not a tool endorsement or prediction. Time horizons are planning heuristics.
### F01 — Long-form generative video
**State:** emerging / research
**Watch window:** now–3y
**Dated signal:** September 2026 Google Research describes multi-agent methods that track characters and locations over many shots; underlying evaluation is by the reporting lab.
**What is not established:** Single-lab examples and model-specific setups do not establish robust editability, economics or industry-wide repeatability.
**Discriminating field test:** Create a 24-shot, two-location story with returning props; score identity, continuity, physics, narrative and human correction hours across 3 runs.
**Adoption threshold:** Independent repeated trials show lower total creative correction cost than conventional alternatives.
**Practical policy:** Prototype for previs/experimental material; retain human review and fallback capture.
**Sources:** [S16](#s16), [S17](#s17), [S23](#s23), [S24](#s24).

### F02 — Human-centered creative vocabulary
**State:** deployed early standardization
**Watch window:** now–2y
**Dated signal:** MovieLabs Creative Vocabulary v1.0 was announced July 8, 2026 and defines intent-bearing cinematography terminology in four categories.
**What is not established:** Cross-model interpretation and adoption vary; a vocabulary is not an aesthetics engine.
**Discriminating field test:** Give 40 identical creative instructions to three model/tool stacks; blind-rate camera/intent conformance.
**Adoption threshold:** Meaningfully lower variance on unseen shot requests and reversible round-trips.
**Practical policy:** Use as metadata layer but preserve filmmaker-authored reasons.
**Sources:** [S03](#s03).

### F03 — Interoperable metadata + cloud workflows
**State:** adopting / integration challenge
**Watch window:** now–5y
**Dated signal:** MovieLabs 2030 Vision promotes secure software-defined workflows; OMC 2.8 added collections and custom-data support in Jan 2026.
**What is not established:** Ontology compatibility does not guarantee semantic agreement across proprietary editorial/VFX systems.
**Discriminating field test:** Transfer 100 shot objects across production, editorial and VFX, retaining identities, permissions, timestamps and version lineage.
**Adoption threshold:** Near-zero unmapped attributes plus measurable reduced manual reconciliation.
**Practical policy:** Build a small vendor-neutral pilot; insist on export and rollback.
**Sources:** [S01](#s01), [S02](#s02), [S22](#s22).

### F04 — Color-managed creative continuity
**State:** established / evolving implementation
**Watch window:** now
**Dated signal:** ACES 2.0 released in 2025 and addresses display rendering and cross-dynamic-range consistency; current deployments depend on tool support.
**What is not established:** A standard pipeline does not eliminate creative judgment or monitor/hardware errors.
**Discriminating field test:** Perform cross-application transform round trips on faces, saturated lights and extreme highlights.
**Adoption threshold:** Passing reference image and metadata tests across every required vendor.
**Practical policy:** Commit to scene-referred pipeline tests in preproduction.
**Sources:** [S04](#s04), [S05](#s05), [S25](#s25).

### F05 — HDR and emissive digital cinema
**State:** specification evolving
**Watch window:** now–4y
**Dated signal:** DCI published DCSS 1.5.0 on Jan 29, 2026 and its HDR D-Cinema Addendum v1.2.2 on Feb 19, 2026.
**What is not established:** Cinema display adoption, auditorium conditions and access to properly calibrated HDR screens differ widely.
**Discriminating field test:** Screen matched scenes at a controlled cinema and HDR review room, scoring intent changes.
**Adoption threshold:** Documented display/calibration conformance and distribution path.
**Practical policy:** Finish to agreed venue/outlet targets; do not assume universal HDR.
**Sources:** [S07](#s07), [S08](#s08), [S09](#s09).

### F06 — Signed media provenance
**State:** standard / partial ecosystem adoption
**Watch window:** now–3y
**Dated signal:** C2PA 2.4 defines signed assertions and their association to media through a chain of edits.
**What is not established:** Signing establishes provenance claims, not truth; downstream platforms may strip credentials.
**Discriminating field test:** Test capture→edit→transcode→distribution with manifest validation, tamper detection and privacy review.
**Adoption threshold:** Major outlets preserve and display actionable credential status.
**Practical policy:** Pilot evidence traceability and maintain a separate legal rights ledger.
**Sources:** [S11](#s11), [S13](#s13).

### F07 — Synthetic performers and digital replicas
**State:** regulated by contract / changing
**Watch window:** now
**Dated signal:** SAG-AFTRA 2026 TV/theatrical agreement adds protections for digital replicas and synthetics, including bargaining provisions.
**What is not established:** Applicability depends on the production, covered contract, union, territory and updated law.
**Discriminating field test:** Perform a rights/consent threat model before any sample or likeness capture.
**Adoption threshold:** Documented informed consent, compensation, security, retention and permitted-use approvals.
**Practical policy:** Treat likeness as protected human data; obtain qualified legal/labor review.
**Sources:** [S12](#s12), [S13](#s13).

### F08 — Neural 3D scenes and relighting
**State:** research prototype
**Watch window:** 1–4y
**Dated signal:** A May 2026 preprint reports a relightable Gaussian-splatting pipeline designed for controlled virtual-production scenes.
**What is not established:** Task-specific datasets and reported efficiency cannot be generalized to all hair, transparency, motion, relighting or VFX shots.
**Discriminating field test:** Capture 5 materials under 4 lighting conditions with ground truth and compare relighting fidelity and correction hours.
**Adoption threshold:** Repeatable success under held-out lighting and difficult surfaces.
**Practical policy:** Use for spatial ideation where capture rights and reconstruction errors are acceptable.
**Sources:** [S18](#s18).

### F09 — Virtual production integration
**State:** established niche / active standards practice
**Watch window:** now–3y
**Dated signal:** SMPTE technical work addresses color consistency for LED panels; 2026 Academy investigations include color-accurate LED lighting.
**What is not established:** Wall-to-camera performance depends on refresh, exposure, color, tracking, scale and technical crews.
**Discriminating field test:** Shoot test plates of skin, fine fabrics, speculars and fast pans at planned exposures.
**Adoption threshold:** Acceptance criteria on moiré, tracking, latency, flicker and color passed on actual stage.
**Practical policy:** Plan VP as a system, not a display rental.
**Sources:** [S25](#s25), [S20](#s20).

### F10 — Low-carbon production systems
**State:** active operational transition
**Watch window:** now–2030
**Dated signal:** BAFTA albert published a UK clean temporary power roadmap in December 2025 and offers a production carbon toolkit.
**What is not established:** Life-cycle totals, grid availability and local infrastructure differ across regions.
**Discriminating field test:** Compare diesel/hybrid/grid/battery cases for energy, reliability, cost, noise and emissions over a real location day.
**Adoption threshold:** Auditable lifecycle savings without risk to working conditions or production continuity.
**Practical policy:** Integrate footprint and logistical constraints from planning, not after wrap.
**Sources:** [S14](#s14), [S15](#s15).

### F11 — Exhibition and audience bifurcation
**State:** observed regional signal
**Watch window:** now–5y
**Dated signal:** European Audiovisual Observatory estimated 2025 cinema admissions declined 5.5% to 796 million, while regional box office revenue was comparatively stable.
**What is not established:** Preliminary European aggregates do not predict one title or other world regions.
**Discriminating field test:** Model releases against realistic cohort audience, booking, ticket-price and alternate-window scenarios.
**Adoption threshold:** Evidence of purchase/attendance behavior from a comparable local audience.
**Practical policy:** Develop audience access strategy alongside development financing.
**Sources:** [S19](#s19).

### F12 — Automated conform and semantic handoffs
**State:** maturing tools / operational risk
**Watch window:** now–3y
**Dated signal:** OpenTimelineIO supports editable timeline metadata and external media references; 2026 Academy awards recognized audio and reconform-related advances.
**What is not established:** Unsupported transforms, effects, retimes and proprietary metadata can silently change output.
**Discriminating field test:** Round-trip a 150-shot sequence with nested edits, speed changes, captions, sound handoff and VFX pulls.
**Adoption threshold:** Frame-accurate and metadata-accurate acceptance on fixed test suite.
**Practical policy:** Automate repetitive transfers; keep human creative signoff.
**Sources:** [S06](#s06), [S21](#s21).

## 6. Five learning and production routes
### First short film
*Make one precise expressive choice, then close the loop all the way to audience.*
[Premise and thematic question](#k001) → [Scene design](#k004) → [Directorial intention](#k010) → [Production dialogue](#k044) → [Script breakdown](#k071) → [Daily call and readiness](#k077) → [Performance-led selects](#k053) → [DCP, IMF and platform packages](#k094)
**Exercise:** Create each node’s named artifact for one genuine scene, then conduct a peer review and record what changed.

### Indie feature producer
*Build a viable film and a viable agreement, not only a shoot.*
[Chain of title](#k104) → [Audience economics](#k108) → [Creative producing](#k069) → [Financing architecture](#k103) → [Budget and cost reports](#k073) → [Scheduling and critical path](#k072) → [Rights windows and territories](#k107) → [Waterfall and recoupment](#k105)
**Exercise:** Create each node’s named artifact for one genuine scene, then conduct a peer review and record what changed.

### Cinematographer / colorist
*Trace intent from eye line to projection.*
[Point of view and empathy](#k008) → [Composition and attention](#k018) → [Lens and perspective](#k020) → [Exposure and scene latitude](#k027) → [Monitoring and look transforms](#k035) → [Color management (ACES)](#k088) → [HDR and SDR trims](#k092) → [Theatrical exhibition](#k098)
**Exercise:** Create each node’s named artifact for one genuine scene, then conduct a peer review and record what changed.

### Documentary creator
*Treat documentary craft as accountable evidence-making.*
[Documentary truth contract](#k121) → [Informed consent and power](#k111) → [Observation and intervention](#k122) → [Interview architecture](#k123) → [Archival evidence](#k124) → [Documentary narrative ethics](#k125) → [Synthetic media disclosure and provenance](#k117) → [Community and impact release](#k101)
**Exercise:** Create each node’s named artifact for one genuine scene, then conduct a peer review and record what changed.

### AI / VP pipeline architect
*Test creative controllability, technical integration and rights together.*
[Standardized creative vocabulary](#k131) → [Scene and world-state models](#k130) → [Media identity and metadata](#k085) → [Composable cloud workflows](#k132) → [In-camera virtual production](#k066) → [Long-horizon video coherence](#k129) → [Provenance and content credentials](#k133) → [Automation of reconform and metadata](#k136)
**Exercise:** Create each node’s named artifact for one genuine scene, then conduct a peer review and record what changed.

## 7. Eight decisive cross-discipline tests
- **Narrative:** After a scene, can five fresh viewers describe what changed, without being coached?
- **Performance:** Does the decisive emotional action remain readable with picture muted or the performance seen out of sequence?
- **Camera:** Does a lens/camera move improve inference relative to a simpler baseline?
- **Sound:** Can key dialogue and narrative cues be followed on the worst intended playback device?
- **Pipeline:** Can the scene be reconstructed, conformed and traced after one department changes software?
- **Safety & consent:** Can every affected worker or subject explain permissions, stop conditions and escalation?
- **Generative AI:** Can the same creative instruction be revised precisely and reproduced under a fixed resource budget?
- **Release:** Does the campaign attract the audience that actually values the film, at acceptable acquisition cost?

## 8. Case simulation: one two-minute scene, three production pathways
**Scene:** Two siblings prepare to sell their late parent’s house; one finds an undisclosed recording and decides not to reveal it. Dramatic intention: transform shared grief into asymmetrical knowledge without dialogue explaining the twist.
| Decision | Naturalistic location | LED/virtual stage | Generative/hybrid |
|---|---|---|---|
| Authorship | Actors work against real space | Actors interact with controlled image and practical set | Human editorial authorship must specify states and permissions |
| Image | Dawn test; window latitude; sound contamination | Display-camera tests; frustum; moiré; practical reflection | Cross-shot consistency; hand/object motion and matched faces |
| Sound | Airplanes, traffic and intimate dialogue are first-order risks | Fan noise, reverberation and playback sync need tests | Generated speech consent, acoustics and intelligibility need approval |
| Evidence | Take/continuity notes + camera/sound reports | Tracking/lens/environment metadata + versioned assets | Prompt/model/version lineage + permissions + regeneration cost |
| Failure signal | Performance broken by location or time | Display artifact ruins close-up | The recording/object or sibling identity changes across shots |
| Decision gate | Scout + rehearsal + camera/sound test | Stage acceptance + budget proof | 24-shot continuity benchmark + legal/rights clearance |
**Result:** Do not choose a method from aesthetic marketing. Compare the cost of achieving the same dramatic effect, the ability to revise it, the rights burden, and the failure recovery path.

## 9. Foresight, blind spots and negative knowledge
**Unknowns to track:** reliable editability of generated shots; portability of creative semantics; maintenance cost of enterprise metadata; impact of AI on diverse creative labor; long-term preservation of model-dependent assets; sustainability rebound effects; regional and accessibility differences in audience behavior.
**False equivalences to refuse:** resolution ≠ cinematic meaning; photorealism ≠ believable performance; provenance ≠ truth; watermark ≠ consent; a film festival selection ≠ commercial demand; temporal smoothness ≠ physical correctness; standardized naming ≠ system interoperability; technical accuracy ≠ emotional truth; synthetic realism ≠ ethical legitimacy.
**Disconfirming tests:** collect rival hypotheses, deliberately include hard cases, set a baseline, require restoration after failures, measure total human correction time, and record whose perspective is excluded.

## 10. Maintenance and versioning
**Snapshot:** 2026-10-17; **version:** 1.0. Re-check fast-moving source versions, labor contracts, regulatory obligations and software changes before adoption.
- Watch official issuers and peer-reviewed work.
- Capture claim, publication date, event date and context.
- Separate specification, research, opinion and own inference.
- Seek disconfirming evidence and realistic counterexamples.
- Update node and edge with rationale and version.
- Rerun key production tests and archive prior state.
The JSON uses stable IDs, typed links and source identifiers so new versions can be diffed without relabeling the whole atlas.

## 11. Sources and provenance ledger
Sources mainly support **specific technical, policy, market and frontier claims**. Craft nodes are editorial synthesis rather than sourced scientific laws. Access dates reflect this snapshot; if a source changes, archive an updated reference and date.
<a id="s01"></a>
### S01: MovieLabs 2030 Vision
**Issuer:** MovieLabs · **Date:** 2019–2026 · **Type:** industry roadmap.
Studio-led principles for interoperable, secure, software-defined production.  
**URL:** https://movielabs.com/the-2030-vision/

<a id="s02"></a>
### S02: Ontology for Media Creation v2.8
**Issuer:** MovieLabs · **Date:** 2026-01-03 · **Type:** industry specification.
Versioned industry metadata ontology; not the same schema as this independently authored atlas.  
**URL:** https://movielabs.com/news/movielabs-releases-ontology-for-media-creation-v2-8/

<a id="s03"></a>
### S03: Creative Vocabulary v1.0
**Issuer:** MovieLabs · **Date:** 2026-07-08 · **Type:** industry vocabulary.
Initial controlled vocabulary covers lens, shot size, camera movement and angle, with attention to intent.  
**URL:** https://movielabs.com/news/movielabs-announces-the-movielabs-creative-vocabulary/

<a id="s04"></a>
### S04: Academy announcement: ACES 2.0
**Issuer:** Academy of Motion Picture Arts and Sciences · **Date:** 2025-08-06 · **Type:** official release.
ACES 2.0 launched in 2025 with rendering and interoperability improvements.  
**URL:** https://press.oscars.org/news/academy-motion-picture-arts-and-sciences-launches-next-chapter-aces-academy-software

<a id="s05"></a>
### S05: ACES code and release packages
**Issuer:** Academy Software Foundation · **Date:** 2025–2026 · **Type:** software project.
ACES release coordination and component definitions.  
**URL:** https://github.com/aces-aswf/aces

<a id="s06"></a>
### S06: OpenTimelineIO project
**Issuer:** Academy Software Foundation · **Date:** accessed 2026-10-17 · **Type:** software specification.
Timeline interchange references media; does not embed audio or video essence.  
**URL:** https://github.com/AcademySoftwareFoundation/OpenTimelineIO

<a id="s07"></a>
### S07: DCI System Specification v1.5.0
**Issuer:** Digital Cinema Initiatives · **Date:** 2026-01-29 · **Type:** industry specification.
Current DCSS approval date shown by DCI as of atlas preparation.  
**URL:** https://www.dcimovies.com/dci-specification/

<a id="s08"></a>
### S08: DCI HDR D-Cinema Addendum v1.2.2
**Issuer:** Digital Cinema Initiatives · **Date:** 2026-02-19 · **Type:** industry specification.
Defines HDR cinema reference display and tolerances for review/exhibition.  
**URL:** https://www.dcimovies.com/dci-specification/

<a id="s09"></a>
### S09: ITU-R BT.2100-3
**Issuer:** International Telecommunication Union · **Date:** 2025-02-05 · **Type:** international recommendation.
HDR-TV image parameters covering PQ and HLG; applicable by delivery context.  
**URL:** https://www.itu.int/rec/R-REC-BT.2100-3-202502-I/en

<a id="s10"></a>
### S10: EBU R 128 v5.0
**Issuer:** European Broadcasting Union · **Date:** 2023-11-21 · **Type:** broadcast recommendation.
Programme loudness recommendation; not a universal theatrical mix target.  
**URL:** https://tech.ebu.ch/publications/r128

<a id="s11"></a>
### S11: C2PA Content Credentials 2.4
**Issuer:** Coalition for Content Provenance and Authenticity · **Date:** 2026 · **Type:** technical specification.
Signed media provenance and manifests, not an independent truth detector.  
**URL:** https://spec.c2pa.org/specifications/specifications/2.4/specs/C2PA_Specification.html

<a id="s12"></a>
### S12: 2026 TV/Theatrical contracts
**Issuer:** SAG-AFTRA · **Date:** 2026 · **Type:** labor agreement.
Union-specific provisions on digital replicas, synthetics, notice and bargaining.  
**URL:** https://www.sagaftra.org/contracts-industry-resources/contracts/2026-tvtheatrical-contracts

<a id="s13"></a>
### S13: Copyright & AI study
**Issuer:** U.S. Copyright Office · **Date:** 2024–2025 · **Type:** legal policy analysis.
U.S.-specific evolving analysis on digital replicas, copyrightability and training.  
**URL:** https://copyright.gov/policy/artificial-intelligence/

<a id="s14"></a>
### S14: Clean Temporary Power by 2030 (SPARK)
**Issuer:** BAFTA albert · **Date:** 2025-12-11 · **Type:** industry roadmap.
Production power decarbonization roadmap and UK industry statement of intent.  
**URL:** https://www.bafta.org/media-centre/press-releases/bafta-albert-spark-clean-temporary-power/

<a id="s15"></a>
### S15: BAFTA albert resources & calculator
**Issuer:** BAFTA albert · **Date:** 2026 · **Type:** operational toolkit.
Sustainable production practices and carbon measurement tools.  
**URL:** https://baftaalbert.org/resources/

<a id="s16"></a>
### S16: Coherent long-form video generation
**Issuer:** Google Research · **Date:** 2026-09-24 · **Type:** research report.
Research on multi-agent world-state and continuity; performance claims require external replication.  
**URL:** https://research.google/blog/coherent-long-form-video-generation/

<a id="s17"></a>
### S17: Generative AI for Film Creation survey
**Issuer:** arXiv preprint by Zhang et al. · **Date:** 2025-04-11 · **Type:** research survey.
Maps generative filmmaking uses and problems in consistency, controllability and editing.  
**URL:** https://arxiv.org/abs/2504.08296

<a id="s18"></a>
### S18: Relightable Gaussian Splatting for VP
**Issuer:** arXiv preprint by Azzarelli et al. · **Date:** 2026-05-09 · **Type:** research preprint.
Prototype study with limited task and data scope; not proof of general production maturity.  
**URL:** https://arxiv.org/abs/2605.09024

<a id="s19"></a>
### S19: European cinema attendance estimates
**Issuer:** European Audiovisual Observatory · **Date:** 2026-02-13 · **Type:** market report.
Preliminary 2025 European admissions estimate; contextual, not a global market forecast.  
**URL:** https://www.obs.coe.int/en/web/observatoire/-/european-cinema-attendance-dropped-by-5.5-in-2025-with-stable-box-office-figures

<a id="s20"></a>
### S20: 2026 Sci-Tech investigative areas
**Issuer:** Academy of Motion Picture Arts and Sciences · **Date:** 2026-08-20 · **Type:** research/industry signal.
Investigative agenda shows technical interests; does not certify particular technologies.  
**URL:** https://press.oscars.org/news/academy-investigates-six-scientific-and-technical-areas-2026-awards-consideration

<a id="s21"></a>
### S21: Academy Scientific and Technical Awards 2026
**Issuer:** Academy of Motion Picture Arts and Sciences · **Date:** 2026-04-28 · **Type:** industry recognition.
Technical awards spanning stop motion, audio and lighting; evidence of hybrid innovation.  
**URL:** https://www.oscars.org/sci-tech/ceremonies/2026

<a id="s22"></a>
### S22: MovieLabs ontology overview
**Issuer:** MovieLabs · **Date:** 2026 · **Type:** industry architecture.
Why consistent names and relationships support software interoperability.  
**URL:** https://movielabs.org/ontology-for-media-creation/

<a id="s23"></a>
### S23: MotionPhys: physical consistency detection
**Issuer:** arXiv preprint by He et al. · **Date:** 2026-08-21 · **Type:** research preprint.
Identifies physics-consistency failures in sampled generated clips; limited evaluation context.  
**URL:** https://arxiv.org/abs/2608.20770

<a id="s24"></a>
### S24: VideoScience-Bench
**Issuer:** arXiv preprint by Hu et al. · **Date:** 2025-12-02 · **Type:** research benchmark.
Tests scientific/physical reasoning in video generation under defined evaluation conditions.  
**URL:** https://arxiv.org/abs/2512.02942

<a id="s25"></a>
### S25: SMPTE journal: LED color management
**Issuer:** SMPTE Motion Imaging Journal · **Date:** 2025 · **Type:** peer-reviewed/technical article.
Technical treatment of color consistency in LED virtual production.  
**URL:** https://journal.smpte.org/periodicals/SMPTE%20Motion%20Imaging%20Journal/134/2/17/
