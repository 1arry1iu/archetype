# THE RESEARCH KNOWLEDGE ATLAS

**Frontier edition | As of 2026-10-17**

> A navigable map of disciplines, research methods, demonstrated capabilities, bottlenecks, cross-domain bridges, and important unanswered questions.

**Editorial scope.** Global, cross-disciplinary. Curated, illustrative and non-systematic: not a systematic review, funding ranking or probability forecast.

**How to read the map.** Field cards are curated coordinates, not field grades. A frontier claim is tied to one or more source identifiers. Questions and tests are editorial research hypotheses, not quotations from sources.

## The central thesis

The consequential frontier is increasingly an *interface frontier*: AI with experiment; genomic sequence with function; quantum devices with error correction; climate observation with resilience; institutional design with technology deployment; and open metadata with reproducibility. Strong progress in one component does not settle validity, scale, safety or distributional impact in the entire system.

## Navigator

- [Epistemic compass](#epistemic-compass) · [14 fields](#the-14-field-constellations) · [14 bridges](#cross-domain-bridges) · [Method selection](#method-selection-table) · [Research operating system](#research-operating-system) · [Portfolio](#portfolio-of-research-investments) · [Sources](#verified-source-registry)

## Epistemic compass

Research becomes reliable by tracking the relationship **question → claim → measurement → evidence → alternative explanations → replication → scope → decision**. Each stage can fail independently.

- **Established.** Strong convergent evidence within known scope; still conditional on assumptions.
- **Demonstrated.** A capability/phenomenon shown in a defined setting; scalability or generality unproven.
- **Provisional.** Promising evidence with major validation or boundary gaps.
- **Contested.** Meaningful competing models, methods or results; do not assert equivalence of evidence.
- **Speculative.** Coherent possible mechanism or direction without adequate empirical testing.
- **Unknown.** Question lacks decisive measurement, model or tractable discriminating test.

The atlas applies *capability-specific* descriptors (“demonstrated on constrained hardware”, “contested interpretation”) rather than pretending to assign field-wide numerical confidence.

### Eight invariants of credible frontier work

01. **Distinguish claims from evidence:** Every important proposition should point to a method, measurement, source and scope.
02. **Classify epistemic status, not popularity:** Use established / demonstrated / provisional / contested / speculative / unknown; avoid numeric confidence without a model.
03. **Separate prediction from causal explanation:** High accuracy does not prove mechanism, intervention benefit or out-of-domain transfer.
04. **Prefer independent convergence:** Replication across teams, modalities and settings is stronger than repeated citations to the same result.
05. **Expose the denominator:** Check missing studies, excluded populations, negative results and unindexed languages.
06. **Measure systems, not only components:** Scale-up requires costs, safety, human behavior, supply chains and environments.
07. **Respect legitimate closure:** Open when possible; protect privacy, rights, sensitive data and affected communities.
08. **Keep the map revisable:** Record an as-of date, updates, disputed claims, failure modes and superseded evidence.

## The 14 field constellations

### D01 · Mathematics, logic & statistics

**Foundations** — The formal grammar of inference: proofs, uncertainty, algorithms, identification and explanation.

**Established baseline.** Formal proof gives conditional certainty once axioms and derivations are correct; statistical inference addresses uncertainty arising from sampling, models and measurement.

**Research frontier.**

- **Machine-assisted formal reasoning** *(active frontier).* Proof assistants and AI-guided conjecture or proof search may widen verifiable mathematics; full reliability requires independent formal checking. [S09](#ref-s09)
- **Causal identification and robust inference** *(active frontier).* Research increasingly treats identification, transportability, multiple testing and model dependence as first-class problems, not afterthoughts. [S01](#ref-s01) [S04](#ref-s04)
- **Uncertainty-aware scientific ML** *(open problem).* Calibrated uncertainty under distribution shift remains a fundamental bridge between pattern recognition and scientific use. [S10](#ref-s10)

**Four high-value unknowns.**

1. How do we reliably formalize informal mathematical insight?
2. Which causal effects are identifiable under realistic data-generating assumptions?
3. How do we validate generalization to new regimes rather than new random splits?
4. How can statistical guarantees survive adaptive, AI-assisted exploration?

**Primary toolkits.** Formal proof and counterexample · Bayesian/frequentist inference · Causal graphical models · Sensitivity analysis
**Principal bottleneck.** Convenient proxies and benchmark success are regularly mistaken for theorem-level or out-of-distribution guarantees.
**Discriminating next test.** Pre-register a clear estimand or theorem; test against adversarial counterexamples, negative controls and external shifts.
**Linked constellations.** D07, D11, D14

### D02 · Physics, quantum science & cosmology

**Physical sciences & cosmos** — Precision instruments confront foundational unknowns in matter, spacetime and quantum information.

**Established baseline.** The Standard Model and general relativity are highly successful in tested domains, but do not constitute a complete theory of the universe.

**Research frontier.**

- **Below-threshold quantum error correction** *(demonstrated in constrained hardware).* Superconducting surface-code memories have shown suppression of logical error with code distance; utility-scale fault tolerance remains to be demonstrated. [S15](#ref-s15)
- **Dark energy dynamics** *(contested interpretation).* DESI distance measurements sharpen constraints and have motivated evolving-dark-energy fits when combined with other datasets, but they do not settle the underlying physics. [S14](#ref-s14)
- **Wide-field dark-universe surveys** *(demonstrated data infrastructure).* Euclid is releasing large survey datasets with lensing and galaxy information, increasing statistical power and systematic-control demands. [S16](#ref-s16)

**Four high-value unknowns.**

1. Is dark energy a constant, an evolving field or a symptom of incomplete gravity?
2. What is the practical overhead of useful error-corrected quantum computation?
3. What physics lies beyond the Standard Model?
4. Which astrophysical anomalies survive independent instruments and calibrations?

**Primary toolkits.** Precision measurement · Collider and quantum experiments · Cosmological surveys · Statistical model comparison
**Principal bottleneck.** Small systematic biases can dominate unprecedented data volumes; laboratory milestones are not industrial scalability.
**Discriminating next test.** Independent survey cross-checks and sustained logical-qubit operation on useful tasks with full resource accounting.
**Linked constellations.** D01, D03, D07

### D03 · Chemistry & materials discovery

**Physical sciences & cosmos** — From molecular control to deployable function: discovery is increasingly an instrument-and-synthesis problem.

**Established baseline.** Chemical kinetics, thermodynamics and structure–property relations enable powerful prediction, but synthesis routes and operating environments govern usable performance.

**Research frontier.**

- **Self-driving laboratories** *(demonstrated, limited scope).* Closed-loop combinations of robotics, optimization and measurement now exist; generality, provenance and safe operation remain active research questions. [S17](#ref-s17) [S29](#ref-s29)
- **Machine-learned materials candidates** *(active frontier).* Models search enormous compositional spaces faster than manual screening, but experimental reproducibility and manufacturability filter predictions. [S17](#ref-s17)
- **Catalysts and circular materials** *(open problem).* Selectivity, longevity, low-energy manufacturing and recycling are coupled objectives with incomplete measurement standards. [S18](#ref-s18)

**Four high-value unknowns.**

1. Can autonomous labs generalize beyond tightly engineered reaction families?
2. Which candidate materials maintain properties over years in field conditions?
3. How can mechanistic and data-driven models jointly optimize synthesis?
4. What is the life-cycle cost and resource burden of novel materials?

**Primary toolkits.** Synthesis and characterization · Active learning · High-throughput experimentation · Life-cycle assessment
**Principal bottleneck.** Converting a simulated or benchtop discovery into safe, reproducible, high-yield manufacture.
**Discriminating next test.** Run blinded inter-laboratory syntheses with full protocols, impurity assays and life-cycle measurements.
**Linked constellations.** D02, D07, D08

### D04 · Genomics, cells & synthetic biology

**Living systems** — Move from reading biological sequences to explaining, predicting and safely controlling function.

**Established baseline.** DNA sequence, gene regulation and cell state are coupled by context-dependent biophysical and regulatory mechanisms.

**Research frontier.**

- **Multimodal sequence-to-function models** *(demonstrated benchmarks).* AlphaGenome predicts diverse genomic signals and variant effects from long DNA context; computational prediction is not synonymous with clinical validity. [S12](#ref-s12)
- **Integrated single-cell and spatial atlases** *(active frontier).* Cross-modal atlases reveal cellular diversity, but harmonizing annotations, developmental trajectories and populations is unfinished. [S13](#ref-s13)
- **Programmable biological systems** *(open problem).* Designing predictable, evolutionarily robust circuits and tissues remains much harder than editing their components. [S12](#ref-s12)

**Four high-value unknowns.**

1. Can variant-effect predictions generalize across ancestry, cell type and disease context?
2. What multi-scale mechanisms connect sequence to phenotype?
3. How do engineered organisms behave across long periods and uncontrolled ecologies?
4. Which mechanistic claims survive perturbation experiments?

**Primary toolkits.** CRISPR perturbation screens · Single-cell and spatial omics · Functional assays · Mechanistic simulations
**Principal bottleneck.** Context dependence and incomplete ground truth create large gaps between predicted and observed function.
**Discriminating next test.** Independent perturbation assays on held-out genes, tissues, ancestries and environments, with measured off-target effects.
**Linked constellations.** D05, D06, D07

### D05 · Medicine & population health

**Living systems** — Turn biological understanding into safe, equitable health gains with rigorous evaluation.

**Established baseline.** Clinical decisions require evidence of patient-relevant benefit and harm; biological plausibility and algorithm accuracy alone are insufficient.

**Research frontier.**

- **Antimicrobial resistance surveillance** *(established need / active measurement).* WHO GLASS aggregates multi-country resistance evidence and highlights coverage and completeness constraints. [S23](#ref-s23)
- **AI-assisted diagnosis and care** *(active translation frontier).* Clinical AI models may aid workflows, but external validation, workflow studies, calibration and safety monitoring determine real-world benefit. [S09](#ref-s09) [S10](#ref-s10)
- **Precision and preventive medicine** *(active frontier).* Genomics and longitudinal data create opportunities for targeted interventions, with large issues of equity, effect heterogeneity and evidence thresholds. [S12](#ref-s12) [S24](#ref-s24)

**Four high-value unknowns.**

1. Which interventions improve morbidity and mortality in underserved settings?
2. How do AI tools change clinician behavior and patient outcomes over time?
3. Which AMR interventions work across hospital and community contexts?
4. How can privacy-preserving studies represent neglected populations?

**Primary toolkits.** Randomized and pragmatic trials · Cohort and surveillance studies · Implementation science · Systematic review
**Principal bottleneck.** External validity, incentives, missing outcomes and unequal access often dominate headline model performance.
**Discriminating next test.** Prospective controlled, multi-site evaluation with pre-specified patient outcomes, safety endpoints and equity stratification.
**Linked constellations.** D04, D10, D11

### D06 · Neuroscience, cognition & behavior

**Living systems** — Connect molecular and circuit maps to computation, experience, learning and human function.

**Established baseline.** Brain structure is not the same thing as brain function; behavior emerges across cells, circuits, bodies, development and social contexts.

**Research frontier.**

- **Multi-species brain-cell reference atlases** *(active infrastructure).* NIH BICAN is developing molecular and anatomical cell atlases emphasizing humans and cross-species alignment. [S13](#ref-s13)
- **Connectomic reconstruction** *(demonstrated partial maps).* Dense circuit mapping is advancing, but synaptic diagrams alone do not predict cognition or subjective experience. [S13](#ref-s13)
- **Brain–AI comparisons** *(exploratory).* Comparing representation and learning in artificial and biological networks creates hypotheses, not automatic equivalence. [S09](#ref-s09) [S13](#ref-s13)

**Four high-value unknowns.**

1. How do cell-type, connectivity and dynamics combine to generate behavior?
2. Which neural signatures generalize across people and tasks?
3. Can interventions change symptoms without damaging agency or privacy?
4. What explanatory status should be given to theories of consciousness?

**Primary toolkits.** Causal neural perturbation · Longitudinal behavior measurement · Imaging and electrophysiology · Computational modeling
**Principal bottleneck.** Ambiguous measurement proxies and species-to-human transfer can overstate mechanistic explanations.
**Discriminating next test.** Replicate circuit-to-behavior predictions across species and contexts, using intervention rather than correlation alone.
**Linked constellations.** D04, D07, D12

### D07 · Artificial intelligence & computer science

**Computation & engineering** — A fast-moving capability frontier whose core bottleneck is increasingly credible evaluation under real conditions.

**Established baseline.** AI systems have demonstrated major advances in multimodal pattern processing and scientific assistance; benchmark scores are conditional on test design.

**Research frontier.**

- **Frontier model capability growth** *(demonstrated on benchmarks).* Stanford AI Index 2026 documents rapid performance changes alongside concentration of frontier model creation and measurement gaps. [S09](#ref-s09)
- **Agentic and embodied systems** *(active frontier).* Planning, tool use and autonomy create opportunities, but reliability, control and robustness remain task- and environment-dependent. [S09](#ref-s09) [S10](#ref-s10)
- **AI for scientific discovery** *(active frontier).* Learning systems connect to protein/genomic models, simulations and labs; claims of discovery need independent empirical validation. [S12](#ref-s12) [S17](#ref-s17)

**Four high-value unknowns.**

1. Can models produce reliable, auditable scientific hypotheses with verified provenance?
2. What evaluations detect failure under distribution shift or adversarial pressure?
3. How can mechanistic interpretability and runtime monitoring improve assurance?
4. Who benefits and who bears costs from infrastructure concentration?

**Primary toolkits.** Benchmark and stress testing · Ablation and causal intervention · Formal verification · Human-factors studies
**Principal bottleneck.** Saturated benchmarks, data leakage, opaque training and weak third-party testing reduce confidence in headline scores.
**Discriminating next test.** Frozen unseen test suites, independent audits and real-world longitudinal field trials with documented failure modes.
**Linked constellations.** D01, D03, D12

### D08 · Robotics, energy & built systems

**Computation & engineering** — The physical test of innovation is safe, reliable performance under resource and infrastructure constraints.

**Established baseline.** Robotic and energy systems are cyber-physical: sensors, control, materials, economics, human factors and safety cannot be evaluated separately.

**Research frontier.**

- **Autonomous experimentation and production** *(demonstrated partial integration).* Self-driving labs illustrate closed-loop physical automation while highlighting provenance, scale and laboratory safety gaps. [S17](#ref-s17) [S29](#ref-s29)
- **Clean-energy manufacturing and supply chains** *(active deployment transition).* IEA 2026 tracks fast technology deployment along with trade, manufacturing concentration and supply-chain exposure. [S18](#ref-s18)
- **Fusion plant engineering** *(exploratory scale-up).* Fusion progress must be evaluated against fuel-cycle, materials, maintenance, safety and systems engineering constraints. [S30](#ref-s30)

**Four high-value unknowns.**

1. Can embodied systems maintain safety after uncommon sensor, weather or component failures?
2. Which power technologies minimize total system cost and critical-material dependence?
3. Can fusion concepts meet integrated plant-level reliability constraints?
4. How are automation benefits and harms distributed across workers?

**Primary toolkits.** Hardware-in-the-loop trials · Reliability engineering · Energy systems optimization · Life-cycle and supply-chain analysis
**Principal bottleneck.** Testbed success can obscure operational maintenance, interfaces, rare failures and costs.
**Discriminating next test.** Full-stack pilots with measured uptime, accidents, human workload, cost and energy use over operationally meaningful periods.
**Linked constellations.** D03, D09, D11

### D09 · Climate, oceans & Earth observation

**Planetary systems** — The frontier joins physical forecasting, risk attribution, resilience and decisions across scales.

**Established baseline.** Human-caused warming is established; exact local impacts, compound hazards and adaptation outcomes remain highly context-dependent.

**Research frontier.**

- **Earth energy imbalance and ocean heat** *(well-observed trend).* WMO 2026 synthesizes records documenting sustained warming, ocean heat accumulation and extremes. [S19](#ref-s19)
- **Climate risk at decision scales** *(active frontier).* Downscaling, early warning and compound-event models must quantify uncertainty and prove usefulness to users. [S19](#ref-s19) [S20](#ref-s20)
- **Integrated adaptation and mitigation pathways** *(open implementation challenge).* Physical interventions interact with institutions, inequality, biodiversity and land use. [S20](#ref-s20) [S21](#ref-s21)

**Four high-value unknowns.**

1. Which compound extremes exceed infrastructure design assumptions?
2. How credible are kilometer-scale local projections in data-poor regions?
3. What adaptation programs reduce measured mortality and losses?
4. How should interventions be robust to deep uncertainty?

**Primary toolkits.** Remote sensing · Earth system and ensemble modeling · Event attribution · Impact evaluation
**Principal bottleneck.** Nonstationarity and incomplete local exposure and vulnerability records obstruct trustworthy risk prediction.
**Discriminating next test.** Prospective warning-system trials and out-of-period hindcasts with local loss and equity outcomes.
**Linked constellations.** D08, D10, D11

### D10 · Biodiversity, food, water & ecosystems

**Planetary systems** — A coupled nexus: interventions in one ecological sector propagate to others.

**Established baseline.** Ecosystems influence food, freshwater and health; causal effects depend on geography, feedback loops and governance.

**Research frontier.**

- **Biodiversity–water–food–health nexus** *(established systems framing).* IPBES Nexus Assessment integrates cross-sector pressures, dependencies and governance options. [S21](#ref-s21)
- **Food security under multiple shocks** *(well-evidenced challenge).* FAO-led assessments link affordability, food systems and nutrition; models must account for political and economic dynamics. [S22](#ref-s22)
- **Ecological prediction and monitoring** *(active frontier).* Remote sensing and environmental DNA can improve coverage but require field validation and legitimate local stewardship. [S21](#ref-s21) [S27](#ref-s27)

**Four high-value unknowns.**

1. Which ecosystem interventions generate net benefits across biodiversity, water and diets?
2. Can regional early warning forecast cascading ecological failures?
3. What are meaningful and just restoration success measures?
4. How should local and Indigenous knowledge govern research questions and data?

**Primary toolkits.** Long-term field ecology · Spatial monitoring and remote sensing · Participatory research · Systems dynamics
**Principal bottleneck.** Short observation windows and sector-by-sector accounting hide spillovers and distributional harms.
**Discriminating next test.** Matched watershed/landscape evaluations with biodiversity, water, health, cost and community-governance indicators.
**Linked constellations.** D05, D09, D13

### D11 · Economics, development & institutions

**Human systems** — Study not only what works, but for whom, through which mechanism, at what scale and cost.

**Established baseline.** Human outcomes are shaped by institutions, incentives, history and markets; causal estimates often vary across settings.

**Research frontier.**

- **AI diffusion and development** *(active policy frontier).* World Bank WDR 2026 emphasizes locally adapted AI, infrastructure and institutions rather than frontier-model ownership alone. [S11](#ref-s11)
- **Standards as productive infrastructure** *(established institutional mechanism).* World Bank WDR 2025 argues that technical standards lower coordination and interoperability frictions. [S32](#ref-s32)
- **Distributional technology impacts** *(open measurement problem).* Assessing job tasks, earnings and institutional capacity requires longitudinal data, heterogeneity analysis and policy context. [S11](#ref-s11)

**Four high-value unknowns.**

1. Which interventions still work when generalized beyond original study sites?
2. Can productivity gains be shared without locking countries into suppliers?
3. What are the long-run consequences of institutional and data standards?
4. How do shocks interact with household and firm adaptation?

**Primary toolkits.** Randomized policy experiments · Natural experiments · Structural and agent-based models · Administrative data analysis
**Principal bottleneck.** Equilibrium responses, spillovers and selection threaten transportability from pilots to economies.
**Discriminating next test.** Replicate causal estimates with policy rollouts, distributional endpoints and independently specified mechanisms.
**Linked constellations.** D07, D09, D12

### D12 · Society, governance & public trust

**Human systems** — Legitimacy, coordination, institutions and lived experience are research objects—not residual variables.

**Established baseline.** Public preferences and trust are conditional on context, institutions, identity, informational environments and measurement design.

**Research frontier.**

- **Comparable institutional trust measurement** *(demonstrated survey infrastructure).* OECD trust surveys provide documented questionnaires and methodological resources for comparative analysis. [S28](#ref-s28)
- **AI governance in practice** *(active frontier).* AI accountability requires observability, procurement rules, verification and redress beyond abstract principles. [S10](#ref-s10) [S11](#ref-s11)
- **Participatory knowledge production** *(active methodological shift).* Affected communities increasingly shape research design, validity and data governance. [S07](#ref-s07) [S27](#ref-s27)

**Four high-value unknowns.**

1. Which interventions strengthen legitimate institutions without compromising rights?
2. How do digital media and AI affect beliefs, power and social coordination?
3. Which survey concepts remain comparable across cultures?
4. What does meaningful community consent require in different settings?

**Primary toolkits.** Survey experiments · Ethnography and interviews · Comparative institutional analysis · Participatory action research
**Principal bottleneck.** Construct validity, social desirability, power asymmetry and nonrepresentative samples.
**Discriminating next test.** Pre-specified mixed-method validation across social contexts, plus co-designed governance and independent oversight.
**Linked constellations.** D06, D11, D13

### D13 · Language, culture, history & interpretation

**Human systems** — Human knowledge includes meaning, memory, norms, archives and narratives that resist reduction to a single metric.

**Established baseline.** Historical and interpretive claims depend on source criticism, context and transparent inferential paths, not only quantitative fit.

**Research frontier.**

- **Digitization and computational humanities** *(active enabling frontier).* OCR, multilingual NLP and linked archives widen access but can encode omission and colonial cataloguing biases. [S07](#ref-s07) [S08](#ref-s08)
- **Knowledge sovereignty** *(established ethical framework).* CARE principles complement FAIR by centering collective benefit, authority to control, responsibility and ethics. [S27](#ref-s27)
- **Multilingual research discovery** *(open problem).* Bibliographic indexes and language models can improve discovery while underrepresenting scholarship outside dominant languages. [S08](#ref-s08) [S31](#ref-s31)

**Four high-value unknowns.**

1. How can interpretation be audited without erasing ambiguity?
2. Which cultures and languages are systematically invisible to research indexes?
3. How can AI assist archival interpretation without fabricating historical evidence?
4. Who has authority to collect, describe and publish cultural data?

**Primary toolkits.** Archival criticism · Comparative and historical methods · Corpus linguistics · Community-led oral-history research
**Principal bottleneck.** Source selection, translation loss, decontextualization and uneven institutional archives.
**Discriminating next test.** Multilingual archival cross-checks with expert/community review, documented metadata choices and alternative interpretations.
**Linked constellations.** D10, D12, D14

### D14 · Metascience, evidence & research infrastructure

**Knowledge systems** — The research system itself must be measured, reproduced, governed and redesigned.

**Established baseline.** Research outputs are neither automatically valid nor complete: incentives, methods, selection and access shape the visible record.

**Research frontier.**

- **Open scholarly knowledge graphs** *(operational infrastructure).* OpenAlex and Crossref expose large structured scholarly metadata, while coverage and classification errors remain material. [S08](#ref-s08) [S26](#ref-s26) [S31](#ref-s31)
- **Verification-centered openness** *(active reform).* TOP guidelines, reproducibility frameworks, FAIR and reporting standards push from sharing artifacts toward verifiable claims. [S01](#ref-s01) [S02](#ref-s02) [S03](#ref-s03) [S04](#ref-s04) [S05](#ref-s05)
- **Open science policy and equitable governance** *(active implementation).* UNESCO monitoring and CARE principles show openness also requires rights, benefits, capacity and appropriate restrictions. [S07](#ref-s07) [S27](#ref-s27)

**Four high-value unknowns.**

1. How can we measure scientific progress rather than publication volume?
2. Which interventions measurably reduce non-reproducibility and reporting bias?
3. What source graph captures evidence dependencies and contradiction?
4. Can AI literature synthesis remain auditable amid corpus expansion?

**Primary toolkits.** Meta-research · Bibliometrics with coverage audits · Replication studies · Knowledge-graph engineering
**Principal bottleneck.** Citation counts, indexing coverage and AI-generated summaries are easy to mistake for epistemic strength.
**Discriminating next test.** Audit claims back to independently retrieved sources and reproducible data/code; sample out-of-index and negative findings.
**Linked constellations.** D01, D07, D13

## Cross-domain bridges

These 14 bridges represent **editorial hypotheses about where interdisciplinary research could yield unusually high learning value**, not ranked predictions.

### X01 · AI × experimental chemistry (D07 ↔ D03)

**Question.** Can closed-loop lab systems discover *reproducibly*, not merely optimize a recorded proxy?
**Limiting interface.** Generalization to new chemistries, safety, provenance.
**Discriminating evidence.** Independent lab transfer with traceable samples. [S17](#ref-s17) [S29](#ref-s29)

### X02 · Genome models × patient outcomes (D04 ↔ D05)

**Question.** Do predicted variant effects change decisions and patient-relevant outcomes?
**Limiting interface.** Biological context, ancestry diversity and prospective validation.
**Discriminating evidence.** Perturbation-to-clinic validation chain. [S12](#ref-s12) [S24](#ref-s24)

### X03 · Brain atlases × learning theory (D06 ↔ D07)

**Question.** Can circuit-level models predict new behaviors rather than just describe anatomy?
**Limiting interface.** Scale mismatch, interventions and representational ambiguity.
**Discriminating evidence.** Blind held-out behavioral prediction. [S13](#ref-s13) [S09](#ref-s09)

### X04 · Quantum hardware × materials (D02 ↔ D03)

**Question.** Can lower error rates survive scale, fabrication variation and full-stack integration?
**Limiting interface.** Device noise, correlated errors, cryogenics.
**Discriminating evidence.** Useful algorithm executed with audited logical overhead. [S15](#ref-s15)

### X05 · Cosmic surveys × statistical inference (D02 ↔ D01)

**Question.** Are cosmological tensions new physics or subtle measurement/model effects?
**Limiting interface.** Cross-calibration, model selection and systematics.
**Discriminating evidence.** Independent multi-probe consistency. [S14](#ref-s14) [S16](#ref-s16)

### X06 · Climate risk × infrastructure (D09 ↔ D08)

**Question.** Which investments withstand compound events and future distribution shift?
**Limiting interface.** Local uncertainty, cascading dependencies.
**Discriminating evidence.** Out-of-time stress tests and loss reduction. [S19](#ref-s19) [S18](#ref-s18)

### X07 · One Health × antibiotic resistance (D05 ↔ D10)

**Question.** Can joined human, livestock and environmental surveillance reduce resistance?
**Limiting interface.** Non-comparable sampling and cross-sector incentives.
**Discriminating evidence.** Integrated sentinel interventions over time. [S23](#ref-s23) [S21](#ref-s21)

### X08 · AI × economic development (D07 ↔ D11)

**Question.** How can countries deploy AI without worsening capability and supplier dependence?
**Limiting interface.** Power, connectivity, languages and institutions.
**Discriminating evidence.** Multi-country studies of benefit and distribution. [S11](#ref-s11) [S09](#ref-s09)

### X09 · Open metadata × living evidence (D14 ↔ D01)

**Question.** Can literature graphs preserve contradictory and negative evidence reliably?
**Limiting interface.** Incomplete indexes, versioning and provenance.
**Discriminating evidence.** Blind recall/precision audits across languages. [S08](#ref-s08) [S26](#ref-s26) [S31](#ref-s31)

### X10 · Cultural archives × data governance (D13 ↔ D14)

**Question.** How can searchable collections preserve rights to context, consent and benefit?
**Limiting interface.** Access policies conflict with indiscriminate openness.
**Discriminating evidence.** Community-audited FAIR + CARE workflows. [S27](#ref-s27) [S07](#ref-s07)

### X11 · Food security × climate adaptation (D10 ↔ D09)

**Question.** Which adaptation packages improve both ecosystem and household outcomes?
**Limiting interface.** Multiple interacting shocks and long time lags.
**Discriminating evidence.** Spatial quasi-experiments and participatory follow-up. [S21](#ref-s21) [S22](#ref-s22)

### X12 · Public trust × AI governance (D12 ↔ D07)

**Question.** Which governance choices change trust *and* independently verified system safety?
**Limiting interface.** Survey–behavior divergence, information asymmetry.
**Discriminating evidence.** Audited deployments plus longitudinal social research. [S28](#ref-s28) [S10](#ref-s10)

### X13 · Standards × clean technology (D11 ↔ D08)

**Question.** Can interoperability standards lower clean-technology supply-chain vulnerabilities?
**Limiting interface.** Fragmented regulation and costly transitions.
**Discriminating evidence.** Before/after supply-chain and cost studies. [S32](#ref-s32) [S18](#ref-s18)

### X14 · Social inequality × research infrastructure (D12 ↔ D14)

**Question.** Whose findings never enter searchable, citable scientific records?
**Limiting interface.** Indexing, geography and language exclusions.
**Discriminating evidence.** Coverage audits with local scholar collaboration. [S08](#ref-s08) [S07](#ref-s07)

## Method selection table

Choose designs by the **kind of claim you need to justify**, not by a prestige hierarchy of techniques.

| Research design | Best inferential target | Minimum safeguard | Typical failure |
|:--|:--|:--|:--|
| Formal proof | Logical entailment under assumptions | Verified proof obligations and explicit axioms | A valid proof cannot confirm the empirical truth of its premises. |
| Controlled laboratory experiment | Mechanism or local causal response | Randomization, controls, metrology, replicates | Context and scale may differ from the field. |
| Randomized controlled trial | Average intervention effect in an eligible sample | Allocation integrity, concealment, CONSORT reporting | External validity, attrition and implementation fidelity. |
| Pragmatic / cluster trial | Intervention effects in routine settings | Cluster correlation, implementation monitoring | Contamination, heterogeneous adherence, site selection. |
| Observational cohort / case-control | Associations, risk factors, trajectories | Confounding plan, target trial framing, sensitivity | Selection bias, reverse causality, unmeasured confounders. |
| Natural experiment / quasi-experiment | Causal estimates from policy or event variation | Identification checks, pre-trends, placebo tests | Untestable assumptions, interference, policy endogeneity. |
| Qualitative ethnography | Lived meaning, context, mechanisms, practice | Reflexivity, thick description, triangulation | Transferability cannot be assumed from a few cases. |
| Participatory action research | Jointly defined problems and workable changes | Power and consent audit, reciprocal benefits | Representation and process governance need explicit care. |
| Comparative historical inquiry | Mechanism and context across cases/time | Source criticism, rival narratives, trace evidence | Archive survival and retrospective selection bias. |
| Simulation / digital twin | Conditional system dynamics and counterfactuals | Parameter validation, uncertainty and calibration | A precise simulation can be precisely wrong. |
| Statistical / ML prediction | Out-of-sample predictive performance | Holdout hygiene, calibration, shifts, subgroup tests | Predictive validity is not causal explanation. |
| Remote sensing and spatial modeling | Change and variation across large areas | Ground truth, sensor calibration, sampling frames | Resolution and proxies conceal local reality. |
| Omics / high-dimensional profiling | Patterns and candidate molecular mechanisms | Batch effects, biological replication, orthogonal assays | Multiplicity and correlation masquerading as mechanism. |
| Systematic review / meta-analysis | Body-of-evidence estimates or mapping | Protocol, transparent search, bias and heterogeneity | Pooling biased or incompatible studies does not cure bias. |
| Replication / registered report | Robustness and scope of earlier claims | Independent design, pre-specified endpoints, sufficient power | Differences in population/protocol complicate interpretation. |
| Science-of-science / bibliometrics | Patterns of scholarship and research systems | Index coverage, deduplication, language and field norms | Citation impact is not validity or social importance. |

**Reporting and research-integrity anchors.** CONSORT 2025 for randomized trial reporting [S03](#ref-s03); PRISMA 2020 for systematic review reporting [S02](#ref-s02); TOP transparency and verification [S04](#ref-s04); FAIR and CARE for data stewardship [S05](#ref-s05) [S27](#ref-s27).

## Research operating system

A general protocol for designing, checking and continuously updating a real-world research programme:

1. **Frame.** Define phenomenon, population/system, objective, decision and harm boundaries.
2. **Decompose.** Convert a topic into answerable descriptive, causal, mechanistic, predictive or normative questions.
3. **Map prior knowledge.** Search multiple indexes and local/non-English knowledge; record the search date and exclusions.
4. **Register claims.** Extract individual findings with context, source, method and epistemic status.
5. **Challenge evidence.** Assess selection, measurement, missing data, publication and incentive risks.
6. **Select method.** Choose design for inference target and ethical/operational constraints, not prestige.
7. **Pre-specify.** State outcomes, baselines, alternative hypotheses, stopping rules and failure thresholds.
8. **Collect & compute.** Log provenance, versions, instruments, data governance and environment.
9. **Triangulate.** Compare independent methods, contradictory findings and neglected populations.
10. **Replicate & stress-test.** Vary sites, operators, populations, temporal regimes and measurement pipelines.
11. **Translate.** Specify who benefits, distributional impacts, costs, safety and conditions for use.
12. **Revise.** Version the map, update classifications, retire falsified claims and publish limitations.

### A research claim ledger: minimal fields

`claim_id · proposition · type · field · scope_population · source_id · source_version · publication_date · method · sample_and_setting · measurement · effect_or_finding · uncertainty · conflicting_evidence · replication_status · safety_and_ethics · update_trigger · last_checked`

### A falsification-first project brief

1. Specify **the claim that would change a decision** and its intended context.
2. Name at least two rival explanations and an observation that distinguishes them.
3. Set minimum effect, uncertainty and safety thresholds before observing results.
4. Include a negative control, independent validation or explicit reason one is impossible.
5. Record what would make you **stop, narrow or reject** the project.

## Portfolio of research investments

Priorities are organized as **infrastructure for learning**, not a speculative ranking of hot topics.

### 1. Verification capacity

**Action.** Independent replication funds; held-out evaluation; open protocols; reporting standards.
**Strategic purpose.** Research validity
**How to test progress.** Replication success across independent settings and evidence trace completeness.

### 2. Measurement infrastructure

**Action.** Monitoring, sensors, clinical surveillance, multilingual indexes and ground truth.
**Strategic purpose.** Observability
**How to test progress.** Measurement coverage, accuracy, denominator quality and bias audits.

### 3. Cross-domain integration

**Action.** Human/AI/robotic tools that keep provenance and allow meaningful counterexamples.
**Strategic purpose.** Integration
**How to test progress.** Validated transfer across disciplines, labs and populations.

### 4. Fair participation

**Action.** Community-owned data, local language research and low-resource representation.
**Strategic purpose.** Legitimacy
**How to test progress.** Participation, governance rights and benefit distribution.

### 5. Scale and translation

**Action.** Field trials, total costs, reliability, energy use and supply-chain accounting.
**Strategic purpose.** Deployment reality
**How to test progress.** Real-world outcomes and independently measured harms.

### 6. Risk and dual-use governance

**Action.** Safety-by-design, controlled access where warranted, red-teaming and oversight.
**Strategic purpose.** Safety
**How to test progress.** Measured failure rates and actual effectiveness of controls.

## Frontier monitoring protocol

Review frontier cards quarterly or when a claim-changing event occurs (independent replication, retraction, major dataset release, successful deployment, regulatory intervention or contradictory measurement). For each update log: source publication date, observation date, previous status, new status, reason, independent checks, and who reviewed the change.

Never count more papers or a saturated benchmark as scientific progress without examining robustness, novelty, external validity and downstream effect.

## Limitations, provenance and reuse

**Review method:** Constructed from established research methodology and a targeted October 2026 scan of first-party institutional reports, major assessments, guidelines, and selected peer-reviewed frontier studies. Inclusion was purposive, not exhaustive; no quantitative bibliometric scoring was performed. A citation supports a described development, not every extrapolation or open question inferred from it.

This atlas does not assign probabilistic odds, endorse particular commercial technologies, provide medical advice, or claim exhaustive coverage. First-party reports can have institutional perspective; peer-reviewed papers can have publication bias; bibliographic indexes have omissions; and some open questions cannot be decided on current instruments. The status of a narrow demonstration should not be generalized to a mature technology.

The JSON contains research questions, domain links, bridge edges and source IDs. Every URL is retained in the registry for follow-up verification. The PDF and DOCX are editorial readouts of the same map.

## Verified source registry

Sources were checked for existence and basic relevance during atlas preparation. Original reports and research papers are preferred over news summaries. Years refer to the cited item or selected edition, not always to the underlying data.

<a id='ref-s01'></a>
**S01 — National Academies (2019).** Reproducibility and Replicability in Science. https://www.nationalacademies.org/news/new-report-examines-reproducibility-and-replicability-in-science-recommends-ways-to-improve-transparency-and-rigor-in-research

<a id='ref-s02'></a>
**S02 — PRISMA (2021).** PRISMA 2020 statement and checklist. https://www.prisma-statement.org/prisma-2020

<a id='ref-s03'></a>
**S03 — EQUATOR / CONSORT (2025).** CONSORT 2025 statement: reporting randomized trials. https://www.equator-network.org/reporting-guidelines/consort/

<a id='ref-s04'></a>
**S04 — Center for Open Science (2025).** TOP Guidelines, 2025 update. https://www.cos.io/initiatives/top-guidelines

<a id='ref-s05'></a>
**S05 — GO FAIR (2016).** FAIR Principles: findability, accessibility, interoperability, reusability. https://www.go-fair.org/how-to-go-fair/

<a id='ref-s06'></a>
**S06 — OECD (2025).** Science, Technology and Innovation Outlook 2025. https://www.oecd.org/en/publications/oecd-science-technology-and-innovation-outlook-2025_5fe57b90-en.html

<a id='ref-s07'></a>
**S07 — UNESCO (2025).** First consultation on the Open Science Recommendation. https://www.unesco.org/en/open-science/2025reports

<a id='ref-s08'></a>
**S08 — OpenAlex (2026).** Works Overview and scholarly metadata architecture. https://help.openalex.org/data/works/

<a id='ref-s09'></a>
**S09 — Stanford HAI (2026).** AI Index Report 2026. https://hai.stanford.edu/ai-index/2026-ai-index-report

<a id='ref-s10'></a>
**S10 — NIST (2024).** Generative AI Profile of the AI Risk Management Framework. https://www.nist.gov/publications/artificial-intelligence-risk-management-framework-generative-artificial-intelligence

<a id='ref-s11'></a>
**S11 — World Bank (2026).** World Development Report 2026: The Promise of Artificial Intelligence. https://www.worldbank.org/en/publication/wdr2026

<a id='ref-s12'></a>
**S12 — Avsec et al. / Nature (2026).** Advancing regulatory variant effect prediction with AlphaGenome. https://www.nature.com/articles/s41586-025-10014-0

<a id='ref-s13'></a>
**S13 — NIH BRAIN Initiative (2025–26).** BRAIN Initiative Cell Atlas Network. https://www.nih.gov/brain/research/tools-technologies-brain-cells-circuits/brain-initiative-cell-atlas-network

<a id='ref-s14'></a>
**S14 — DESI Collaboration (2025).** DESI DR2 Results: March 19 guide. https://www.desi.lbl.gov/2025/03/19/desi-dr2-results-march-19-guide/

<a id='ref-s15'></a>
**S15 — Google Quantum AI et al. / Nature (2025).** Quantum error correction below the surface code threshold. https://www.nature.com/articles/s41586-024-08449-y

<a id='ref-s16'></a>
**S16 — European Space Agency (2025).** Euclid opens data treasure trove. https://www.esa.int/Science_Exploration/Space_Science/Euclid/Euclid_opens_data_treasure_trove_offers_glimpse_of_deep_fields

<a id='ref-s17'></a>
**S17 — Canty & Abolhasani / Nature Reviews Chemistry (2026).** The past, present and future of self-driving laboratories. https://www.nature.com/articles/s41570-026-00847-2

<a id='ref-s18'></a>
**S18 — International Energy Agency (2026).** Energy Technology Perspectives 2026. https://www.iea.org/reports/energy-technology-perspectives-2026

<a id='ref-s19'></a>
**S19 — World Meteorological Organization (2026).** State of the Global Climate 2025. https://wmo.int/publication-series/state-of-global-climate/state-of-global-climate-2025

<a id='ref-s20'></a>
**S20 — IPCC (2023).** Sixth Assessment Report: Synthesis Report. https://www.ipcc.ch/report/sixth-assessment-report-cycle/2023/

<a id='ref-s21'></a>
**S21 — IPBES (2024).** Nexus Assessment: biodiversity, water, food and health. https://www.ipbes.net/nexus-assessment

<a id='ref-s22'></a>
**S22 — FAO / IFAD / UNICEF / WFP / WHO (2025).** State of Food Security and Nutrition in the World 2025. https://www.fao.org/agrifood-economics/publications/detail/en/c/1740904/

<a id='ref-s23'></a>
**S23 — World Health Organization (2025).** Global antibiotic resistance surveillance report 2025. https://www.who.int/publications/i/item/9789240116337/

<a id='ref-s24'></a>
**S24 — World Health Organization (2025).** World health statistics 2025. https://www.who.int/publications/i/item/9789240110496

<a id='ref-s25'></a>
**S25 — U.S. National Science Foundation (2026).** Indicators Explorer: science and engineering data. https://www.nsf.gov/sbe/updates/introducing-indicators-explorer-custom-science-engineering

<a id='ref-s26'></a>
**S26 — Crossref (2026 access).** Metadata Retrieval documentation. https://www.crossref.org/documentation/retrieve-metadata/

<a id='ref-s27'></a>
**S27 — Global Indigenous Data Alliance (2020).** CARE Principles for Indigenous Data Governance. https://www.gida-global.org/careprinciples

<a id='ref-s28'></a>
**S28 — OECD (2026).** Trust Survey Data and methodology. https://www.oecd.org/en/data/datasets/oecd-trust-survey-data.html

<a id='ref-s29'></a>
**S29 — Nature Reviews Chemistry (2025).** Steering towards safe self-driving laboratories. https://www.nature.com/articles/s41570-025-00747-x

<a id='ref-s30'></a>
**S30 — International Atomic Energy Agency (2025).** IAEA World Fusion Outlook 2025 / Fusion Portal. https://nucleus.iaea.org/sites/fusionportal/

<a id='ref-s31'></a>
**S31 — OpenAlex (2026).** Topics documentation: research classification. https://help.openalex.org/data/topics/

<a id='ref-s32'></a>
**S32 — World Bank (2025).** World Development Report 2025: Standards for Development. https://www.worldbank.org/en/publication/wdr2025

---

*Atlas version 1.0 · 2026-10-17 · A human-readable and machine-reusable, curated research map.*
