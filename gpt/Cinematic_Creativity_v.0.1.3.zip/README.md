# Cinematic Creativity

A portable Agent Plugins 1.0 skills-only package derived from the user-supplied `Cinematic_Creativity_v.0.0.1.zip`.

## Contents

- `plugin.json` — portable manifest and OpenAI presentation metadata.
- `skills/cinematic_creativity/` — primary creative-direction workflow that routes to six specialist systems.
- `skills/filmmaking/`, `skills/creativity/`, `skills/digital_storytelling/`, `skills/artificial_intelligence/`, `skills/research/`, `skills/systematic_review/` — original specialist knowledge profiles, with valid portable frontmatter.
- `skills/*/agents/openai.yaml` — per-skill interface metadata.
- `skills/*/references/` — original zipped reference bundles plus directly readable knowledge-atlas Markdown where present.
- `assets/` — vector SVG master and high-resolution PNG icons.

## Notes

This is a knowledge-and-workflow plugin, not a video renderer or connected generative media API. No MCP server or API keys are configured. Output production depends on tools separately available in the host environment.

Original research and creative framework content is preserved from the supplied archive. The redundant top-level `skills/research.zip` was omitted because its contents were already present at `skills/research/`; the misplaced Digital Storytelling entry point was relocated to `skills/digital_storytelling/SKILL.md`. No claim of ownership or grant of a new license is made for supplied material.
