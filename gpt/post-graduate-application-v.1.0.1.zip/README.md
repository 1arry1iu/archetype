# Postgraduate Application

**Release:** 1.0.1  
**Metadata reviewed:** 2026-10-18  
**Scope:** One central orchestration skill and 18 specialized skills (19 total).

## Package layout

- Root Agent Plugins 1.0 manifest: `plugin.json`.
- Synchronized compatibility manifest: `.codex-plugin/plugin.json`.
- Core routing instructions: `skills/postgraduate-application/SKILL.md`.
- User-facing core skill metadata: `skills/postgraduate-application/agents/openai.yaml`.
- Each of the 19 skills has a `SKILL.md` and two original ZIP reference resources under its `references/` directory (38 archive files total).
- Primary and composer icons are stored in `assets/`.

## Skill inventory

The 19 named skills are:

- `postgraduate-application` — primary application orchestrator
- `postgraduate-admission`
- `program-fit`
- `postgraduate-application-essay`
- `masters-in-finance-application`
- `career-development`
- `authenticity`
- `narration`
- `differentiation`
- `evidence`
- `impact`
- `potential`
- `strategy`
- `personality-psychology`
- `economics`
- `finance`
- `fintech`
- `accounting`
- `quantitative-analysis`

## Routing and evidence discipline

Use `postgraduate-application` for multi-stage application planning, then engage specialists for admissions eligibility, program fit, writing, funding decisions, career alignment, or subject-matter depth. Route to `masters-in-finance-application` for finance master's applications; combine with the finance, economics, fintech, accounting, and quantitative-analysis specialists when needed.

Treat the skill profiles and ZIP reference resources as analytic support, **not** live admissions data, institution policy, verified acceptance probabilities, legal advice, or permission to act. Verify current requirements, deadlines, costs, visa rules, and scholarships with relevant official sources. Do not invent applicant achievements or replace applicant authorship; secure explicit authorization before external actions.

## Release note

`1.0.1` refreshes plugin descriptions, search keywords, user-facing starter prompts, the core skill's lightweight interface metadata, and the documented skill inventory. No substantive skill instructions, archives, or image assets are altered.
