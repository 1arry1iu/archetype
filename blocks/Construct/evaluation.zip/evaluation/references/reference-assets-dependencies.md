<!-- CONSTRUCT-SKILL-NOTES:BEGIN version=1 -->

## Reference Notes

**Reference scope.** Evidence-grounded assessment of merit, quality, value, effectiveness, impact and accountability.

- Method anchors: program theory and theory of change, OECD DAC evaluation criteria, mixed-methods research, utilization-focused evaluation, causal inference and metaevaluation.
- Measurement anchors: rubric design, indicator validity, sampling quality, counterfactual identification, equity/distributional assessment and sensitivity analysis.
- Evidence rule: keep descriptive results, causal attribution, value judgments and recommendations separately traceable; never treat an index score as value-neutral.

**Reference register convention.** For every cited claim, record source title/author or standards body, edition or release, persistent identifier/URL, access date when online, quoted passage or page/section, claim supported, evidence tier, and known counterevidence. External works mentioned here are **reading leads, not bundled or automatically verified citations**. Resolve authoritative editions before use.

## Assets Notes

**Existing package assets (verified against release `pluginrel_6ad31a9c75dc81918fe03685a5cd24bc`):**

- **Bundled local reference:** none specific to this skill was listed in the current release.
- **Shared branding only:** `assets/construct-icon.png` exists at plugin root. It is not evidence, a skill dataset, or a specialized analysis asset.
- **No other evaluation-specific templates, data files, test corpora, schemas, or visualizations were found in the release file inventory.**

**Recommended assets to develop and validate:**

- **Proposed, not yet bundled:** evaluation questions/criteria/indicators/standards matrix.
- **Proposed, not yet bundled:** theory-of-change and causal-assumption diagram.
- **Proposed, not yet bundled:** evidence register with limitations and stakeholder perspective.
- **Proposed, not yet bundled:** scoring rubric, weighting sensitivities and dissent log.
- **Proposed, not yet bundled:** metaevaluation checklist.

**Asset registration standard.** Every future file should carry purpose, source/creator, provenance, license/consent, version, schema or media type, integrity digest, restrictions, expected consumer, and validation status. Keep examples distinct from normative specifications and empirical datasets. Do not claim a proposed asset exists until it has been bundled and audited.

## Dependencies

**Package/runtime dependencies.** This skill is a Markdown instruction module; no skill-specific executable runtime, package manager dependency, remote API, or MCP tool dependency is declared in the inspected plugin package. Invocation of tools or sources is conditional on access, authorization, and the question being asked.

**Cross-skill reasoning dependencies (invoke selectively, not automatically):**

- `skills/validity/SKILL.md` — measurement and inference fitness; a **conceptual** dependency, not a required code import.
- `skills/judgement/SKILL.md` — synthesize uncertain evidence; a **conceptual** dependency, not a required code import.
- `skills/ranking/SKILL.md` — order when comparative placement is requested; a **conceptual** dependency, not a required code import.
- `skills/priority/SKILL.md` — allocate resources after evaluation; a **conceptual** dependency, not a required code import.
- `skills/model/SKILL.md` — causal program representation; a **conceptual** dependency, not a required code import.

**Handoff contract.** Input: evaluand, stakeholders, criteria, context and evidence. Output: defensible evaluative conclusion, confidence, tradeoffs, dissent, implications and audit trail.

**Dependency rules.** Preserve the ownership boundary between specialist skills; pass a stated purpose, definitions, provenance, constraints and confidence with every handoff. If a required skill, external source, authorization or test environment is unavailable, mark the gap rather than simulating evidence or claiming a test ran.

<!-- CONSTRUCT-SKILL-NOTES:END -->
