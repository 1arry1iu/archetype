<!-- CONSTRUCT-SKILL-NOTES:BEGIN version=1 -->

## Reference Notes

**Reference scope.** Conditional openness of access, transparency, reuse, interoperability, participation and governance.

- Policy anchors: FAIR data principles and CARE principles, open-definition/licensing frameworks, open science guidance, data protection and research ethics.
- Implementation anchors: SPDX identifiers where relevant, access-control models, privacy/security threat assessment, provenance and community stewardship.
- Evidence rule: open availability does not equal legitimate reuse, consent, interoperability or safety; specify audience, conditions, jurisdiction and affected parties.

**Reference register convention.** For every cited claim, record source title/author or standards body, edition or release, persistent identifier/URL, access date when online, quoted passage or page/section, claim supported, evidence tier, and known counterevidence. External works mentioned here are **reading leads, not bundled or automatically verified citations**. Resolve authoritative editions before use.

## Assets Notes

**Existing package assets (verified against release `pluginrel_6ad31a9c75dc81918fe03685a5cd24bc`):**

- **Bundled local reference:** none specific to this skill was listed in the current release.
- **Shared branding only:** `assets/construct-icon.png` exists at plugin root. It is not evidence, a skill dataset, or a specialized analysis asset.
- **No other openness-specific templates, data files, test corpora, schemas, or visualizations were found in the release file inventory.**

**Recommended assets to develop and validate:**

- **Proposed, not yet bundled:** openness decision matrix (what / to whom / for what / when).
- **Proposed, not yet bundled:** rights/license/consent register.
- **Proposed, not yet bundled:** threat, misuse and benefit-impact assessment.
- **Proposed, not yet bundled:** provenance and stewardship manifest.
- **Proposed, not yet bundled:** controlled access and disclosure exception policy.

**Asset registration standard.** Every future file should carry purpose, source/creator, provenance, license/consent, version, schema or media type, integrity digest, restrictions, expected consumer, and validation status. Keep examples distinct from normative specifications and empirical datasets. Do not claim a proposed asset exists until it has been bundled and audited.

## Dependencies

**Package/runtime dependencies.** This skill is a Markdown instruction module; no skill-specific executable runtime, package manager dependency, remote API, or MCP tool dependency is declared in the inspected plugin package. Invocation of tools or sources is conditional on access, authorization, and the question being asked.

**Cross-skill reasoning dependencies (invoke selectively, not automatically):**

- `skills/information/SKILL.md` — access control and source lineage; a **conceptual** dependency, not a required code import.
- `skills/format/SKILL.md` — interoperability; a **conceptual** dependency, not a required code import.
- `skills/evaluation/SKILL.md` — weigh public/private consequences; a **conceptual** dependency, not a required code import.
- `skills/validity/SKILL.md` — test governance claims; a **conceptual** dependency, not a required code import.
- `skills/workflow/SKILL.md` — implement approvals and revocation; a **conceptual** dependency, not a required code import.

**Handoff contract.** Input: assets, rights holders, stakeholders, harms, incentives and jurisdiction. Output: conditional openness policy, licenses/permissions, access routes and audit rules.

**Dependency rules.** Preserve the ownership boundary between specialist skills; pass a stated purpose, definitions, provenance, constraints and confidence with every handoff. If a required skill, external source, authorization or test environment is unavailable, mark the gap rather than simulating evidence or claiming a test ran.

<!-- CONSTRUCT-SKILL-NOTES:END -->
