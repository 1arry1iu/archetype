<!-- CONSTRUCT-SKILL-NOTES:BEGIN version=1 -->

## Reference Notes

**Reference scope.** Purpose-conditioned, evidence-preserving semantic compression and minimum sufficient meaning.

- Theoretical anchors: rate–distortion theory and information bottleneck concepts (as analogies requiring task definition), discourse representation, abstractive summarization evaluation and decision sufficiency.
- Practical anchors: claim–source linkage, exception retention, uncertainty calibration, audience-specific relevance, reversible expansion and human verification.
- Evidence rule: compression quality depends on the recipient task; preserve negations, conditions, exceptions, provenance and action-critical uncertainty even when inconvenient.

**Reference register convention.** For every cited claim, record source title/author or standards body, edition or release, persistent identifier/URL, access date when online, quoted passage or page/section, claim supported, evidence tier, and known counterevidence. External works mentioned here are **reading leads, not bundled or automatically verified citations**. Resolve authoritative editions before use.

## Assets Notes

**Existing package assets (verified against release `pluginrel_6ad31a9c75dc81918fe03685a5cd24bc`):**

- **Bundled local reference:** none specific to this skill was listed in the current release.
- **Shared branding only:** `assets/construct-icon.png` exists at plugin root. It is not evidence, a skill dataset, or a specialized analysis asset.
- **No other gist-specific templates, data files, test corpora, schemas, or visualizations were found in the release file inventory.**

**Recommended assets to develop and validate:**

- **Proposed, not yet bundled:** source-to-gist claim alignment sheet.
- **Proposed, not yet bundled:** semantic-loss budget and must-retain facts/qualifiers checklist.
- **Proposed, not yet bundled:** paired short/expanded output examples.
- **Proposed, not yet bundled:** distortion, omission and hallucination challenge set.

**Asset registration standard.** Every future file should carry purpose, source/creator, provenance, license/consent, version, schema or media type, integrity digest, restrictions, expected consumer, and validation status. Keep examples distinct from normative specifications and empirical datasets. Do not claim a proposed asset exists until it has been bundled and audited.

## Dependencies

**Package/runtime dependencies.** This skill is a Markdown instruction module; no skill-specific executable runtime, package manager dependency, remote API, or MCP tool dependency is declared in the inspected plugin package. Invocation of tools or sources is conditional on access, authorization, and the question being asked.

**Cross-skill reasoning dependencies (invoke selectively, not automatically):**

- `skills/information/SKILL.md` — identify source structure; a **conceptual** dependency, not a required code import.
- `skills/knowledge/SKILL.md` — retain epistemic status; a **conceptual** dependency, not a required code import.
- `skills/judgement/SKILL.md` — preserve decision uncertainty; a **conceptual** dependency, not a required code import.
- `skills/validity/SKILL.md` — test fidelity and sufficiency; a **conceptual** dependency, not a required code import.

**Handoff contract.** Input: source, reader/task, maximum length and loss tolerance. Output: task-sufficient gist, retained qualifiers, source links and omission audit.

**Dependency rules.** Preserve the ownership boundary between specialist skills; pass a stated purpose, definitions, provenance, constraints and confidence with every handoff. If a required skill, external source, authorization or test environment is unavailable, mark the gap rather than simulating evidence or claiming a test ran.

<!-- CONSTRUCT-SKILL-NOTES:END -->
