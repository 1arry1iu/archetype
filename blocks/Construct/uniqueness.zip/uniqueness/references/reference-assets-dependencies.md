<!-- CONSTRUCT-SKILL-NOTES:BEGIN version=1 -->

## Reference Notes

**Reference scope.** One-of-one distinctiveness relative to an explicitly bounded universe and identity criterion.

- Formal anchors: equivalence classes, uniqueness constraints, probabilistic record linkage, novelty/anomaly detection, provenance and identity theory.
- Operational anchors: duplicate search, open-world recognition, threshold/coverage analysis and privacy-preserving entity resolution.
- Evidence rule: distinguish uniqueness from rarity, originality and novelty; always declare comparison universe, observation coverage, temporal window and possibility of unseen duplicates.

**Reference register convention.** For every cited claim, record source title/author or standards body, edition or release, persistent identifier/URL, access date when online, quoted passage or page/section, claim supported, evidence tier, and known counterevidence. External works mentioned here are **reading leads, not bundled or automatically verified citations**. Resolve authoritative editions before use.

## Assets Notes

**Existing package assets (verified against release `pluginrel_6ad31a9c75dc81918fe03685a5cd24bc`):**

- **Bundled local reference:** none specific to this skill was listed in the current release.
- **Shared branding only:** `assets/construct-icon.png` exists at plugin root. It is not evidence, a skill dataset, or a specialized analysis asset.
- **No other uniqueness-specific templates, data files, test corpora, schemas, or visualizations were found in the release file inventory.**

**Recommended assets to develop and validate:**

- **Proposed, not yet bundled:** identity and equivalence-policy specification.
- **Proposed, not yet bundled:** candidate-universe/coverage and resolution register.
- **Proposed, not yet bundled:** duplicate/collision and counterexample challenge set.
- **Proposed, not yet bundled:** uniqueness claim evidence card with update triggers.
- **Proposed, not yet bundled:** re-identification and privacy threat assessment.

**Asset registration standard.** Every future file should carry purpose, source/creator, provenance, license/consent, version, schema or media type, integrity digest, restrictions, expected consumer, and validation status. Keep examples distinct from normative specifications and empirical datasets. Do not claim a proposed asset exists until it has been bundled and audited.

## Dependencies

**Package/runtime dependencies.** This skill is a Markdown instruction module; no skill-specific executable runtime, package manager dependency, remote API, or MCP tool dependency is declared in the inspected plugin package. Invocation of tools or sources is conditional on access, authorization, and the question being asked.

**Cross-skill reasoning dependencies (invoke selectively, not automatically):**

- `skills/difference/SKILL.md` — one-or-more separating features; a **conceptual** dependency, not a required code import.
- `skills/similarity/SKILL.md` — equivalence and matching; a **conceptual** dependency, not a required code import.
- `skills/name/SKILL.md` — identifier policies; a **conceptual** dependency, not a required code import.
- `skills/validity/SKILL.md` — falsification and coverage; a **conceptual** dependency, not a required code import.
- `skills/information/SKILL.md` — provenance and entity graphs; a **conceptual** dependency, not a required code import.

**Handoff contract.** Input: subject, universe, identity criterion and search coverage. Output: qualified uniqueness claim or counterexample, residual uncertainty and protection controls.

**Dependency rules.** Preserve the ownership boundary between specialist skills; pass a stated purpose, definitions, provenance, constraints and confidence with every handoff. If a required skill, external source, authorization or test environment is unavailable, mark the gap rather than simulating evidence or claiming a test ran.

<!-- CONSTRUCT-SKILL-NOTES:END -->
