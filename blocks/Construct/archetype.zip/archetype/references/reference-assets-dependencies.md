<!-- CONSTRUCT-SKILL-NOTES:BEGIN version=1 -->

## Reference Notes

**Reference scope.** Archetypal pattern analysis, symbolic meaning, cultural variation, and comparison without unsupported universality claims.

- Primary interpretive traditions: C. G. Jung's analytical psychology; post-Jungian criticism; comparative mythology; folklore/motif studies; cultural anthropology and hermeneutics.
- Research-method anchors: historical source criticism, emic/etic comparison, narrative analysis, qualitative coding, cross-cultural sampling, construct validation, and rival-explanation testing.
- Evidence rule: label an item as attested motif, interpretation, analogy, hypothesized mechanism, or tested finding; shared resemblance alone does not establish inheritance, diffusion, psychological universality, or causation.

**Reference register convention.** For every cited claim, record source title/author or standards body, edition or release, persistent identifier/URL, access date when online, quoted passage or page/section, claim supported, evidence tier, and known counterevidence. External works mentioned here are **reading leads, not bundled or automatically verified citations**. Resolve authoritative editions before use.

## Assets Notes

**Existing package assets (verified against release `pluginrel_6ad31a9c75dc81918fe03685a5cd24bc`):**

- **Bundled local reference:** none specific to this skill was listed in the current release.
- **Shared branding only:** `assets/construct-icon.png` exists at plugin root. It is not evidence, a skill dataset, or a specialized analysis asset.
- **No other archetype-specific templates, data files, test corpora, schemas, or visualizations were found in the release file inventory.**

**Recommended assets to develop and validate:**

- **Proposed, not yet bundled:** archetype motif registry with source, culture, period, translation, and motif variant.
- **Proposed, not yet bundled:** pattern–instance–context crosswalk and a transparent coding guide.
- **Proposed, not yet bundled:** rival-explanation matrix (diffusion, convergence, common constraints, chance) with disconfirming cases.
- **Proposed, not yet bundled:** consent and representation review for living cultures.

**Asset registration standard.** Every future file should carry purpose, source/creator, provenance, license/consent, version, schema or media type, integrity digest, restrictions, expected consumer, and validation status. Keep examples distinct from normative specifications and empirical datasets. Do not claim a proposed asset exists until it has been bundled and audited.

## Dependencies

**Package/runtime dependencies.** This skill is a Markdown instruction module; no skill-specific executable runtime, package manager dependency, remote API, or MCP tool dependency is declared in the inspected plugin package. Invocation of tools or sources is conditional on access, authorization, and the question being asked.

**Cross-skill reasoning dependencies (invoke selectively, not automatically):**

- `skills/difference/SKILL.md` — discriminate non-equivalent motifs; a **conceptual** dependency, not a required code import.
- `skills/similarity/SKILL.md` — specify valid structural resemblances; a **conceptual** dependency, not a required code import.
- `skills/taxonomy/SKILL.md` — organize motif categories; a **conceptual** dependency, not a required code import.
- `skills/validity/SKILL.md` — qualify cross-cultural and psychological claims; a **conceptual** dependency, not a required code import.
- `skills/construct/SKILL.md` — turn a pattern into a governed fictional or synthetic identity; a **conceptual** dependency, not a required code import.

**Handoff contract.** Input: named corpus, question, context and comparison frame. Output: pattern specification, situated exemplars, alternatives, evidence tiers, uncertainty and representation cautions.

**Dependency rules.** Preserve the ownership boundary between specialist skills; pass a stated purpose, definitions, provenance, constraints and confidence with every handoff. If a required skill, external source, authorization or test environment is unavailable, mark the gap rather than simulating evidence or claiming a test ran.

<!-- CONSTRUCT-SKILL-NOTES:END -->
