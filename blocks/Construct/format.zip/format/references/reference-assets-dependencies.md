<!-- CONSTRUCT-SKILL-NOTES:BEGIN version=1 -->

## Reference Notes

**Reference scope.** Serialization, representational contracts, schema validity, interoperability, accessibility, security and preservation.

- Standards to consult as applicable: IETF RFCs (e.g., URI and media types), W3C specifications, JSON Schema, XML Schema, Unicode standards, MIME registries and archival/preservation standards.
- Technical anchors: syntax versus semantics, canonicalization, schema evolution, version negotiation, content negotiation, round-trip transformation and attack-surface analysis.
- Evidence rule: identify the authoritative specification, exact edition/profile and parser/runtime compatibility; an extension alone does not guarantee conforming content.

**Reference register convention.** For every cited claim, record source title/author or standards body, edition or release, persistent identifier/URL, access date when online, quoted passage or page/section, claim supported, evidence tier, and known counterevidence. External works mentioned here are **reading leads, not bundled or automatically verified citations**. Resolve authoritative editions before use.

## Assets Notes

**Existing package assets (verified against release `pluginrel_6ad31a9c75dc81918fe03685a5cd24bc`):**

- **Bundled local reference:** none specific to this skill was listed in the current release.
- **Shared branding only:** `assets/construct-icon.png` exists at plugin root. It is not evidence, a skill dataset, or a specialized analysis asset.
- **No other format-specific templates, data files, test corpora, schemas, or visualizations were found in the release file inventory.**

**Recommended assets to develop and validate:**

- **Proposed, not yet bundled:** format-selection decision record.
- **Proposed, not yet bundled:** schema/grammar and worked conforming/nonconforming samples.
- **Proposed, not yet bundled:** loss and interoperability test vectors with round-trip expected outputs.
- **Proposed, not yet bundled:** compatibility matrix, versioning policy, preservation manifest.

**Asset registration standard.** Every future file should carry purpose, source/creator, provenance, license/consent, version, schema or media type, integrity digest, restrictions, expected consumer, and validation status. Keep examples distinct from normative specifications and empirical datasets. Do not claim a proposed asset exists until it has been bundled and audited.

## Dependencies

**Package/runtime dependencies.** This skill is a Markdown instruction module; no skill-specific executable runtime, package manager dependency, remote API, or MCP tool dependency is declared in the inspected plugin package. Invocation of tools or sources is conditional on access, authorization, and the question being asked.

**Cross-skill reasoning dependencies (invoke selectively, not automatically):**

- `skills/information/SKILL.md` — define semantics and metadata; a **conceptual** dependency, not a required code import.
- `skills/model/SKILL.md` — separate reality models from encoding; a **conceptual** dependency, not a required code import.
- `skills/validity/SKILL.md` — check conformance and reliability; a **conceptual** dependency, not a required code import.
- `skills/workflow/SKILL.md` — integrate conversion and migration steps; a **conceptual** dependency, not a required code import.

**Handoff contract.** Input: semantic objects, consumers, platform limits and retention requirements. Output: versioned representation contract, tests, threat model and migration path.

**Dependency rules.** Preserve the ownership boundary between specialist skills; pass a stated purpose, definitions, provenance, constraints and confidence with every handoff. If a required skill, external source, authorization or test environment is unavailable, mark the gap rather than simulating evidence or claiming a test ran.

<!-- CONSTRUCT-SKILL-NOTES:END -->
