<!-- CONSTRUCT-SKILL-NOTES:BEGIN version=1 -->

## Reference Notes

**Reference scope.** Reusable maintained categorization, controlled vocabularies, facets, concept hierarchies and semantic interoperability.

- Standards anchors: W3C SKOS, OWL 2 and RDF; ISO 25964 for thesauri when relevant; data modeling and controlled-vocabulary governance.
- Research anchors: knowledge organization, ontology engineering, concept analysis, faceted classification, multilingual terminology and classification fairness.
- Evidence rule: separate class–subclass, instance–class, part–whole, topic and associative relations; do not assume that practical facets are universal natural kinds.

**Reference register convention.** For every cited claim, record source title/author or standards body, edition or release, persistent identifier/URL, access date when online, quoted passage or page/section, claim supported, evidence tier, and known counterevidence. External works mentioned here are **reading leads, not bundled or automatically verified citations**. Resolve authoritative editions before use.

## Assets Notes

**Existing package assets (verified against release `pluginrel_6ad31a9c75dc81918fe03685a5cd24bc`):**

- **Bundled local reference:** none specific to this skill was listed in the current release.
- **Shared branding only:** `assets/construct-icon.png` exists at plugin root. It is not evidence, a skill dataset, or a specialized analysis asset.
- **No other taxonomy-specific templates, data files, test corpora, schemas, or visualizations were found in the release file inventory.**

**Recommended assets to develop and validate:**

- **Proposed, not yet bundled:** concept register (URI, preferred label, alt labels, definition, scope).
- **Proposed, not yet bundled:** hierarchy and relation-integrity tests.
- **Proposed, not yet bundled:** facet constraints and example annotations.
- **Proposed, not yet bundled:** crosswalk/mapping with match confidence and provenance.
- **Proposed, not yet bundled:** change/deprecation/impact ledger.

**Asset registration standard.** Every future file should carry purpose, source/creator, provenance, license/consent, version, schema or media type, integrity digest, restrictions, expected consumer, and validation status. Keep examples distinct from normative specifications and empirical datasets. Do not claim a proposed asset exists until it has been bundled and audited.

## Dependencies

**Package/runtime dependencies.** This skill is a Markdown instruction module; no skill-specific executable runtime, package manager dependency, remote API, or MCP tool dependency is declared in the inspected plugin package. Invocation of tools or sources is conditional on access, authorization, and the question being asked.

**Cross-skill reasoning dependencies (invoke selectively, not automatically):**

- `skills/name/SKILL.md` — stable labels and identifiers; a **conceptual** dependency, not a required code import.
- `skills/difference/SKILL.md` — category boundary criteria; a **conceptual** dependency, not a required code import.
- `skills/similarity/SKILL.md` — mapping across schemes; a **conceptual** dependency, not a required code import.
- `skills/information/SKILL.md` — metadata/retrieval architecture; a **conceptual** dependency, not a required code import.
- `skills/validity/SKILL.md` — semantic correctness and consistency; a **conceptual** dependency, not a required code import.

**Handoff contract.** Input: domain, entities, use cases and maintenance authority. Output: versioned classification scheme with concept definitions, links, mappings, tests and governance.

**Dependency rules.** Preserve the ownership boundary between specialist skills; pass a stated purpose, definitions, provenance, constraints and confidence with every handoff. If a required skill, external source, authorization or test environment is unavailable, mark the gap rather than simulating evidence or claiming a test ran.

<!-- CONSTRUCT-SKILL-NOTES:END -->
