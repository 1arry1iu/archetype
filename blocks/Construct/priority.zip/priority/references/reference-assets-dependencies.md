<!-- CONSTRUCT-SKILL-NOTES:BEGIN version=1 -->

## Reference Notes

**Reference scope.** Consequential resource allocation, triage, precedence and sequencing under constraints.

- Decision anchors: value-focused thinking and multicriteria decision analysis, expected value of information, scheduling/dependency analysis, portfolio optimization and risk management.
- Ethics anchors: distributive justice, proportionality, accountability and human override for consequential allocation.
- Evidence rule: rank position alone does not determine priority; model scarcity, deadlines, reversibility, fairness, interdependencies and cost of delay.

**Reference register convention.** For every cited claim, record source title/author or standards body, edition or release, persistent identifier/URL, access date when online, quoted passage or page/section, claim supported, evidence tier, and known counterevidence. External works mentioned here are **reading leads, not bundled or automatically verified citations**. Resolve authoritative editions before use.

## Assets Notes

**Existing package assets (verified against release `pluginrel_6ad31a9c75dc81918fe03685a5cd24bc`):**

- **Bundled local reference:** none specific to this skill was listed in the current release.
- **Shared branding only:** `assets/construct-icon.png` exists at plugin root. It is not evidence, a skill dataset, or a specialized analysis asset.
- **No other priority-specific templates, data files, test corpora, schemas, or visualizations were found in the release file inventory.**

**Recommended assets to develop and validate:**

- **Proposed, not yet bundled:** priority decision table with criteria, constraints and resource budgets.
- **Proposed, not yet bundled:** dependency DAG, critical-path and gating list.
- **Proposed, not yet bundled:** scenario/sensitivity and regret analyses.
- **Proposed, not yet bundled:** re-prioritization trigger log.
- **Proposed, not yet bundled:** override/approval and distributional-impact record.

**Asset registration standard.** Every future file should carry purpose, source/creator, provenance, license/consent, version, schema or media type, integrity digest, restrictions, expected consumer, and validation status. Keep examples distinct from normative specifications and empirical datasets. Do not claim a proposed asset exists until it has been bundled and audited.

## Dependencies

**Package/runtime dependencies.** This skill is a Markdown instruction module; no skill-specific executable runtime, package manager dependency, remote API, or MCP tool dependency is declared in the inspected plugin package. Invocation of tools or sources is conditional on access, authorization, and the question being asked.

**Cross-skill reasoning dependencies (invoke selectively, not automatically):**

- `skills/evaluation/SKILL.md` — absolute merit and expected benefit; a **conceptual** dependency, not a required code import.
- `skills/judgement/SKILL.md` — uncertainty about outcomes; a **conceptual** dependency, not a required code import.
- `skills/ranking/SKILL.md` — comparative ordering if useful; a **conceptual** dependency, not a required code import.
- `skills/workflow/SKILL.md` — operational sequencing; a **conceptual** dependency, not a required code import.
- `skills/validity/SKILL.md` — assess robustness and legitimacy; a **conceptual** dependency, not a required code import.

**Handoff contract.** Input: candidate actions, objectives, budgets, deadlines and constraints. Output: justified action set and order, dependencies, tradeoffs, contingency and review cadence.

**Dependency rules.** Preserve the ownership boundary between specialist skills; pass a stated purpose, definitions, provenance, constraints and confidence with every handoff. If a required skill, external source, authorization or test environment is unavailable, mark the gap rather than simulating evidence or claiming a test ran.

<!-- CONSTRUCT-SKILL-NOTES:END -->
