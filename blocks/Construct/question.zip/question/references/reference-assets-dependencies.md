<!-- CONSTRUCT-SKILL-NOTES:BEGIN version=1 -->

## Reference Notes

**Reference scope.** Design and sequential selection of diagnostic, research and conversational questions.

- Research anchors: scientific question formation, survey/questionnaire design, psychometrics, active learning, Bayesian experimental design and information gain.
- Interaction anchors: cognitive interviewing, Socratic methods, conversation analysis, ethical interviewing and stopping rules.
- Evidence rule: distinguish information gain from decision value; avoid leading questions, hidden presuppositions, excessive elicitation and irreversible disclosure requests.

**Reference register convention.** For every cited claim, record source title/author or standards body, edition or release, persistent identifier/URL, access date when online, quoted passage or page/section, claim supported, evidence tier, and known counterevidence. External works mentioned here are **reading leads, not bundled or automatically verified citations**. Resolve authoritative editions before use.

## Assets Notes

**Existing package assets (verified against release `pluginrel_6ad31a9c75dc81918fe03685a5cd24bc`):**

- **Bundled local reference:** none specific to this skill was listed in the current release.
- **Shared branding only:** `assets/construct-icon.png` exists at plugin root. It is not evidence, a skill dataset, or a specialized analysis asset.
- **No other question-specific templates, data files, test corpora, schemas, or visualizations were found in the release file inventory.**

**Recommended assets to develop and validate:**

- **Proposed, not yet bundled:** question typology, assumption and answerability schema.
- **Proposed, not yet bundled:** question graph with conditional branching.
- **Proposed, not yet bundled:** response rubric and follow-up rulebook.
- **Proposed, not yet bundled:** information-value estimates and stopping criteria.
- **Proposed, not yet bundled:** privacy and burden risk screen.

**Asset registration standard.** Every future file should carry purpose, source/creator, provenance, license/consent, version, schema or media type, integrity digest, restrictions, expected consumer, and validation status. Keep examples distinct from normative specifications and empirical datasets. Do not claim a proposed asset exists until it has been bundled and audited.

## Dependencies

**Package/runtime dependencies.** This skill is a Markdown instruction module; no skill-specific executable runtime, package manager dependency, remote API, or MCP tool dependency is declared in the inspected plugin package. Invocation of tools or sources is conditional on access, authorization, and the question being asked.

**Cross-skill reasoning dependencies (invoke selectively, not automatically):**

- `skills/knowledge/SKILL.md` — locate epistemic gaps; a **conceptual** dependency, not a required code import.
- `skills/information/SKILL.md` — represent candidate answers; a **conceptual** dependency, not a required code import.
- `skills/judgement/SKILL.md` — assess value of evidence; a **conceptual** dependency, not a required code import.
- `skills/validity/SKILL.md` — check measurement and question effects; a **conceptual** dependency, not a required code import.
- `skills/workflow/SKILL.md` — execute adaptive interviews; a **conceptual** dependency, not a required code import.

**Handoff contract.** Input: goal, hypotheses, respondent context, risk and response budget. Output: sequenced questions, rationales, branch rules, bias checks and stop condition.

**Dependency rules.** Preserve the ownership boundary between specialist skills; pass a stated purpose, definitions, provenance, constraints and confidence with every handoff. If a required skill, external source, authorization or test environment is unavailable, mark the gap rather than simulating evidence or claiming a test ran.

<!-- CONSTRUCT-SKILL-NOTES:END -->
