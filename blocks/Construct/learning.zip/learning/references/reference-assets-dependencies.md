<!-- CONSTRUCT-SKILL-NOTES:BEGIN version=1 -->

## Reference Notes

**Reference scope.** Durable adaptive change across humans, organizations and AI systems.

- Research anchors: retrieval practice, spacing, feedback, formative assessment, transfer, expertise development, metacognition, reinforcement/continual learning and organizational learning.
- Design anchors: constructive alignment, mastery criteria, spaced retrieval schedules, generalization tests, forgetting and unlearning policies.
- Evidence rule: distinguish exposure from learning and in-sample proficiency from transfer; for AI systems distinguish prompt adaptation, persistent memory and parameter updates.

**Reference register convention.** For every cited claim, record source title/author or standards body, edition or release, persistent identifier/URL, access date when online, quoted passage or page/section, claim supported, evidence tier, and known counterevidence. External works mentioned here are **reading leads, not bundled or automatically verified citations**. Resolve authoritative editions before use.

## Assets Notes

**Existing package assets (verified against release `pluginrel_6ad31a9c75dc81918fe03685a5cd24bc`):**

- **Bundled local reference:** none specific to this skill was listed in the current release.
- **Shared branding only:** `assets/construct-icon.png` exists at plugin root. It is not evidence, a skill dataset, or a specialized analysis asset.
- **No other learning-specific templates, data files, test corpora, schemas, or visualizations were found in the release file inventory.**

**Recommended assets to develop and validate:**

- **Proposed, not yet bundled:** competency and prerequisite map.
- **Proposed, not yet bundled:** practice-item bank with transfer challenges.
- **Proposed, not yet bundled:** feedback and longitudinal performance log.
- **Proposed, not yet bundled:** forgetting/interference/retention test suite.
- **Proposed, not yet bundled:** adaptive policy and update audit.

**Asset registration standard.** Every future file should carry purpose, source/creator, provenance, license/consent, version, schema or media type, integrity digest, restrictions, expected consumer, and validation status. Keep examples distinct from normative specifications and empirical datasets. Do not claim a proposed asset exists until it has been bundled and audited.

## Dependencies

**Package/runtime dependencies.** This skill is a Markdown instruction module; no skill-specific executable runtime, package manager dependency, remote API, or MCP tool dependency is declared in the inspected plugin package. Invocation of tools or sources is conditional on access, authorization, and the question being asked.

**Cross-skill reasoning dependencies (invoke selectively, not automatically):**

- `skills/knowledge/SKILL.md` — define learning content and uncertainty; a **conceptual** dependency, not a required code import.
- `skills/evaluation/SKILL.md` — assess outcomes against objectives; a **conceptual** dependency, not a required code import.
- `skills/validity/SKILL.md` — confirm generalization; a **conceptual** dependency, not a required code import.
- `skills/model/SKILL.md` — represent learning dynamics; a **conceptual** dependency, not a required code import.
- `skills/construct/SKILL.md` — safeguard identity change in agents; a **conceptual** dependency, not a required code import.

**Handoff contract.** Input: learner/system, objectives, baseline, context and constraints. Output: adaptive learning design, evidence of retention and transfer, safety/ethics limits and revision policy.

**Dependency rules.** Preserve the ownership boundary between specialist skills; pass a stated purpose, definitions, provenance, constraints and confidence with every handoff. If a required skill, external source, authorization or test environment is unavailable, mark the gap rather than simulating evidence or claiming a test ran.

<!-- CONSTRUCT-SKILL-NOTES:END -->
