# DIGITAL STORYTELLING — A FRONTIER-AWARE KNOWLEDGE ATLAS
**Research edition:** 17 October 2026  |  **Scope:** interdisciplinary synthesis  |  **Nodes:** 118  |  **Typed links:** 97  |  **Sources:** 22

> **Central thesis.** Digital storytelling designs meaningful change and interpretation through narrative, media, computation and human participation. It includes linear, interactive, social, immersive and AI-mediated work; interactivity is not a prerequisite. A story is not simply a bundle of assets, nor is a knowledge atlas a validated empirical theory.

## 01 / READ THE ATLAS
**How to navigate:** First choose the question you are designing for (meaning, identity, agency, form, embodiment, community, generation, production, evidence, trust). Then follow concept relationships. Frontier entries are hypotheses with tests, not promises. The accompanying HTML supports search and graph exploration.

**Epistemic labels:** `Established` = established practice/concept as editorial synthesis, **not** proven universal effect; `Active research` = published contemporary work with unresolved generalization; `Emerging / hypothesis` = plausible proposal with limited verification; `Speculative design` = exploratory scenario; `Observed industry trend / forecast` = direction/forecast whose numerical claims are not independently audited here. Concepts cite representative sources, not empirical confirmation of each design heuristic.

### A generative model of the field
**Experience = narrative change × situated identity × affordance × medium × participation × infrastructure × governance.** This is a design synthesis, not a quantitatively validated law. A zero in any factor is a diagnostic prompt rather than a mathematical fact.

### Eight orthogonal axes (classification facets)
- **Authorship:** single author ⇄ collaborative ⇄ generative agents
- **Audience control:** watch ⇄ explore ⇄ choose ⇄ change world
- **State persistence:** session-only ⇄ serial ⇄ multi-year persistent
- **Reality claim:** fiction ⇄ blended ⇄ evidence-bound nonfiction
- **Embodiment:** abstract text ⇄ audiovisual ⇄ spatial/physical
- **Distribution:** one channel ⇄ social network ⇄ coordinated transmedia
- **Adaptation:** fixed ⇄ declared-preference ⇄ dynamically adaptive
- **Governance:** individual editorial ⇄ delegated ⇄ community negotiated

### The necessary distinctions
- Narrative agency ≠ number of buttons
- A protagonist archetype ≠ an individual psychological diagnosis
- Character belief ≠ canonical world fact
- Simulation ≠ human experience
- Transmedia ≠ cross-posting
- Audience engagement ≠ informed consent
- Content provenance ≠ factual accuracy
- Model fluency ≠ long-horizon coherence
- Accessibility conformance ≠ accessibility experience
- Market forecast ≠ observed revenue

## 02 / SYSTEM MAP
The field is not a one-dimensional ladder from text to VR to AI. The twelve domains below are **facets**, not mutually exclusive media boxes. Each can modify the others. The typed JSON knowledge graph connects concepts across facets.
01. **Narrative grammar** (10 concepts): Events, causes, interpretation and emotional form.
02. **Characters & identity** (10 concepts): Motivation, contradiction, relationships and temporal integrity.
03. **Agency & interaction** (10 concepts): Player choice, information, consequence and legibility.
04. **Story architectures** (10 concepts): Graphs, loops, quests, temporal and spatial composition.
05. **Media ecologies** (10 concepts): Linear, social, live, documentary and transmedia forms.
06. **Spatial & sensory** (8 concepts): Presence, embodiment, movement, sound and alternate access.
07. **Communities & co-creation** (8 concepts): Collective authorship, facilitation and governance.
08. **AI & procedural narrative** (10 concepts): World models, agents, memory, constraints and synthesis.
09. **Production architecture** (10 concepts): Brief, pipeline, content model, quality and delivery.
10. **Research & measurement** (10 concepts): Narrative quality, behavior, experiments and learning.
11. **Rights, safety & trust** (10 concepts): Consent, inclusion, provenance, labor and ethical choices.
12. **Knowledge frontier** (12 concepts): Emerging capabilities, open questions and discriminating tests.

## 03 / CONCEPT DOMAINS AND RELATIONAL PRACTICE

### 01 — Narrative grammar
**Thesis.** A story is not identical to a sequence of content units. Its minimum useful analytical unit is change: an event reconfigures a valued situation, and an audience infers why that change matters. This distinction prevents an interactive or multimedia project from becoming merely a collection of assets.
**Practice.** Separate event chronology, causal graph and encounter order. Challenge every scene with three questions: what changed, who paid, and what new question became possible?
**Boundary.** Narrative devices are cultural and genre-dependent. This atlas presents heuristics, not a universal formula for emotional response.

#### Story event  ·  `grammar-story-event`
A meaningful change in a character, relationship, world or interpretation across time, rather than a mere occurrence.
**Design move:** For every beat, write before-state, event and after-state.
**Failure mode:** Spectacle without change feels detachable.
**Knowledge state:** Established. **Representative sources:** [S01].

#### Causality  ·  `grammar-causality`
A chain of why one story event changes the probability or meaning of the next.
**Design move:** Check whether removing a scene breaks later events.
**Failure mode:** Chronology mistaken for cause.
**Knowledge state:** Established. **Representative sources:** [S01].

#### Stakes  ·  `grammar-stakes`
The valued possibilities that may be lost or gained as a result of a decision or event.
**Design move:** Specify concrete cost, personal significance and time pressure.
**Failure mode:** Abstract world-ending threats with no human texture.
**Knowledge state:** Established. **Representative sources:** [S01].

#### Conflict  ·  `grammar-conflict`
Incompatible goals, interpretations, obligations or constraints that force consequential action.
**Design move:** Pair external opposition with an internal value collision.
**Failure mode:** Arbitrary obstacles that never test character.
**Knowledge state:** Established. **Representative sources:** [S01].

#### Theme  ·  `grammar-theme`
A recurring question or tension made legible by contrasting actions and outcomes, not simply a slogan.
**Design move:** Encode theme as a question each major branch answers differently.
**Failure mode:** Treating every route as a didactic proof.
**Knowledge state:** Established. **Representative sources:** [S01].

#### Point of view  ·  `grammar-point-of-view`
The situated filter determining what information is seen, believed and withheld.
**Design move:** Design who knows what at each story beat.
**Failure mode:** False neutrality, hidden viewpoint or accidental omniscience.
**Knowledge state:** Established. **Representative sources:** [S01].

#### Pacing  ·  `grammar-pacing`
The distribution of anticipation, revelation, variation and recovery over experienced time.
**Design move:** Alternate escalation with reflection; test on the real device.
**Failure mode:** Reliance on average duration as a proxy for rhythm.
**Knowledge state:** Established. **Representative sources:** [S01].

#### Emotional arc  ·  `grammar-emotional-arc`
The evolution of felt stakes, attachment, surprise and resolution across the experience.
**Design move:** Chart intended emotional transition by scene, not only plot.
**Failure mode:** Manipulation without earned attachment.
**Knowledge state:** Established. **Representative sources:** [S01].

#### Narrative inference  ·  `grammar-narrative-inference`
Meaning constructed by an audience from evidence, gaps and prior expectations.
**Design move:** Give clues that support more than one plausible hypothesis until a reveal.
**Failure mode:** Confusing ambiguity with missing information.
**Knowledge state:** Established. **Representative sources:** [S01].

#### Closure & openness  ·  `grammar-closure-openness`
The balance between resolving the local question and leaving possibilities for continued interpretation.
**Design move:** Close emotional promises even in open-world formats.
**Failure mode:** Endless lore in place of payoff.
**Knowledge state:** Established. **Representative sources:** [S01].


### 02 — Characters & identity
**Thesis.** Digital characters are temporally extended systems. They consist of goals, commitments, beliefs, relationship obligations, selective memory and cultural situation; a voice profile alone does not make an identity. Construct-style identity modeling becomes particularly useful for simulation, branching and long-duration stories.
**Practice.** Model facts separately from character beliefs; distinguish stable identity commitments from momentary emotional states; verify that changes have causes. Treat archetypes as interpretive design tools rather than supposedly universal human categories.
**Boundary.** Simulated personhood is not human personhood. Psychological plausibility in fiction is not empirical evidence that an AI persona represents a real person.

#### Character kernel  ·  `identity-character-kernel`
Persistent commitments, formative history, dispositions and values that make actions recognizably belong to one person.
**Design move:** Record what a character will protect even under pressure.
**Failure mode:** A costume, adjective list or voice alone masquerading as identity.
**Knowledge state:** Established. **Representative sources:** [S14], [S12].

#### Want versus need  ·  `identity-want-versus-need`
An articulated pursuit and a deeper unresolved dependency that can diverge through choice.
**Design move:** Link wants to conflicts and needs to potential transformation.
**Failure mode:** Imposing one universal therapeutic character arc.
**Knowledge state:** Established. **Representative sources:** [S14], [S12].

#### Belief model  ·  `identity-belief-model`
What the character believes, how certain they are and what would change their mind.
**Design move:** Track beliefs separately from objective storyworld facts.
**Failure mode:** Characters knowing what only authors or players know.
**Knowledge state:** Established. **Representative sources:** [S14], [S12].

#### Motive hierarchy  ·  `identity-motive-hierarchy`
The ranked motives activated under specific constraints rather than generic fixed traits.
**Design move:** Define goals, red lines, exceptions and scarcity trade-offs.
**Failure mode:** Inexplicable actions chosen only to advance plot.
**Knowledge state:** Established. **Representative sources:** [S14], [S12].

#### Relationship graph  ·  `identity-relationship-graph`
Time-varying trust, power, affection, debt and obligation between characters.
**Design move:** Record a relationship state change for each major interaction.
**Failure mode:** Binary friendship meters with no lived consequence.
**Knowledge state:** Established. **Representative sources:** [S14], [S12].

#### Internal contradiction  ·  `identity-internal-contradiction`
A value conflict or dissonance that gives plausible alternatives under stress.
**Design move:** Specify situations that force each side of the contradiction.
**Failure mode:** Arbitrary inconsistency mistaken for complexity.
**Knowledge state:** Established. **Representative sources:** [S14], [S12].

#### Cultural situatedness  ·  `identity-cultural-situatedness`
Identity embedded in language, institution, history, place and relationships, not in an exotic motif.
**Design move:** Consult affected communities and allow character specificity.
**Failure mode:** Archetypal stereotype or one voice representing a whole group.
**Knowledge state:** Established. **Representative sources:** [S14], [S12].

#### Character memory  ·  `identity-character-memory`
The selective, sometimes mistaken recollection of experienced events, distinct from canonical history.
**Design move:** Store what happened, what was perceived and what is recalled separately.
**Failure mode:** Total recall; AI persona confabulation presented as fact.
**Knowledge state:** Established. **Representative sources:** [S14], [S12].

#### Identity evolution  ·  `identity-identity-evolution`
Change in beliefs and relationships while preserving intelligible continuity with a prior self.
**Design move:** Define allowable growth, irreversible choices and repair arcs.
**Failure mode:** Personality reset after every scene or model refresh.
**Knowledge state:** Established. **Representative sources:** [S14], [S12].

#### Archetypal function  ·  `identity-archetypal-function`
A recurrent narrative organizing role such as mentor or threshold guardian, interpreted within a culture and genre.
**Design move:** Use archetypes as design hypotheses and subvert them through specificity.
**Failure mode:** Treating an archetype as a universal psychology or demographic truth.
**Knowledge state:** Established. **Representative sources:** [S14], [S12].


### 03 — Agency & interaction
**Thesis.** Choice is only one manifestation of agency. People may alter the world, explore the order of evidence, select a perspective or co-create norms. Meaningful agency requires both real consequence and the audience understanding where its power begins and ends.
**Practice.** Write an agency contract: what can players change, what is protected, when feedback appears, and which decisions endure? If the world cannot change, design interpretive agency instead.
**Boundary.** Branch counts are not impact; visible interfaces can deceive if promised consequences are silently erased.

#### Perceived agency  ·  `agency-perceived-agency`
Whether participants can see that their intentions are understood and can affect experience.
**Design move:** Make feedback acknowledge intent and consequence clearly.
**Failure mode:** Hidden scoring mistaken for user agency.
**Knowledge state:** Established. **Representative sources:** [S02], [S19], [S06].

#### Material agency  ·  `agency-material-agency`
The actual capacity to change later world states, relationships, pathways or outcomes.
**Design move:** List which variables a decision persistently alters.
**Failure mode:** Illusory branches presented as meaningful change.
**Knowledge state:** Established. **Representative sources:** [S02], [S19], [S06].

#### Interpretive agency  ·  `agency-interpretive-agency`
Freedom to choose perspectives, sequence or meaning when factual outcomes must remain fixed.
**Design move:** Let users compare testimonies without rewriting history.
**Failure mode:** Distorting documentary facts to simulate control.
**Knowledge state:** Established. **Representative sources:** [S02], [S19], [S06].

#### Choice architecture  ·  `agency-choice-architecture`
How alternatives are framed, labeled, delayed and constrained at decision points.
**Design move:** Show distinct costs and information rather than cosmetic wording.
**Failure mode:** Choice overload or coercive false dichotomies.
**Knowledge state:** Established. **Representative sources:** [S02], [S19], [S06].

#### Agency budget  ·  `agency-agency-budget`
Deliberate allocation of meaningful influence across story moments and layers.
**Design move:** Choose three decisions that alter different kinds of value.
**Failure mode:** Costly branching everywhere without real impact.
**Knowledge state:** Established. **Representative sources:** [S02], [S19], [S06].

#### Consequence horizon  ·  `agency-consequence-horizon`
How soon, clearly and reliably an action alters the experience.
**Design move:** Combine immediate acknowledgment with delayed payoff.
**Failure mode:** Long-delayed effects users cannot attribute to choices.
**Knowledge state:** Established. **Representative sources:** [S02], [S19], [S06].

#### Branching affordance  ·  `agency-branching-affordance`
A visible invitation to affect narrative flow, including links, dialogue, objects, timing or movement.
**Design move:** Test that first-time participants recognize what is interactive.
**Failure mode:** Clever controls discovered only by experts.
**Knowledge state:** Established. **Representative sources:** [S02], [S19], [S06].

#### Failure & recovery  ·  `agency-failure-recovery`
How unsuccessful decisions remain meaningful and how users can reconsider or continue.
**Design move:** Design informative fail-forward and optional rewind rules.
**Failure mode:** Punishment loops with no new knowledge.
**Knowledge state:** Established. **Representative sources:** [S02], [S19], [S06].

#### Consentful personalization  ·  `agency-consentful-personalization`
Adaptation according to expressed preferences, permissions and revocable data use.
**Design move:** Offer inspectable preference controls and a nonpersonalized route.
**Failure mode:** Secret emotion targeting or presumed intimacy.
**Knowledge state:** Established. **Representative sources:** [S02], [S19], [S06].

#### Choice accessibility  ·  `agency-choice-accessibility`
Equivalent access to decisions across keyboard, touch, assistive technology and time constraints.
**Design move:** Provide adjustable timing and non-gesture alternatives.
**Failure mode:** Physical ability mistaken for narrative competence.
**Knowledge state:** Established. **Representative sources:** [S02], [S19], [S06].


### 04 — Story architectures
**Thesis.** Narrative architectures trade authorial control, content costs and agency against one another. A tree buys transparency but scales poorly; foldback structures reduce content; storylets produce flexible sequencing; state machines ensure invariants; simulations permit surprise at the cost of guaranteed beats.
**Practice.** Choose topology against creative need. Define entry guards, irreversible actions, hidden/visible state and replay rules. Mix authored milestones with generative or modular local texture.
**Boundary.** No architecture guarantees art. Formal correctness must coexist with meaning, voice and dramatic surprise.

#### Linear sequence  ·  `structures-linear-sequence`
An authored ordering of events with no participant-driven causal branches.
**Design move:** Use when pacing and shared interpretation matter more than path autonomy.
**Failure mode:** Assuming linear means passive or obsolete.
**Knowledge state:** Established. **Representative sources:** [S02], [S03], [S12].

#### Branching tree  ·  `structures-branching-tree`
Divergent scenes and endings selected by choices; conceptually clear but expensive at depth.
**Design move:** Budget branch width/depth and merge where honest.
**Failure mode:** Exponential content without distinct payoffs.
**Knowledge state:** Established. **Representative sources:** [S02], [S03], [S12].

#### Foldback branch  ·  `structures-foldback-branch`
Local divergence converging on shared structural milestones while preserving differences.
**Design move:** Carry branch consequences via memory, dialogue or relationship state.
**Failure mode:** Convergence that erases previously promised agency.
**Knowledge state:** Established. **Representative sources:** [S02], [S03], [S12].

#### State machine  ·  `structures-state-machine`
A bounded set of narrative states with guarded transitions and invariants.
**Design move:** Specify each trigger, state mutation and illegal transition.
**Failure mode:** Broken canon due to underspecified edge cases.
**Knowledge state:** Established. **Representative sources:** [S02], [S03], [S12].

#### Storylets  ·  `structures-storylets`
Reusable narrative fragments dynamically eligible according to world state and priority.
**Design move:** Author entry conditions, effects and repetition guards.
**Failure mode:** Random events with no dramatic direction.
**Knowledge state:** Established. **Representative sources:** [S02], [S03], [S12].

#### Quest network  ·  `structures-quest-network`
A dependency network of goals, clues and objectives traversed in different orders.
**Design move:** Make dependency and optional content visible to authors.
**Failure mode:** Dead-ends created by circular prerequisites.
**Knowledge state:** Established. **Representative sources:** [S02], [S03], [S12].

#### Spatial narrative  ·  `structures-spatial-narrative`
Meaning revealed by where evidence and events are situated in an explorable environment.
**Design move:** Place contradictory environmental traces that reward looking.
**Failure mode:** Beautiful rooms with no narrative inference.
**Knowledge state:** Established. **Representative sources:** [S02], [S03], [S12].

#### Temporal remix  ·  `structures-temporal-remix`
Flashbacks, loops, asynchronous release or revisits that alter understanding of causality.
**Design move:** Track story time separately from encounter time.
**Failure mode:** Timeline confusion without payoff.
**Knowledge state:** Established. **Representative sources:** [S02], [S03], [S12].

#### Emergent narrative  ·  `structures-emergent-narrative`
Coherent stories interpreted from simulated systems and unscripted interactions.
**Design move:** Supply legible motives, constraints and event logs.
**Failure mode:** Calling any randomized sequence a story.
**Knowledge state:** Established. **Representative sources:** [S02], [S03], [S12].

#### Narrative state ledger  ·  `structures-narrative-state-ledger`
An auditable record of facts, commitments, decisions and derived consequences.
**Design move:** Make canon updates transactional and versioned.
**Failure mode:** One unstructured prompt serving as the world database.
**Knowledge state:** Established. **Representative sources:** [S02], [S03], [S12].


### 05 — Media ecologies
**Thesis.** Digital storytelling is broader than interactive fiction. It encompasses linear online cinema, audio, participatory live events, documentary interfaces, location-specific narratives, data stories and socially distributed serial fiction. Each medium changes time, attention and contribution patterns.
**Practice.** Make each platform carry its distinctive advantage. Transmedia means additive contribution, not reposting identical trailers. Protect an entry point that works independently for newcomers.
**Boundary.** Market forecasts and platform features change rapidly; neither is proof of narrative superiority.

#### Interactive fiction  ·  `media-interactive-fiction`
Text-centered narrative with player inputs, branching or simulation as core expression.
**Design move:** Prototype mechanics in Twine or ink before expensive media production.
**Failure mode:** Prose whose choices change nothing.
**Knowledge state:** Established. **Representative sources:** [S01], [S04], [S05], [S17].

#### Narrative game  ·  `media-narrative-game`
A rule-governed experience in which mechanics and authored or emergent stories interact.
**Design move:** Ask what values the core verb expresses.
**Failure mode:** Storytelling that contradicts what play rewards.
**Knowledge state:** Established. **Representative sources:** [S01], [S04], [S05], [S17].

#### Interactive documentary  ·  `media-interactive-documentary`
Fact-based narrative that lets users navigate testimony, perspectives, locations or data.
**Design move:** Make fact versus reconstruction explicit.
**Failure mode:** Treating interaction as permission to change evidence.
**Knowledge state:** Established. **Representative sources:** [S01], [S04], [S05], [S17].

#### Digital audio story  ·  `media-digital-audio-story`
Podcast, spatial audio, voice interface or responsive sound narrative.
**Design move:** Test comprehension without visuals and with text alternatives.
**Failure mode:** Vital information encoded only in spatial hearing.
**Knowledge state:** Established. **Representative sources:** [S01], [S04], [S05], [S17].

#### Short-form serialized video  ·  `media-short-form-serialized-video`
Mobile-first episodes with dense hooks, repeated orientation and cliffhangers.
**Design move:** Map season-scale emotional movement beyond click-through.
**Failure mode:** Attention engineering replacing character development.
**Knowledge state:** Established. **Representative sources:** [S01], [S04], [S05], [S17].

#### Live participatory story  ·  `media-live-participatory-story`
A narrative altered by audience actions during broadcasts, performances or communal events.
**Design move:** Design moderation, latency and safe intervention windows.
**Failure mode:** Crowd decisions exploiting or humiliating individuals.
**Knowledge state:** Established. **Representative sources:** [S01], [S04], [S05], [S17].

#### Transmedia world  ·  `media-transmedia-world`
Coordinated contributions across media, with each medium adding something distinctive to the whole.
**Design move:** Map entry points and unique narrative information per channel.
**Failure mode:** Duplicate marketing content mislabeled as transmedia.
**Knowledge state:** Established. **Representative sources:** [S01], [S04], [S05], [S17].

#### Data journalism story  ·  `media-data-journalism-story`
A claim-bearing, evidence-driven narrative using charts, interactives and exposition.
**Design move:** Separate observed data from model assumptions and narrative rhetoric.
**Failure mode:** Visually persuasive causal claims without identification.
**Knowledge state:** Established. **Representative sources:** [S01], [S04], [S05], [S17].

#### Social-native narrative  ·  `media-social-native-narrative`
Story organized around platform-native comments, remixes, feeds, formats and audience behavior.
**Design move:** Build an off-platform continuity plan for reach volatility.
**Failure mode:** Algorithm-dependent cliffhangers and fragile archives.
**Knowledge state:** Established. **Representative sources:** [S01], [S04], [S05], [S17].

#### Location-based narrative  ·  `media-location-based-narrative`
Site-specific narrative triggered by place, route, proximity or community knowledge.
**Design move:** Include remote alternative and avoid unsafe location incentives.
**Failure mode:** Excluding mobility-limited or distant participants.
**Knowledge state:** Established. **Representative sources:** [S01], [S04], [S05], [S17].


### 06 — Spatial & sensory
**Thesis.** In spatial narrative, action and bodily position become signifying media. Sound, gesture and environmental traces can carry plot information, but presence is not reducible to photorealistic graphics. Accessibility and comfort are primary design constraints.
**Practice.** Write a sensory-information ledger for every essential clue. Guarantee equivalent access across seated, low-motion, captioned, mono-audio, text-based and alternate-control routes where applicable.
**Boundary.** W3C XR user requirements are an informative note rather than a universal legal checklist; user testing is indispensable.

#### Presence  ·  `embodiment-presence`
Felt locatedness in a mediated setting, influenced by sensory coherence, attention and action.
**Design move:** Prefer credible interaction feedback over visual maximalism.
**Failure mode:** Assuming high resolution guarantees immersion.
**Knowledge state:** Established. **Representative sources:** [S08], [S09], [S07].

#### Embodied perspective  ·  `embodiment-embodied-perspective`
Meaning created by bodily scale, position, orientation and possible action.
**Design move:** Test how the story changes when experienced seated or standing.
**Failure mode:** Required movement excluding users.
**Knowledge state:** Established. **Representative sources:** [S08], [S09], [S07].

#### Six-degree navigation  ·  `embodiment-six-degree-navigation`
Movement and orientation across three positional and three rotational axes in tracked spaces.
**Design move:** Mark navigable boundaries and supply comfortable travel modes.
**Failure mode:** Disorientation and simulator sickness.
**Knowledge state:** Established. **Representative sources:** [S08], [S09], [S07].

#### Spatial audio  ·  `embodiment-spatial-audio`
Audio whose relative direction and distance convey place, attention or event.
**Design move:** Pair directional sound with a visual/text equivalent.
**Failure mode:** Plot-critical cue accessible only to binaural hearing.
**Knowledge state:** Established. **Representative sources:** [S08], [S09], [S07].

#### Environmental evidence  ·  `embodiment-environmental-evidence`
Objects, traces, signage and architecture that let participants infer history.
**Design move:** Curate objects with causal links to world events.
**Failure mode:** Set dressing mistaken for meaning.
**Knowledge state:** Established. **Representative sources:** [S08], [S09], [S07].

#### Volumetric representation  ·  `embodiment-volumetric-representation`
Captured or synthesized 3D people, places and performances for navigable viewing.
**Design move:** Evaluate motion, identity fidelity, rights and compute cost.
**Failure mode:** Technical spectacle without narrative relevance.
**Knowledge state:** Established. **Representative sources:** [S08], [S09], [S07].

#### Multimodal fallback  ·  `embodiment-multimodal-fallback`
A deliberately authored alternate route for movement, audio, visual or device constraints.
**Design move:** Preserve information and choice equivalence across modes.
**Failure mode:** Relegating accessibility to an incomplete transcript.
**Knowledge state:** Established. **Representative sources:** [S08], [S09], [S07].

#### Comfort & safety envelope  ·  `embodiment-comfort-safety-envelope`
Timing, locomotion, content and sensory controls that keep immersive participation voluntary.
**Design move:** Provide a safe exit, scene skip, reorientation and motion options.
**Failure mode:** Optimizing for time-in-headset over wellbeing.
**Knowledge state:** Established. **Representative sources:** [S08], [S09], [S07].


### 07 — Communities & co-creation
**Thesis.** Digital storyworlds often grow through community interpretation, contribution and shared ritual. Participation creates value and simultaneously introduces unequal voice, moderation burdens and authorship disputes. Co-creation must therefore be designed as governance, not just an engagement mechanic.
**Practice.** Document contribution licenses, official versus unofficial canon, moderator powers, restorative steps and appeal routes before launch. Preserve opt-out and pseudonymous paths.
**Boundary.** A vocal community is not identical to a representative audience. Digital participation can reproduce inequalities of time and access.

#### Participatory culture  ·  `participation-participatory-culture`
Audiences circulate, interpret and sometimes make new story material within communities.
**Design move:** Give meaningful ways to contribute without requiring public visibility.
**Failure mode:** Extracting unpaid creativity without credit.
**Knowledge state:** Established. **Representative sources:** [S01], [S04].

#### Co-authorship rights  ·  `participation-co-authorship-rights`
Explicit allocation of contribution ownership, permissions, attribution and remix boundaries.
**Design move:** Publish contribution terms before collecting submissions.
**Failure mode:** Ambiguous licenses after valuable fan work exists.
**Knowledge state:** Established. **Representative sources:** [S01], [S04].

#### Collective intelligence  ·  `participation-collective-intelligence`
Distributed sensemaking where people pool clues, perspectives and interpretive labor.
**Design move:** Design divisible puzzles and synthesis spaces.
**Failure mode:** Hidden dependency on large or privileged communities.
**Knowledge state:** Established. **Representative sources:** [S01], [S04].

#### Moderated canon  ·  `participation-moderated-canon`
A system deciding what fan-made, AI-made or event-made material becomes official world history.
**Design move:** Separate sandbox, provisional and canonical layers.
**Failure mode:** Quiet retroactive canon changes.
**Knowledge state:** Established. **Representative sources:** [S01], [S04].

#### Role-based participation  ·  `participation-role-based-participation`
Different contribution powers for performers, witnesses, moderators, players and editors.
**Design move:** Specify role capability, accountability and appeals.
**Failure mode:** Voice or role conflated with operational authority.
**Knowledge state:** Established. **Representative sources:** [S01], [S04].

#### Community safety  ·  `participation-community-safety`
Rules and responses for harassment, exclusion, spoilers, intimate content and conflict.
**Design move:** Create escalation paths and staffed moderation capacity.
**Failure mode:** Launching participatory experiences without response capacity.
**Knowledge state:** Established. **Representative sources:** [S01], [S04].

#### Ritual & cadence  ·  `participation-ritual-cadence`
Recurring shared moments that produce belonging, anticipation and narrative memory.
**Design move:** Balance event exclusivity with recorded catch-up paths.
**Failure mode:** Fear-of-missing-out used as forced retention.
**Knowledge state:** Established. **Representative sources:** [S01], [S04].

#### Participatory archive  ·  `participation-participatory-archive`
Durable records of choices, remixes and community interpretation with privacy-aware access.
**Design move:** Define what persists, who can delete and what can be exported.
**Failure mode:** Unconsented public preservation of private expression.
**Knowledge state:** Established. **Representative sources:** [S01], [S04].


### 08 — AI & procedural narrative
**Thesis.** Generative systems can improvise language, action and media, but long-horizon coherence, narrative commitment and multimodal continuity remain active research problems. Architectural decomposition—canon store, scene planner, character performance, verifier, safety policy, editor—reduces unbounded improvisation.
**Practice.** Validate story facts before publication. Track beliefs, goals and state updates in typed records. Test adversarial and normal play, not only polished showcase transcripts.
**Boundary.** Preprint benchmarks, vendor examples and simulator studies have different evidentiary weights. None guarantees reliable open-world storytelling.

#### Generative narrative model  ·  `generative-generative-narrative-model`
A system proposing dialogue, events or scenes from a specification, context and stochastic computation.
**Design move:** Constrain generation with canon, safety policy and revision workflow.
**Failure mode:** Fluency mistaken for truth or dramatic structure.
**Knowledge state:** Active research. **Representative sources:** [S12], [S13], [S14], [S15], [S16].

#### Director–actor separation  ·  `generative-director-actor-separation`
Separate dramatic pacing and world rules from individual character performance policies.
**Design move:** Keep a planner, independent state store and performer-level outputs.
**Failure mode:** Every agent improvising an incompatible world.
**Knowledge state:** Active research. **Representative sources:** [S12], [S13], [S14], [S15], [S16].

#### Persistent canon  ·  `generative-persistent-canon`
Authoritative versioned story facts against which generated material is validated.
**Design move:** Check each generated assertion against canon before publishing.
**Failure mode:** Retrieval of old summaries treated as a fact database.
**Knowledge state:** Active research. **Representative sources:** [S12], [S13], [S14], [S15], [S16].

#### Agent memory architecture  ·  `generative-agent-memory-architecture`
Segmented observations, beliefs, reflections and access-controlled recall for synthetic characters.
**Design move:** Track provenance and expiration of memories and differentiate facts from interpretations.
**Failure mode:** False memories become unchallenged canon.
**Knowledge state:** Active research. **Representative sources:** [S12], [S13], [S14], [S15], [S16].

#### Narrative constraint engine  ·  `generative-narrative-constraint-engine`
Rules restricting generation to legal world actions, limits and continuity contracts.
**Design move:** Test invariants and recover from invalid outputs.
**Failure mode:** Hoping a prose prompt will enforce every invariant.
**Knowledge state:** Active research. **Representative sources:** [S12], [S13], [S14], [S15], [S16].

#### Procedural plot planning  ·  `generative-procedural-plot-planning`
Rule-based or search-based sequencing of goals, complications and resolutions.
**Design move:** Optimize for motivations and constraints, not only novelty.
**Failure mode:** Combinatorial variety with no causality.
**Knowledge state:** Active research. **Representative sources:** [S12], [S13], [S14], [S15], [S16].

#### Multimodal shot consistency  ·  `generative-multimodal-shot-consistency`
Maintaining identity, location, action and style across generated film segments.
**Design move:** Use reference frames, shot lists and human continuity checks.
**Failure mode:** Visually compelling isolated shots that cannot be edited together.
**Knowledge state:** Active research. **Representative sources:** [S12], [S13], [S14], [S15], [S16].

#### Human editorial control  ·  `generative-human-editorial-control`
Accountable human authority over canon, cultural context, publication and harm decisions.
**Design move:** Make approval and intervention permissions explicit.
**Failure mode:** Automated publish-by-default on consequential claims.
**Knowledge state:** Active research. **Representative sources:** [S12], [S13], [S14], [S15], [S16].

#### AI provenance & disclosure  ·  `generative-ai-provenance-disclosure`
Recording where generative systems affected a story asset and making relevant uses legible.
**Design move:** Store tool, model, assets, licenses and disclosure provenance per release.
**Failure mode:** Invisible generation or treating signatures as evidence of truth.
**Knowledge state:** Active research. **Representative sources:** [S12], [S13], [S14], [S15], [S16].

#### Long-horizon evaluation  ·  `generative-long-horizon-evaluation`
Stress testing narrative systems over many turns for contradictions, lost goals and drift.
**Design move:** Run adversarial interaction tests and calculate canon violation rates.
**Failure mode:** Single pretty demos treated as reliable capabilities.
**Knowledge state:** Active research. **Representative sources:** [S12], [S13], [S14], [S15], [S16].


### 09 — Production architecture
**Thesis.** The creative project must survive asset revisions, localization, new devices and years of content growth. Stable IDs, scene metadata, version control, permissions, regression testing and exportable archives are the infrastructure of meaningful narrative continuity.
**Practice.** Prove the experience first with text, then a vertical slice. Maintain a source of truth for canon and an asset provenance record. Automate graph reachability and state invariant tests.
**Boundary.** Pipelines can overformalize early artistic exploration. Reserve spaces for improvisation while protecting the published experience.

#### Story design brief  ·  `production-story-design-brief`
A shared statement of audience, promise, medium, agency, scope and success criteria.
**Design move:** Write what the participant can feel, know or do differently afterward.
**Failure mode:** Choosing technologies before the experience.
**Knowledge state:** Established. **Representative sources:** [S03], [S06], [S10].

#### World bible  ·  `production-world-bible`
Maintained definitions of chronology, character commitments, rules, references and exclusions.
**Design move:** Version the bible with a responsible editor.
**Failure mode:** Lore volume without operational consistency.
**Knowledge state:** Established. **Representative sources:** [S03], [S06], [S10].

#### Narrative data model  ·  `production-narrative-data-model`
Structured scenes, roles, objects, choices, flags, provenance and content dependencies.
**Design move:** Give each entity stable identifiers and schema tests.
**Failure mode:** One unmaintainable spreadsheet containing every meaning.
**Knowledge state:** Established. **Representative sources:** [S03], [S06], [S10].

#### Prototype ladder  ·  `production-prototype-ladder`
A sequence from paper simulation to text interaction to production-quality slices.
**Design move:** Test agency and comprehension before visual fidelity.
**Failure mode:** Delaying user tests until expensive assets are finished.
**Knowledge state:** Established. **Representative sources:** [S03], [S06], [S10].

#### Content production pipeline  ·  `production-content-production-pipeline`
Controlled transitions from concept to script, assets, integration, localization and release.
**Design move:** Build review gates with traceable handoffs.
**Failure mode:** Mixed draft/final assets deployed accidentally.
**Knowledge state:** Established. **Representative sources:** [S03], [S06], [S10].

#### Version & release management  ·  `production-version-release-management`
Managing story variants, state migration, rollback and synchronized channel changes.
**Design move:** Record release notes for both story facts and technical behavior.
**Failure mode:** Players resuming in invalid states after update.
**Knowledge state:** Established. **Representative sources:** [S03], [S06], [S10].

#### Localization & transcreation  ·  `production-localization-transcreation`
Re-authoring meaning, humor, choice clarity and cultural cues across language communities.
**Design move:** Test decision equivalence with native-language participants.
**Failure mode:** Word-for-word translation destroying stakes.
**Knowledge state:** Established. **Representative sources:** [S03], [S06], [S10].

#### Asset & rights ledger  ·  `production-asset-rights-ledger`
Recording creation, source, license, consent, transformation and usage constraints of each asset.
**Design move:** Link every published asset to its permission record.
**Failure mode:** Licensing discovered only after distribution.
**Knowledge state:** Established. **Representative sources:** [S03], [S06], [S10].

#### Narrative quality assurance  ·  `production-narrative-quality-assurance`
Testing branch reachability, continuity, technical access, moderation and regression.
**Design move:** Automate state tests; use humans for meaning and harm review.
**Failure mode:** Technical correctness equated with narrative quality.
**Knowledge state:** Established. **Representative sources:** [S03], [S06], [S10].

#### Archival portability  ·  `production-archival-portability`
Exports and documentation preserving the experience beyond a single platform or vendor.
**Design move:** Save scripts, state schema, assets, transcripts and replay traces.
**Failure mode:** Unrecoverable platform-locked interactive work.
**Knowledge state:** Established. **Representative sources:** [S03], [S06], [S10].


### 10 — Research & measurement
**Thesis.** Successful digital storytelling has multiple independent outcomes: coherence, agency, emotional meaning, comprehension, accessibility, economic viability and trust. These values can conflict and should not be collapsed into one engagement score.
**Practice.** Pre-register major hypotheses, combine telemetry with interviews, test diversity of interpretation, and report tradeoffs. A benchmark result is evidence about the measured setting, not the whole audience.
**Boundary.** Completion, clicks or watch time are not direct measures of meaning or consent.

#### Narrative coherence  ·  `evaluation-narrative-coherence`
Consistency of facts, causality, roles and commitments across the audience's experienced path.
**Design move:** Test contradictions across representative long sessions.
**Failure mode:** Measuring only linguistic smoothness.
**Knowledge state:** Established. **Representative sources:** [S12], [S13], [S06], [S20].

#### Meaningful agency test  ·  `evaluation-meaningful-agency-test`
Whether participant actions produce differentiated, intelligible consequences aligned with promises.
**Design move:** Interview users and inspect actual state changes.
**Failure mode:** Number of clickable options used as an agency metric.
**Knowledge state:** Established. **Representative sources:** [S12], [S13], [S06], [S20].

#### Comprehension & recall  ·  `evaluation-comprehension-recall`
What an audience accurately understands and remembers after interacting.
**Design move:** Use delayed questions with verified answers where appropriate.
**Failure mode:** Confusing exposure with learning.
**Knowledge state:** Established. **Representative sources:** [S12], [S13], [S06], [S20].

#### Emotional resonance  ·  `evaluation-emotional-resonance`
Reported attachment, tension, reflection or identification interpreted within context.
**Design move:** Combine voluntary qualitative reports with careful observation.
**Failure mode:** Inferring emotion from facial data without consent or validation.
**Knowledge state:** Established. **Representative sources:** [S12], [S13], [S06], [S20].

#### Accessibility outcome  ·  `evaluation-accessibility-outcome`
Whether varied participants can reach, understand and act on essential story content.
**Design move:** Test assistive technology and alternate modalities with users.
**Failure mode:** Passing an automated checklist as proof of inclusion.
**Knowledge state:** Established. **Representative sources:** [S12], [S13], [S06], [S20].

#### Narrative analytics  ·  `evaluation-narrative-analytics`
Privacy-conscious event records of entry, choice, return, completion and confusion.
**Design move:** State hypotheses before instrumenting events.
**Failure mode:** Tracking everything and learning little.
**Knowledge state:** Established. **Representative sources:** [S12], [S13], [S06], [S20].

#### Causal experimentation  ·  `evaluation-causal-experimentation`
Comparing design changes while managing confounders and unintended effects.
**Design move:** Randomize when ethical and practical; inspect heterogeneous outcomes.
**Failure mode:** Platform reach changes mistaken for story effect.
**Knowledge state:** Established. **Representative sources:** [S12], [S13], [S06], [S20].

#### Qualitative sensemaking  ·  `evaluation-qualitative-sensemaking`
Interviews, diaries and think-aloud protocols for meaning not captured in clickstreams.
**Design move:** Ask what a choice meant rather than only whether users clicked it.
**Failure mode:** Leading questions and overgeneralization from anecdotes.
**Knowledge state:** Established. **Representative sources:** [S12], [S13], [S06], [S20].

#### Interpretive pluralism  ·  `evaluation-interpretive-pluralism`
Preserving legitimate multiple readings rather than scoring one emotional response as correct.
**Design move:** Measure factual comprehension separately from thematic interpretation.
**Failure mode:** Treating all disagreement as failure.
**Knowledge state:** Established. **Representative sources:** [S12], [S13], [S06], [S20].

#### Evidence ladder  ·  `evaluation-evidence-ladder`
Labeling claims as demonstrated, provisionally supported, contested or speculative.
**Design move:** Record source type, date, scope and disconfirming evidence.
**Failure mode:** Market forecast presented as audited outcome.
**Knowledge state:** Established. **Representative sources:** [S12], [S13], [S06], [S20].


### 11 — Rights, safety & trust
**Thesis.** Digital stories can represent real people, make fact claims, store intimate behavior and synthesize identities. Effective trust requires a combination of permission, truthful labeling, accessible delivery, substantive verification and accountable human decisions.
**Practice.** Keep source claims, editorial interpretations and synthetic reconstructions separate; label appropriate AI uses; consult legal counsel for jurisdiction-specific duties. C2PA can help record provenance but does not make assertions true.
**Boundary.** The EU AI Act Article 50 transparency duties took effect 2 August 2026, with scope and exceptions. This atlas is not legal advice; creators must confirm applicable roles and jurisdictions.

#### Consent & subject dignity  ·  `stewardship-consent-subject-dignity`
Permission and editorial practice respectful of people whose voices, bodies or histories appear.
**Design move:** Make consent granular, revocable where possible and documented.
**Failure mode:** Treating a release form as sufficient for every reuse.
**Knowledge state:** Established. **Representative sources:** [S06], [S10], [S11], [S22].

#### Authorship & labor  ·  `stewardship-authorship-labor`
Transparent recognition, remuneration and bargaining for creative contributors and performers.
**Design move:** Audit compensation and generative replacement decisions.
**Failure mode:** Credit laundering or uncompensated training inputs.
**Knowledge state:** Established. **Representative sources:** [S06], [S10], [S11], [S22].

#### Privacy by design  ·  `stewardship-privacy-by-design`
Collecting and retaining only participant data necessary for declared narrative functions.
**Design move:** Use local settings, short retention and clear withdrawal.
**Failure mode:** Personality profiling as a hidden default.
**Knowledge state:** Established. **Representative sources:** [S06], [S10], [S11], [S22].

#### Provenance chain  ·  `stewardship-provenance-chain`
Verifiable provenance metadata for how a media asset was created and edited.
**Design move:** Use Content Credentials where supported and separately verify substantive claims.
**Failure mode:** Equating authentic provenance with factual truth.
**Knowledge state:** Established. **Representative sources:** [S06], [S10], [S11], [S22].

#### Synthetic identity policy  ·  `stewardship-synthetic-identity-policy`
Boundaries for AI personas, deceased persons, voice replicas and implied relationships.
**Design move:** Clearly disclose synthetic roles and prohibit unauthorized likeness use.
**Failure mode:** Manipulative anthropomorphism or unapproved impersonation.
**Knowledge state:** Established. **Representative sources:** [S06], [S10], [S11], [S22].

#### Truthfulness in nonfiction  ·  `stewardship-truthfulness-in-nonfiction`
Marking verified record, witness account, inference, reconstruction and hypothetical scenario.
**Design move:** Make the evidence-to-scene path inspectable.
**Failure mode:** Documentary re-enactment treated as recorded footage.
**Knowledge state:** Established. **Representative sources:** [S06], [S10], [S11], [S22].

#### Cultural accountability  ·  `stewardship-cultural-accountability`
Consultation, benefit sharing, contextualization and repair mechanisms for affected communities.
**Design move:** Involve communities before representation becomes final.
**Failure mode:** One external consultant as ceremonial approval.
**Knowledge state:** Established. **Representative sources:** [S06], [S10], [S11], [S22].

#### Accessible-by-design governance  ·  `stewardship-accessible-by-design-governance`
Accessibility requirements in procurement, authorship, test and release processes.
**Design move:** Give inclusion reviewers stop-ship authority for blocking defects.
**Failure mode:** Retroactive accessibility that changes the story unevenly.
**Knowledge state:** Established. **Representative sources:** [S06], [S10], [S11], [S22].

#### Safety & content boundaries  ·  `stewardship-safety-content-boundaries`
Protecting users and community members from abuse, manipulative design and foreseeable harms.
**Design move:** Define age-relevant safeguards, escalation and opt-outs.
**Failure mode:** Minimizing harm only after a public incident.
**Knowledge state:** Established. **Representative sources:** [S06], [S10], [S11], [S22].

#### Legal applicability  ·  `stewardship-legal-applicability`
Jurisdiction- and role-specific duties regarding data, copyrights, AI labels and accessible delivery.
**Design move:** Log launch markets and conduct specialist review for live deployments.
**Failure mode:** Treating an atlas overview as legal advice.
**Knowledge state:** Established. **Representative sources:** [S06], [S10], [S11], [S22].


### 12 — Knowledge frontier
**Thesis.** The knowledge frontier is not a product list. It is a portfolio of unresolved design and empirical questions: coherence over time, machine-readable creative systems, privacy-preserving adaptation, multimodal parity, credible provenance and creative labor governance.
**Practice.** Track each frontier with an observed signal, an explicit hypothesis, a discriminating test, a failure mode, and a trigger that would justify updating its state.
**Boundary.** Forecasts, preprints and potential capabilities are not established deployments. Avoid converting possibility into confident prediction.

#### Canon-preserving AI drama  ·  `frontier-canon-preserving-ai-drama`
Open-ended conversation with durable world, goal and relationship consistency remains an active technical challenge.
**Design move:** Benchmark 20-, 50- and 100-turn consistency under hostile and benign players.
**Failure mode:** Model fluency presented as sustained plot reliability.
**Knowledge state:** Active research. **Representative sources:** [S12], [S13], [S16], [S19], [S10].

#### Executable narrative constitutions  ·  `frontier-executable-narrative-constitutions`
Machine-checkable values, constraints, permissions and canon changes may coordinate many creative agents.
**Design move:** Prototype typed rules and an author override ledger.
**Failure mode:** Formal schemas that erase ambiguity essential to art.
**Knowledge state:** Emerging / hypothesis. **Representative sources:** [S12], [S13], [S16], [S19], [S10].

#### Player-shaped persistent worlds  ·  `frontier-player-shaped-persistent-worlds`
Worlds that remember many users and evolve without losing fairness or local narrative coherence.
**Design move:** Test reversible and irreversible collective actions under moderation.
**Failure mode:** Canon captured by a loud minority.
**Knowledge state:** Emerging / hypothesis. **Representative sources:** [S12], [S13], [S16], [S19], [S10].

#### Live adaptive direction  ·  `frontier-live-adaptive-direction`
Real-time pacing, camera, dialogue and content scheduling responsive to audience signals.
**Design move:** Trial opt-in behavioral signals before inferred emotions.
**Failure mode:** Engagement maximizing manipulation.
**Knowledge state:** Emerging / hypothesis. **Representative sources:** [S12], [S13], [S16], [S19], [S10].

#### Generative multi-shot cinema  ·  `frontier-generative-multi-shot-cinema`
Shot-level generation with references and memory extends authors' audiovisual options but continuity remains limited.
**Design move:** Evaluate cross-shot identity and action continuity with human raters.
**Failure mode:** Treating vendor reels as reproducible performance.
**Knowledge state:** Active research. **Representative sources:** [S15], [S16], [S18].

#### Spatial memory worlds  ·  `frontier-spatial-memory-worlds`
Navigable reconstructions combining live capture, spatial rendering and situated annotation.
**Design move:** Audit reconstruction uncertainty and long-term maintainability.
**Failure mode:** Digital twin aesthetics mistaken for historical evidence.
**Knowledge state:** Emerging / hypothesis. **Representative sources:** [S12], [S13], [S16], [S19], [S10].

#### Perspective-based factual agency  ·  `frontier-perspective-based-factual-agency`
Interaction grants interpretation, role-taking or evidence comparison without changing documented events.
**Design move:** Test alternate readings against unchanged source documents.
**Failure mode:** Gamifying suffering or falsifying chronology.
**Knowledge state:** Active research. **Representative sources:** [S19].

#### Consent-aware personalization  ·  `frontier-consent-aware-personalization`
Narrative adaptation from explicitly authorized preference and context rather than covert profiling.
**Design move:** Compare personalization against a robust nonpersonalized baseline.
**Failure mode:** Deducing intimate traits from harmless choices.
**Knowledge state:** Emerging / hypothesis. **Representative sources:** [S12], [S13], [S16], [S19], [S10].

#### Machine-readable story provenance  ·  `frontier-machine-readable-story-provenance`
Linked records of editorial, synthetic and audience-authored contributions become browsable story metadata.
**Design move:** Join rights ledger, story version and C2PA asset manifests.
**Failure mode:** Assuming any one standard captures full authorship truth.
**Knowledge state:** Emerging / hypothesis. **Representative sources:** [S10].

#### Localized world coherence  ·  `frontier-localized-world-coherence`
Shared canon represented across languages, cultures and divergent transcreated branches.
**Design move:** Check goals, consequences and relationships after localization.
**Failure mode:** Treating literal translation as invariant meaning.
**Knowledge state:** Emerging / hypothesis. **Representative sources:** [S12], [S13], [S16], [S19], [S10].

#### Microdrama platform diversification  ·  `frontier-microdrama-platform-diversification`
Short episodic scripted media changes audience entry, financing, cadence and rights economics.
**Design move:** Test retention without coercive payment gates; monitor region-specific evidence.
**Failure mode:** Extrapolating one forecast into universal demand.
**Knowledge state:** Active research. **Representative sources:** [S17].

#### Adaptive accessibility narratives  ·  `frontier-adaptive-accessibility-narratives`
Equivalent but different sensory and interaction routes generated to user-declared needs.
**Design move:** Validate agency equivalence with disability communities.
**Failure mode:** Letting untested AI improvise critical accessible content.
**Knowledge state:** Emerging / hypothesis. **Representative sources:** [S08].

## 04 / SELECTED CROSS-DOMAIN RELATIONSHIPS
Relations describe editorially reasoned design dependencies, not demonstrated causal laws. The relation type has a precise intended meaning.
- **depends_on**: A depends on B for its intended design function.
- **enables**: A can enable B when implemented successfully.
- **constrains**: A sets boundaries on B.
- **tensions_with**: A and B create a consequential design tradeoff.
- **evaluated_by**: A is evaluated by B.
- **expressed_as**: A is often expressed as B.
- **governed_by**: A should be governed by B.

- **Story event** —depends_on→ **Causality**: Changes need reasons and downstream consequences.
- **Causality** —enables→ **Narrative coherence**: Mechanistic links support coherent paths.
- **Stakes** —enables→ **Emotional arc**: Valued consequences build tension.
- **Conflict** —depends_on→ **Motive hierarchy**: Opposing action needs intelligible motives.
- **Theme** —expressed_as→ **Interpretive pluralism**: A thematic question can sustain multiple readings.
- **Point of view** —constrains→ **Narrative inference**: What can be inferred depends on what can be known.
- **Narrative inference** —enables→ **Environmental evidence**: Objects can carry interpretable clues.
- **Pacing** —tensions_with→ **Perceived agency**: Free exploration disrupts fixed beats.
- **Closure & openness** —tensions_with→ **Emergent narrative**: Open simulation resists authored closure.
- **Character kernel** —depends_on→ **Belief model**: Beliefs constrain plausible reactions.
- **Character kernel** —depends_on→ **Motive hierarchy**: Priorities stabilize decisions.
- **Character memory** —depends_on→ **Narrative state ledger**: Events and recollection need separable histories.
- **Identity evolution** —depends_on→ **Relationship graph**: Relationships can transform identity over time.
- **Internal contradiction** —enables→ **Conflict**: Competing commitments create drama.
- **Cultural situatedness** —governed_by→ **Cultural accountability**: Representation requires reciprocal review.
- **Archetypal function** —tensions_with→ **Cultural situatedness**: Generic schemas can flatten particular identities.
- **Material agency** —depends_on→ **Consequence horizon**: Outcomes must follow player action.
- **Perceived agency** —depends_on→ **Branching affordance**: Players need legible control points.
- **Material agency** —evaluated_by→ **Meaningful agency test**: Actual state difference is testable.
- **Interpretive agency** —enables→ **Perspective-based factual agency**: Perspective control preserves factual history.
- **Choice architecture** —constrains→ **Perceived agency**: Choice labels shape understanding.
- **Agency budget** —constrains→ **Branching tree**: Production limits meaningful divergence.
- **Consequence horizon** —depends_on→ **Narrative state ledger**: Delayed consequences need persistence.
- **Choice accessibility** —governed_by→ **Accessible-by-design governance**: Parity requires planned review.
- **Failure & recovery** —enables→ **Comprehension & recall**: Informative failure supports understanding.
- **Branching tree** —tensions_with→ **Content production pipeline**: Branch expansion increases content cost.
- **Foldback branch** —enables→ **Agency budget**: Recombination reduces content explosion.
- **State machine** —enables→ **Narrative constraint engine**: Explicit transitions permit validation.
- **Storylets** —depends_on→ **Narrative state ledger**: Eligibility requires state.
- **Quest network** —depends_on→ **Causality**: Unlock conditions reflect story logic.
- **Spatial narrative** —expressed_as→ **Environmental evidence**: Places can communicate causal traces.
- **Temporal remix** —depends_on→ **Point of view**: Chronology changes interpretation.
- **Emergent narrative** —enables→ **Player-shaped persistent worlds**: Simulation can create participant histories.
- **Narrative state ledger** —depends_on→ **Narrative data model**: Canon needs representation.
- **Interactive fiction** —enables→ **Prototype ladder**: Text builds are cheap to iterate.
- **Narrative game** —depends_on→ **Material agency**: Mechanics should produce consequences.
- **Interactive documentary** —governed_by→ **Truthfulness in nonfiction**: Fact/inference must stay distinct.
- **Transmedia world** —depends_on→ **World bible**: Multiple channels need shared constraints.
- **Transmedia world** —depends_on→ **Archival portability**: Channels have different lifespans.
- **Short-form serialized video** —tensions_with→ **Emotional arc**: Dense hooks can overwhelm earned change.
- **Live participatory story** —governed_by→ **Community safety**: Real-time participation requires moderation.
- **Data journalism story** —governed_by→ **Truthfulness in nonfiction**: Factual claims need evidence.
- **Social-native narrative** —depends_on→ **Archival portability**: Platform longevity is uncertain.
- **Location-based narrative** —governed_by→ **Multimodal fallback**: Place must not be sole access route.
- **Presence** —depends_on→ **Embodied perspective**: Actions and situated perception create location.
- **Six-degree navigation** —constrains→ **Comfort & safety envelope**: Movement options influence safety.
- **Spatial audio** —governed_by→ **Multimodal fallback**: Directional information requires equivalent alternatives.
- **Volumetric representation** —tensions_with→ **Consent & subject dignity**: Captures of people carry likeness and re-use risks.
- **Environmental evidence** —enables→ **Interpretive agency**: Artifacts support different readings.
- **Co-authorship rights** —governed_by→ **Authorship & labor**: Permission and compensation precede remix.
- **Collective intelligence** —depends_on→ **Participatory culture**: Collaboration needs active participants.
- **Moderated canon** —depends_on→ **Role-based participation**: Editors need clear authority.
- **Moderated canon** —depends_on→ **Version & release management**: Changes need migration and traceability.
- **Community safety** —constrains→ **Live participatory story**: Safe participation can limit live input.
- **Participatory archive** —governed_by→ **Privacy by design**: Persistent contributions need privacy controls.
- **Ritual & cadence** —enables→ **Short-form serialized video**: Rhythm creates repeated audience entry.
- **Generative narrative model** —depends_on→ **Persistent canon**: Creation needs verified context.
- **Generative narrative model** —governed_by→ **Human editorial control**: Responsibility survives automation.
- **Director–actor separation** —enables→ **Narrative constraint engine**: Different responsibilities can be checked.
- **Persistent canon** —depends_on→ **World bible**: The authored source of canonical facts.
- **Persistent canon** —depends_on→ **Narrative state ledger**: Canon needs an update history.
- **Agent memory architecture** —tensions_with→ **Character memory**: Simulated memory may diverge from authored psychological plausibility.
- **Agent memory architecture** —depends_on→ **Privacy by design**: Stored interactions carry personal data.
- **Procedural plot planning** —depends_on→ **Causality**: Sequence novelty must preserve causal links.
- **Multimodal shot consistency** —evaluated_by→ **Narrative coherence**: Shot continuity includes identity and causal action.
- **AI provenance & disclosure** —governed_by→ **Provenance chain**: Recording creation history supports disclosures.
- **AI provenance & disclosure** —governed_by→ **Legal applicability**: Disclosure requirements vary by context.
- **Long-horizon evaluation** —evaluated_by→ **Narrative coherence**: Consistency is measurable over many turns.
- **Canon-preserving AI drama** —depends_on→ **Long-horizon evaluation**: Benchmarking is required to trust persistence.
- **Executable narrative constitutions** —enables→ **Narrative constraint engine**: Explicit rules can constrain outputs.
- **Player-shaped persistent worlds** —governed_by→ **Moderated canon**: Shared narratives require authority.
- **Live adaptive direction** —tensions_with→ **Consentful personalization**: Adaptation can become covert behavioral steering.
- **Generative multi-shot cinema** —depends_on→ **Multimodal shot consistency**: Cross-scene validity remains a bottleneck.
- **Spatial memory worlds** —depends_on→ **Volumetric representation**: Navigable reconstruction uses 3D assets.
- **Perspective-based factual agency** —governed_by→ **Truthfulness in nonfiction**: Interpretive freedom must preserve records.
- **Consent-aware personalization** —governed_by→ **Privacy by design**: Permissions constrain adaptation.
- **Machine-readable story provenance** —depends_on→ **Asset & rights ledger**: Media manifests don't replace authorization records.
- **Localized world coherence** —depends_on→ **Localization & transcreation**: Story consequences need equivalent interpretation.
- **Adaptive accessibility narratives** —depends_on→ **Multimodal fallback**: Route parity defines useful adaptation.
- **Microdrama platform diversification** —tensions_with→ **Authorship & labor**: Compressed production can pressure working conditions.
- **Story design brief** —constrains→ **Prototype ladder**: Scope informs tests.
- **World bible** —enables→ **Narrative data model**: Human canon feeds machine semantics.
- **Narrative data model** —enables→ **Narrative quality assurance**: Structured state enables automated tests.
- **Prototype ladder** —evaluated_by→ **Qualitative sensemaking**: Early tests reveal hidden assumptions.
- **Content production pipeline** —depends_on→ **Asset & rights ledger**: Publishing requires cleared assets.
- **Version & release management** —governed_by→ **Narrative quality assurance**: Changes require regression.
- **Localization & transcreation** —evaluated_by→ **Comprehension & recall**: Meaning should survive translation.
- **Archival portability** —depends_on→ **Narrative data model**: Stable formats allow preservation.
- **Narrative coherence** —evaluated_by→ **Evidence ladder**: Claims about quality need scoped evidence.
- **Emotional resonance** —evaluated_by→ **Qualitative sensemaking**: Meaning and affect need interpreted reports.
- **Narrative analytics** —governed_by→ **Privacy by design**: Telemetry must minimize data.
- **Causal experimentation** —depends_on→ **Narrative analytics**: Experiments require outcome measurement.
- **Accessibility outcome** —governed_by→ **Accessible-by-design governance**: Inclusion should be tested and owned.
- **Provenance chain** —tensions_with→ **Truthfulness in nonfiction**: A signed history can still contain false claims.
- **Character kernel** —governed_by→ **Synthetic identity policy**: Synthetic portrayals require identity rules.
- **Safety & content boundaries** —constrains→ **Consentful personalization**: Safety limits adaptation.
- **Legal applicability** —constrains→ **AI provenance & disclosure**: Regulated requirements affect disclosure.

## 05 / FRONTIER WATCHLIST & DISCRIMINATING EXPERIMENTS
### F01 — Durable AI characters, not merely convincing dialogue
**Knowledge state:** Active research
**Observed signal:** 2026 NCP-Bench and WSE-bench examine long-horizon inconsistency and non-equivalent coherence/richness goals.
**Hypothesis:** Typed canon plus belief and commitment verification will improve consistency without suppressing useful variation.
**Test:** 20/50/100-turn adversarial playtests; report contradiction, goal-retention, character specificity and user-rated agency together.
**Failure / disconfirmation:** Averages conceal catastrophic failures or benchmark setting overfits.
**Update trigger:** Independent, reproducible performance on unseen long-horizon scenarios.
**Sources:** [S12], [S13], [S21]

### F02 — World models with editorially governed memory
**Knowledge state:** Emerging / hypothesis
**Observed signal:** Generative-agent architectures demonstrate memory/reflection/planning; persistent multiplayer narrative governance is much less validated.
**Hypothesis:** Append-only event stores, scoped beliefs and narrative directors can sustain shared story state.
**Test:** Simulate conflicting actions by hundreds of role-diverse agents with human adjudication.
**Failure / disconfirmation:** Socially harmful emergent canon and irreversible participant harm.
**Update trigger:** Low-conflict cross-session continuity under real editorial oversight.
**Sources:** [S14], [S12]

### F03 — Multi-shot generative cinema with consistent characters
**Knowledge state:** Active research
**Observed signal:** 2025 long-video survey and StoryMem document continuity deficits and memory-based research directions.
**Hypothesis:** Storyboards, reference assets and explicit shot memory reduce expensive manual repair.
**Test:** Independent human-rated identity, action, composition and editability across 15-shot sequences.
**Failure / disconfirmation:** Vendor showcases and non-independent benchmark claims overstate robustness.
**Update trigger:** Repeatable production-level sequence coherence at known time and cost.
**Sources:** [S15], [S16], [S18]

### F04 — Narrative provenance as part of the interface
**Knowledge state:** Emerging / hypothesis
**Observed signal:** C2PA v2.4 includes an AI disclosure assertion and new provenance mechanisms; support and display remain uneven.
**Hypothesis:** A layered "how this was made" view increases appropriate trust and editorial accountability.
**Test:** Compare user comprehension of provenance, truth and authorship under different disclosures.
**Failure / disconfirmation:** Users confuse provenance with factual accuracy or assume missing metadata means fake.
**Update trigger:** Interoperable creator-to-platform displays plus demonstrated user comprehension.
**Sources:** [S10], [S11]

### F05 — Perspective-based agency for historical stories
**Knowledge state:** Active research
**Observed signal:** A 2026 work-in-progress reports classroom prototyping of role-based interpretive agency while preserving fixed facts.
**Hypothesis:** Allowing interpretive choices can deliver meaningful agency without fictionalizing history.
**Test:** Evaluate source fidelity, role-based empathy and factual recall, with community consultation.
**Failure / disconfirmation:** Role-playing reduces trauma to a game mechanic or distorts responsibility.
**Update trigger:** Replicated evaluations with affected communities and diverse learners.
**Sources:** [S19], [S04]

### F06 — Multimodal equivalence in XR storytelling
**Knowledge state:** Emerging / hypothesis
**Observed signal:** W3C XR user requirements describe diverse input/output needs; device and narrative parity remain hard.
**Hypothesis:** A semantic story layer can render equivalent decisions across visual, sonic, textual and seated modes.
**Test:** Compare comprehension, agency and comfort across disability groups and devices.
**Failure / disconfirmation:** Alternative mode changes what participants can know or decide.
**Update trigger:** Demonstrated cross-modal parity in complete user studies.
**Sources:** [S08], [S09], [S06]

### F07 — Short-form premium serial fiction economics
**Knowledge state:** Observed industry trend / forecast
**Observed signal:** Omdia forecast $11bn global microdrama revenue for 2025; projections are not audited actual outcomes.
**Hypothesis:** Platform-appropriate rapid narrative beats can coexist with non-exploitative monetization and strong character arcs.
**Test:** Track cohort retention, refunds, satisfaction, narrative comprehension and creator economics.
**Failure / disconfirmation:** Metric gaming, aggressive paywalls and regional extrapolation bias.
**Update trigger:** Independent revenue data, creator cost data and longitudinal satisfaction evidence.
**Sources:** [S17]

### F08 — Adaptive narrative without surveillance
**Knowledge state:** Emerging / hypothesis
**Observed signal:** Advances in generative scenes and agent control make live adaptation more plausible; evidence of benefit remains limited.
**Hypothesis:** Explicit preference-based adaptation can beat inferred psychological targeting on trust-adjusted enjoyment.
**Test:** Randomized opt-in study versus generic and covert-targeting control where ethics allow.
**Failure / disconfirmation:** Sensitive trait inference or engagement-optimized compulsion.
**Update trigger:** Consistent improvements in user-defined outcomes without privacy expansion.
**Sources:** [S21], [S06]

### F09 — Machine-actionable creative labor records
**Knowledge state:** Speculative design
**Observed signal:** Existing asset manifests and rights ledgers are complementary but not integrated end-to-end.
**Hypothesis:** Contribution-linked provenance can make compensation, consent and reuse auditable.
**Test:** Pilot one collaborative series using asset-level contracts, withdrawals and reporting.
**Failure / disconfirmation:** Claims of fully automated IP enforcement or inaccurate attribution.
**Update trigger:** Multi-tool exchange plus legally reviewed creator control.
**Sources:** [S10]

### F10 — Interoperable living storyworlds
**Knowledge state:** Speculative design
**Observed signal:** Tools export scripts and state, but no single broadly adopted universal narrative ontology exists.
**Hypothesis:** A minimal portable ontology can decouple canonical content from interfaces and platforms.
**Test:** Port a complex branching story between two runtimes; compare semantics and consequences.
**Failure / disconfirmation:** Lowest-common-denominator schema suppresses medium-specific aesthetics.
**Update trigger:** High-fidelity two-way portability among independently built engines.
**Sources:** [S02], [S03]

## 06 / CASE LENSES
### Twine (Tool / medium)
**Transferable lesson:** Hypertext and conditional state enable low-cost branching prototypes; HTML publishing supports portability. **Limit:** Rich simulations still require deliberate software and content architecture. **Source:** [S02].

### ink by inkle (Tool / medium)
**Transferable lesson:** Recombining narrative flow with stateful dialogue helps avoid purely exploding decision trees. **Limit:** Writing tools do not decide whether branches are meaningful. **Source:** [S03].

### MIT Docubase (Corpus / practice)
**Transferable lesson:** Interactive and immersive nonfiction spans documentary, installation, location and participatory forms. **Limit:** A curated archive is not a representative sample of global production. **Source:** [S05].

### The Matrix as transmedia exemplar (Historical conceptual example)
**Transferable lesson:** Jenkins describes a world distributed through cinema, animation, comics and games with distinct contributions. **Limit:** A sprawling franchise can increase newcomer friction and canon governance costs. **Source:** [S01].

### Generative Agents small-town simulation (Research prototype)
**Transferable lesson:** A memory, reflection and planning pipeline can create plausible local social interactions. **Limit:** A sandbox demonstration is not evidence of psychologically valid people or durable drama. **Source:** [S14].

### NCP-Bench (2026 research benchmark)
**Transferable lesson:** Interactive narration needs explicit commitments and adversarial long-horizon consistency tests. **Limit:** A preprint benchmark is not a universal or replicated quality measure. **Source:** [S12].

### C2PA v2.4 (Trust infrastructure)
**Transferable lesson:** Provenance can express AI disclosure, authorship-related transformations and verification metadata. **Limit:** A correctly signed manifest cannot certify truth of depicted events. **Source:** [S10].

### Microdrama (mobile episodic form) (Industry signal)
**Transferable lesson:** Very short episodic scripted video can reshape pacing, monetization and distribution. **Limit:** Omdia estimates are forecasts; success is region- and platform-dependent. **Source:** [S17].

## 07 / PURPOSE-BUILT READING ROUTES
### The creative director  — 45 minutes
Design a meaningful story for a specific audience.
Story event → Stakes → Theme → Character kernel → Emotional arc → Story design brief → Prototype ladder → Meaningful agency test

### The interactive narrative architect  — 60 minutes
Make agency legible, coherent and testable.
Material agency → Interpretive agency → Agency budget → Foldback branch → State machine → Narrative state ledger → Narrative data model → Narrative quality assurance

### The worldbuilder  — 55 minutes
Maintain fictional consistency across years and media.
Belief model → Relationship graph → Character memory → Identity evolution → World bible → Transmedia world → Persistent canon → Moderated canon

### The AI narrative researcher  — 60 minutes
Stress-test plausible generative story architectures.
Director–actor separation → Agent memory architecture → Narrative constraint engine → Long-horizon evaluation → Canon-preserving AI drama → Generative multi-shot cinema → Evidence ladder → Human editorial control

### The documentary & public-interest maker  — 40 minutes
Offer exploration and interpretation without distorting evidence.
Point of view → Interactive documentary → Interpretive agency → Perspective-based factual agency → Data journalism story → Truthfulness in nonfiction → Consent & subject dignity

### The immersive experience designer  — 40 minutes
Make place and presence meaningful and accessible.
Presence → Embodied perspective → Environmental evidence → Spatial audio → Comfort & safety envelope → Multimodal fallback → Accessibility outcome

### The ethical producer  — 45 minutes
Ship narratives responsibly, with traceable permissions and alternatives.
Asset & rights ledger → Co-authorship rights → Synthetic identity policy → Provenance chain → Privacy by design → Accessible-by-design governance → Archival portability

## 08 / REFERENCE STORY SYSTEM (FICTIONAL DESIGN EXERCISE)
### FLOODLINE / a future-city memory archive
**Premise:** After a catastrophic coastal flood, a neighborhood archivist must decide which endangered memories to preserve while discovering that maps disagree about who was protected.
**Audience:** Adults and secondary-level learners exploring urban planning, memory and civic accountability.
**Format:** 20–30 minute browser-based interactive documentary-fiction hybrid, with a clearly marked invented setting and fictional records.
**Agency:** Participants cannot erase the flood; they choose which witnesses to hear, how to classify contradictory records, and which museum exhibit to publish.
**Theme Question:** Who has the authority to decide what a community remembers?
**Character Kernel:** Archivist Mina values public truth and protecting survivors; their conflict surfaces when publishing a testimony could expose a neighbor.

**State Vars**
- heard_witnesses: set<person_id>
- evidence_flags: set<document_id>
- privacy_consents: map<person_id,bool>
- exhibit_theme: enum{safety,loss,accountability}
- contradictions_noted: set<claim_pair>

**Three Choices**
- Interview the engineer or the street vendor first: changes framing, not historical facts.
- Publish a redacted map or withhold it: changes the exhibition and trust of characters.
- Invite a community review panel or publish rapidly: changes release timeline and authorship.

**Canon Rules**
- Flood timing and casualty numbers remain fixed within the fictional world.
- Witnesses may be mistaken, but the authoritative ledger never silently rewrites itself.
- No personally identifying testimonies publish without in-story consent; players can view redacted alternatives.

**Production**
- Sketch paths in ink/Twine
- Store claims and provenance in JSON
- Create a captioned audio + text-mode prototype
- Run accessibility and fact/fiction labeling tests
- Publish archival package with rights ledger

**Evaluation**
- Agency: did people identify which choices changed outcomes?
- Comprehension: did users distinguish witness statements from verified records?
- Accessibility: was each clue discoverable without audio or motion?
- Trust: did audiences understand fictional versus reconstructed content?

**Boundary:** If presented as real history, synthetic archives could mislead. The experience must prominently disclose its entirely fictional setting.

## 09 / ADAPTIVE PRODUCTION PLAYBOOK
**01. Frame the story promise** — Define a target audience, one thematic question, one enduring change and an ethical red line.
**02. Model identity and canon** — Specify character commitments, beliefs, relationships, scene facts and what may not be rewritten.
**03. Choose affordance, not hype** — Select the smallest form that genuinely requires your chosen degree of agency and sensory embodiment.
**04. Budget consequence** — Name three material effects of participant choices and how they will be communicated.
**05. Prototype without expensive assets** — Use paper, Twine or ink to expose dead-ends, agency illusions and rhythm problems.
**06. Write the state contract** — Assign stable IDs to scenes, facts, users, permissions, assets and transitions.
**07. Build inclusion and trust in** — Make captions, transcripts, alternate control, consent and origin labeling part of the script.
**08. Instrument carefully** — Create hypotheses, minimal telemetry and qualitative evaluation plans; avoid invasive inferred-affect tracking.
**09. Stress test & review** — Test branches, locales, access needs, edge cases, adversarial AI and social abuse.
**10. Publish with rollback** — Record versions, source/rights ledger, human sign-off, archival exports and update triggers.

## 10 / SOURCE REGISTER, EVIDENCE TYPE & PROVENANCE
Sources were visited/verified by web lookup for this 17 October 2026 edition. Sources support selected claims and categories. The ontology, reading paths, relationships, diagnoses and design exercises are original editorial synthesis. No primary user study or systematic review was carried out in preparing this atlas.

- **[S01] Henry Jenkins (2007). Transmedia Storytelling 101.** https://henryjenkins.org/blog/2007/03/transmedia_storytelling_101.html. _primary essay_. Foundational framework
- **[S02] Twine (2026). An open-source tool for telling interactive, nonlinear stories.** https://twinery.org/. _official documentation_. Authoring tool documentation
- **[S03] inkle (2026). ink - narrative scripting language for games.** https://www.inklestudios.com/ink/. _official documentation_. Authoring tool documentation
- **[S04] MIT Open Documentary Lab (2026). About the Open Documentary Lab.** https://opendoclab.mit.edu/opendoclab/. _research lab_. Interactive / immersive documentary
- **[S05] MIT Docubase (2026). Interactive documentary projects and practices.** https://docubase.mit.edu/. _curated case repository_. Example database
- **[S06] W3C (2024). Web Content Accessibility Guidelines (WCAG) 2.2.** https://www.w3.org/TR/WCAG22/. _normative standard_. Accessibility standard
- **[S07] W3C WAI (2024). Making Audio and Video Media Accessible.** https://www.w3.org/WAI/media/av/. _implementation guidance_. Captions, descriptions, transcripts
- **[S08] W3C (2021). XR Accessibility User Requirements.** https://www.w3.org/TR/xaur/. _working group note_. Immersive accessibility needs
- **[S09] W3C (2026). WebXR Device API: candidate recommendation draft.** https://www.w3.org/TR/webxr/. _standards draft_. Web immersive interface
- **[S10] C2PA (2026). Content Credentials technical specification v2.4.** https://spec.c2pa.org/specifications/specifications/2.4/specs/C2PA_Specification.html. _technical specification_. Provenance and AI disclosure assertions
- **[S11] European Commission (2026). Guidelines on Article 50 transparency obligations.** https://digital-strategy.ec.europa.eu/en/policies/guidelines-ai-transparency-obligations. _official policy guidance_. Regulatory transparency EU
- **[S12] Ma et al. (2026). Can LLM Agents Stick to the Script? NCP-Bench.** https://arxiv.org/abs/2608.08160. _preprint; not independently replicated_. Long-horizon narrative commitment preservation
- **[S13] Chen et al. (2026). When Stories Evolve: WSE-bench.** https://arxiv.org/abs/2608.15654. _preprint; not independently replicated_. Consistency versus richness under agent architectures
- **[S14] Park et al. (2023). Generative Agents: Interactive Simulacra of Human Behavior.** https://arxiv.org/abs/2304.03442. _research paper_. Memory, reflection and planning in simulated agents
- **[S15] Elmoghany et al. (2025). Survey on Long-Video Storytelling Generation.** https://openaccess.thecvf.com/content/ICCV2025W/LongVid-Foundation/html/Elmoghany_A_Survey_on_Long-Video_Storytelling_Generation_Architectures_Consistency_and_Cinematic_ICCVW_2025_paper.html. _peer-reviewed workshop survey_. Temporal and character consistency bottlenecks
- **[S16] Zhang et al. (2025). StoryMem: Multi-shot Long Video Storytelling with Memory.** https://arxiv.org/abs/2512.19539. _preprint; claims not independently validated here_. Explicit visual memory in multi-shot synthesis
- **[S17] Omdia (2025). Microdramas to generate $11bn in global revenue in 2025.** https://omdia.tech.informa.com/pr/2025/oct/microdramas-to-generate-11-billion-dollars-in-global-revenues-in-2025-says-omdia. _industry forecast, not actuals_. Industry forecast for vertical scripted fiction
- **[S18] Google DeepMind (2026). Veo 3.1: video generation controls and reference consistency.** https://deepmind.google/models/veo/. _vendor claims_. Vendor-demonstrated generative video
- **[S19] ACM DIS 2026 (2026). Choose Your Own Perspective: role-based agency in heritage learning.** https://dis.acm.org/2026/wp-content/uploads/2026/06/toc_companion.html. _work in progress_. Agency in factual, non-rewritable histories
- **[S20] Wan & Ma (2025). StoryBench: dynamic multi-turn memory benchmark.** https://arxiv.org/abs/2506.13356. _preprint_. Interactive-fiction memory testing
- **[S21] Wu et al. (2025). Towards Enhanced Immersion and Agency for LLM-based Interactive Drama.** https://arxiv.org/abs/2502.17878. _preprint_. LLM drama structure and role agency
- **[S22] European Commission (2026). Article 50 transparency FAQs.** https://digital-strategy.ec.europa.eu/en/faqs/transparency-obligations-under-article-50-ai-act. _official guidance_. Regulatory scope and exceptions

## 11 / REPRODUCIBILITY AND REVISION PROTOCOL
- All concept identifiers are stable within this edition; breaking schema changes require a major version.
- Every typed edge carries a rationale; an edge expresses an argued design relation rather than statistical proof.
- When updating a source, record publication date and revision date separately.
- Promote a frontier entry only when new independent evidence satisfies its stated update trigger.
- Track contradictions and negative results alongside successful showcases.
- Re-audit platform-dependent, legal and pricing claims before decisions.
- Preserve the prior edition and an audit trail of removals, merged terms and semantic changes.
- For empirical review: define search queries, screening, study quality and effect/uncertainty extraction prospectively.

**End of atlas.**  |  Built as an interpretive research atlas, not a universal theory of storytelling.