# Construct v0.9.21 — Grok single-skill edition

One Grok Build Skill named `construct`. It includes all 21 original specialist skills as individually readable references, so you can invoke `/construct` and let its router select the appropriate architecture.

## Install

Extract **the contents of this ZIP** into either:

- Your project: `<project>/.grok/skills/` (result: `<project>/.grok/skills/construct/SKILL.md`)
- Your user profile: `~/.grok/skills/` (result: `~/.grok/skills/construct/SKILL.md`)

Then open Grok Build and enter `/skills` to inspect discovery, or `/construct` to invoke it.

**Note:** The archive does not need a `plugin.json` to function as a Skill. Grok Build discovers the skill folder, not the ZIP directly. Installation consists of extracting the ZIP; no upload-based import is promised.

## Structure

```text
construct/
├── SKILL.md                 # concise Grok entrypoint and module router
├── README.md
├── references/
│   └── modules/
│       ├── construct.md      # original Construct architecture
│       ├── archetype.md      # original archetype module
│       └── ...               # 19 other original modules
├── assets/
│   ├── construct-icon.png
│   ├── source-plugin.json
│   └── source-codex-plugin.json
└── SOURCE_MANIFEST.json
```

## Conversion fidelity

All 21 source skill documents are preserved byte-for-byte as reference files. No original architecture was shortened or rewritten. The concise root `SKILL.md` is new and selects relevant modules. Plugin descriptors and icon are retained as provenance/assets; they are not needed to activate this one skill.

**Version:** 0.9.21. **Source:** supplied Construct archive. **Original author label:** User.
