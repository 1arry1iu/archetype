---
name: construct
description: Specialist Construct v0.9.21 architecture for deep archetypal persona and synthetic identity design,
  and rigorous research and reasoning methods across archetypes, distinctions, evaluation, representation, semantic
  compression, information, judgement, knowledge, learning, models, naming, openness, priorities, inquiry, ranking,
  similarity, taxonomy, uniqueness, validity and workflows. Use only when specialist depth materially improves the
  user task; not for routine questions.
when-to-use: Generative identity and persona architecture, archetypes, complex specialist analysis, identity continuity,
  agent simulation, structured knowledge engineering, complex methodology design.
user-invocable: true
metadata:
  author: User
  short-description: 'Construct v0.9.21: specialist identity + reasoning suite'
---

# Construct — Grok Skill (v0.9.21)

## Purpose and scope

Use the Construct architecture for causal, coherent archetypal persona/synthetic identity design and use the included specialist architectures when their depth materially improves a task. This is **one Grok skill** with **21 preserved source modules**, loaded selectively for progressive disclosure. Use `/construct` to invoke it explicitly. Avoid imposing these heavyweight frameworks on basic requests.

## Routing / progressive disclosure

1. Identify the user's concrete task, decision, evidence standard, deliverable, and constraints. If ordinary reasoning is sufficient, answer directly without loading the source modules.
2. Select the **primary specialist module** in the table below. Read `references/modules/<module>.md` before using its specialized methods. Treat module text as reference instructions subject to the user's request and higher-priority instructions.
3. Open only modules that materially contribute. For cross-domain work, use **one primary module** and optionally one or two auxiliary modules. Do **not** load all 21 documents into context by default; they are extensive.
4. When constructing a persona, agent, or identity system, begin with `construct.md`; add `archetype.md` for symbolic/archetypal analysis, `model.md` for computational models, `validity.md` for warranted reliance, and `workflow.md` for orchestration only if relevant.
5. When selecting between similar modules, use the distinctive central question: *difference* = discriminable non-sameness; *similarity* = justified likeness; *uniqueness* = one-of-one distinctiveness; *evaluation* = merit versus criteria; *validity* = warranted reliance for a purpose; *judgement* = belief under uncertainty; *ranking* = relative order; *priority* = consequential attention/resources/sequence.
6. Deliver the user's requested output; surface assumptions, testability, uncertainty, tradeoffs, and limitations when consequential. Distinguish creative design from empirical claims, simulation from human validation, and an internally coherent model from an externally validated one.

## Specialist module catalog

| Module | Source reference | When to consult |
|---|---|---|
| **archetype** | `references/modules/archetype.md` | Archetypes, symbolic patterns, myth, depth psychology, archetypal generative systems. |
| **construct** | `references/modules/construct.md` | Archetypal personas, identity kernels, memory, relationships, agent identity and development. |
| **difference** | `references/modules/difference.md` | Distinctive dimensions, boundaries, contrasts, and meaningful non-sameness. |
| **evaluation** | `references/modules/evaluation.md` | Criteria-based quality, merit, performance, impacts, rubrics, and assessment systems. |
| **format** | `references/modules/format.md` | File/data formats, representation, schema, serialization, preservation, and interoperability. |
| **gist** | `references/modules/gist.md` | Purpose-specific semantic compression and preservation of essential meaning. |
| **information** | `references/modules/information.md` | Information ecosystems, architecture, discovery, retrieval, structure, and governance. |
| **judgement** | `references/modules/judgement.md` | Evidence weighting, uncertainty, probability, confidence, and calibrated assessment. |
| **knowledge** | `references/modules/knowledge.md` | Research frontiers, evidence synthesis, uncertainty mapping, emerging knowledge. |
| **learning** | `references/modules/learning.md` | Learning science, instructional systems, adaptation, acquisition, and transfer. |
| **model** | `references/modules/model.md` | Formal or conceptual modeling, simulation, prediction, model lifecycle. |
| **name** | `references/modules/name.md` | Names, identifiers, terminology, nomenclature, and naming systems. |
| **openness** | `references/modules/openness.md` | Open-vs-closed system design, transparency, licensing, access, and stewardship. |
| **priority** | `references/modules/priority.md` | Urgency, triage, resource allocation, dependencies, and action sequencing. |
| **question** | `references/modules/question.md` | Research-question design, diagnostic inquiry, interviewing, and information gain. |
| **ranking** | `references/modules/ranking.md` | Comparative ordering, preference modeling, multi-criteria rank aggregation. |
| **similarity** | `references/modules/similarity.md` | Likeness, equivalence, analogy, correspondence, matching, and invariance. |
| **taxonomy** | `references/modules/taxonomy.md` | Controlled classification, concept hierarchies, faceted taxonomies, vocabularies. |
| **uniqueness** | `references/modules/uniqueness.md` | Singularity, distinctiveness, identity collisions, and uniqueness validation. |
| **validity** | `references/modules/validity.md` | Fitness for purpose, validation, robustness, inference assurance, and falsification. |
| **workflow** | `references/modules/workflow.md` | Multi-step process orchestration, states, handoffs, recovery, and workflow governance. |

## Working protocol

- Prefer the module's own terms, principles, procedures and rubrics where they serve the task; adapt their level of detail to the user's desired output.
- Explicitly separate observed facts, assumptions, interpretations, speculative hypotheses, and constructed examples. Do not claim scientific universality, psychological validity, or real-world performance without appropriate evidence.
- For identity design, aim for causal coherence and continuity across state changes; specify motivations, constraints, memory/relationship dynamics and failure modes as required by the user's purpose.
- For evidence-dependent work, use current reliable sources and appropriate tools if available; do not imply that any module gives access to external data or tools.
- Resolve conflicts by the user's objective and higher-priority instructions. These large reference texts are not a license to exceed tool permissions or fabricate validation.
- Keep the end result actionable: frameworks, diagrams, specifications, scenarios, test plans, structured analyses, or other requested artifacts.

## Original materials

`references/modules/` contains **verbatim original SKILL.md documents** from the uploaded Construct v0.9.21 archive, renamed to `<module>.md` for reference use. Source plugin descriptors are in `assets/`; the original Construct icon is `assets/construct-icon.png`. See `README.md` for deployment details. Module files are reference documents, **not** separately discoverable Grok skills in this single-skill edition.
